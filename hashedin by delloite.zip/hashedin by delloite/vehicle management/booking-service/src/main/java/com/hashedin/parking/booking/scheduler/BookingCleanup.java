package com.hashedin.parking.booking.scheduler;

import com.hashedin.parking.booking.model.Booking;
import com.hashedin.parking.booking.repo.BookingRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class BookingCleanup {
    private static final Logger log = LoggerFactory.getLogger(BookingCleanup.class);
    private final BookingRepo repo;

    public BookingCleanup(BookingRepo repo) { this.repo = repo; }

    @Scheduled(cron = "0 */15 * * * *")
    public void expireOld() {
        List<Booking> all = repo.findAll();
        int changed = 0;
        for (Booking b : all) {
            if ("CREATED".equals(b.getStatus()) && b.getEndTime().isBefore(LocalDateTime.now())) {
                b.setStatus("EXPIRED");
                repo.save(b);
                changed++;
            }
        }
        if (changed > 0) log.info("Expired {} bookings", changed);
    }
}
