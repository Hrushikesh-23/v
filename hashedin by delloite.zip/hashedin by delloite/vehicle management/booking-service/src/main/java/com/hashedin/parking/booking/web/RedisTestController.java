package com.hashedin.parking.booking.web;

import org.springframework.web.bind.annotation.*;
import com.hashedin.parking.booking.service.AvailabilityCache;

@RestController
@RequestMapping("/redis")
public class RedisTestController {

    private final AvailabilityCache cache;

    public RedisTestController(AvailabilityCache cache) {
        this.cache = cache;
    }

    @PostMapping("/set")
    public String setUnavailable(@RequestParam Long spotId, @RequestParam String windowKey) {
        cache.setUnavailable(spotId, windowKey, 30); // TTL = 30 seconds
        return "Set unavailable for spot " + spotId + " with window " + windowKey;
    }

    @GetMapping("/check")
    public String checkUnavailable(@RequestParam Long spotId, @RequestParam String windowKey) {
        boolean result = cache.isUnavailable(spotId, windowKey);
        return result ? "❌ Spot is unavailable" : "✅ Spot is available";
    }
    
    @PostMapping("/clear")
    public String clearUnavailable(@RequestParam Long spotId, @RequestParam String windowKey) {
        cache.evict(spotId, windowKey);
        return "Cleared availability for spot " + spotId + " with window " + windowKey;
    }
}
