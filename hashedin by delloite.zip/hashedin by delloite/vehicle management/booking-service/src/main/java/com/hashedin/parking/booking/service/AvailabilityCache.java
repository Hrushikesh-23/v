package com.hashedin.parking.booking.service;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

@Component
public class AvailabilityCache {
    private final RedisTemplate<String, String> redis;

    public AvailabilityCache(RedisTemplate<String, String> redis) {
        this.redis = redis;
    }

    public void setUnavailable(Long spotId, String windowKey, long ttlSeconds) {
        String key = "spot:" + spotId + ":" + windowKey;
        redis.opsForValue().set(key, "unavailable", java.time.Duration.ofSeconds(ttlSeconds));
    }

    public boolean isUnavailable(Long spotId, String windowKey) {
        return Boolean.TRUE.equals(redis.hasKey("spot:" + spotId + ":" + windowKey));
    }
    
    public void evict(Long spotId, String windowKey) {
        String key = "spot:" + spotId + ":" + windowKey;
        redis.delete(key);
    }
}
