package com.hashedin.parking.booking.mq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Map;

@Component
public class UserProfileListener {

    private static final Logger log = LoggerFactory.getLogger(UserProfileListener.class);
    private final StringRedisTemplate redis;

    public UserProfileListener(StringRedisTemplate redis) {
        this.redis = redis;
    }

    @RabbitListener(queues = "${app.rabbit.queues.bookingService.userProfileUpdated}")
    public void onUserProfileUpdated(Map<String, Object> ev) {
        try {
            String userId   = String.valueOf(ev.get("userId"));
            String email    = ev.get("email") == null ? "" : ev.get("email").toString();
            String fullName = ev.get("fullName") == null ? "" : ev.get("fullName").toString();

            String key = "user:profile:" + userId;
            redis.opsForHash().put(key, "email", email);
            redis.opsForHash().put(key, "fullName", fullName);
            redis.expire(key, java.time.Duration.ofHours(24));

            log.info("Booking cached user profile {} -> {}, {}", userId, email, fullName);
        } catch (Exception e) {
            log.warn("Booking failed caching user profile: {}", e.getMessage());
        }
    }
}
