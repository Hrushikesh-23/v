package com.hashedin.parking.booking.web;

import com.hashedin.parking.booking.model.Booking;
import com.hashedin.parking.booking.model.Waitlist;
import com.hashedin.parking.booking.repo.BookingRepo;
import com.hashedin.parking.booking.service.AvailabilityCache;
import com.hashedin.parking.booking.service.WaitlistService;
import com.hashedin.parking.common.events.Events;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingRepo repo;
    private final AvailabilityCache cache;
    private final WaitlistService waitlistService;
    private final RabbitTemplate rabbit;
    private final String exchange;
    private final String bookingCreatedRoutingKey;
    private final String bookingCancelledRoutingKey;

    public record CreateBookingRequest(@NotNull Long lotId,
                                       @NotNull Long spotId,
                                       @NotNull LocalDateTime startTime,
                                       @NotNull LocalDateTime endTime) {}
    
    public record UpdateBookingRequest(Long lotId,
                                      Long spotId,
                                      LocalDateTime startTime,
                                      LocalDateTime endTime) {}

    public BookingController(BookingRepo repo,
                             AvailabilityCache cache,
                             WaitlistService waitlistService,
                             RabbitTemplate rabbit,
                             @Value("${app.rabbit.exchange}") String exchange,
                             @Value("${app.rabbit.routing.bookingCreated}") String bookingCreatedRoutingKey,
                             @Value("${app.rabbit.routing.bookingCancelled}") String bookingCancelledRoutingKey) {
        this.repo = repo;
        this.cache = cache;
        this.waitlistService = waitlistService;
        this.rabbit = rabbit;
        this.exchange = exchange;
        this.bookingCreatedRoutingKey = bookingCreatedRoutingKey;
        this.bookingCancelledRoutingKey = bookingCancelledRoutingKey;
    }

    @GetMapping
    public List<Booking> myBookings(Authentication auth) {
        return repo.findByUserId(UUID.fromString(auth.getName()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getBooking(Authentication auth, @PathVariable("id") UUID id) {
        return ResponseEntity.of(repo.findById(id).map(booking -> {
            if (!booking.getUserId().toString().equals(auth.getName())) {
                return Map.of("error", "forbidden");
            }
            return booking;
        }));
    }

    @PostMapping
    @Transactional
    public ResponseEntity<?> create(Authentication auth, @Valid @RequestBody CreateBookingRequest req) {
        String windowKey = req.startTime() + ":" + req.endTime();
        if (cache.isUnavailable(req.spotId(), windowKey)) {
            return ResponseEntity.badRequest().body(Map.of("error", "spot unavailable for window"));
        }
        boolean dbConflict = repo.existsBySpotIdAndStatusInAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
                req.spotId(), List.of("CREATED", "CONFIRMED"), req.endTime(), req.startTime());
        if (dbConflict) {
            // Instead of returning error, offer waitlist option
            try {
                Waitlist waitlistEntry = waitlistService.addToWaitlist(
                    UUID.fromString(auth.getName()),
                    req.lotId(),
                    req.spotId(),
                    req.startTime(),
                    req.endTime()
                );
                return ResponseEntity.status(202).body(Map.of(
                    "message", "spot unavailable, added to waitlist",
                    "waitlistId", waitlistEntry.getId(),
                    "position", waitlistService.getUserWaitlist(UUID.fromString(auth.getName())).size()
                ));
            } catch (IllegalArgumentException e) {
                return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
            }
        }

        Booking b = new Booking();
        b.setUserId(UUID.fromString(auth.getName()));
        b.setLotId(req.lotId());
        b.setSpotId(req.spotId());
        b.setStartTime(req.startTime());
        b.setEndTime(req.endTime());
        b.setStatus("CREATED");
        Booking saved = repo.save(b);

        long ttl = Math.max(Duration.between(LocalDateTime.now(), req.endTime()).toSeconds(), 60);
        cache.setUnavailable(req.spotId(), windowKey, ttl);

        // publish booking.created
        rabbit.convertAndSend(
                exchange,
                bookingCreatedRoutingKey,
                new Events.BookingCreated(
                        saved.getId(),
                        saved.getUserId(),
                        saved.getLotId(),
                        saved.getSpotId(),
                        saved.getStartTime(),
                        saved.getEndTime()
                )
        );

        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateBooking(Authentication auth, 
                                         @PathVariable("id") UUID id, 
                                         @Valid @RequestBody UpdateBookingRequest req) {
        return ResponseEntity.of(repo.findById(id).map(booking -> {
            if (!booking.getUserId().toString().equals(auth.getName())) {
                return Map.of("error", "forbidden");
            }
            
            // Only allow updates for CREATED bookings
            if (!"CREATED".equals(booking.getStatus())) {
                return Map.of("error", "can only update CREATED bookings");
            }
            
            // Check if any fields are being updated
            boolean hasChanges = false;
            
            if (req.lotId() != null && !req.lotId().equals(booking.getLotId())) {
                booking.setLotId(req.lotId());
                hasChanges = true;
            }
            
            if (req.spotId() != null && !req.spotId().equals(booking.getSpotId())) {
                // Clear old cache entry
                String oldWindowKey = booking.getStartTime() + ":" + booking.getEndTime();
                cache.evict(booking.getSpotId(), oldWindowKey);
                
                booking.setSpotId(req.spotId());
                hasChanges = true;
            }
            
            if (req.startTime() != null && !req.startTime().equals(booking.getStartTime())) {
                booking.setStartTime(req.startTime());
                hasChanges = true;
            }
            
            if (req.endTime() != null && !req.endTime().equals(booking.getEndTime())) {
                booking.setEndTime(req.endTime());
                hasChanges = true;
            }
            
            if (!hasChanges) {
                return Map.of("message", "no changes detected");
            }
            
            // Validate new time slot availability
            String newWindowKey = booking.getStartTime() + ":" + booking.getEndTime();
            if (cache.isUnavailable(booking.getSpotId(), newWindowKey)) {
                return Map.of("error", "spot unavailable for new time window");
            }
            
            // Check for conflicts with new time slot
            boolean dbConflict = repo.existsBySpotIdAndStatusInAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
                    booking.getSpotId(), List.of("CREATED", "CONFIRMED"), 
                    booking.getEndTime(), booking.getStartTime());
            
            // Exclude current booking from conflict check
            if (dbConflict) {
                List<Booking> conflictingBookings = repo.findAll().stream()
                    .filter(b -> b.getSpotId().equals(booking.getSpotId()) &&
                               List.of("CREATED", "CONFIRMED").contains(b.getStatus()) &&
                               !b.getId().equals(booking.getId()) &&
                               b.getStartTime().isBefore(booking.getEndTime()) &&
                               b.getEndTime().isAfter(booking.getStartTime()))
                    .toList();
                
                if (!conflictingBookings.isEmpty()) {
                    return Map.of("error", "spot conflict with existing booking");
                }
            }
            
            Booking saved = repo.save(booking);
            
            // Update cache with new availability
            long ttl = Math.max(Duration.between(LocalDateTime.now(), booking.getEndTime()).toSeconds(), 60);
            cache.setUnavailable(booking.getSpotId(), newWindowKey, ttl);
            
            // Publish booking updated event
            rabbit.convertAndSend(
                    exchange,
                    bookingCreatedRoutingKey, // Reuse the same routing key
                    new Events.BookingCreated(
                            saved.getId(),
                            saved.getUserId(),
                            saved.getLotId(),
                            saved.getSpotId(),
                            saved.getStartTime(),
                            saved.getEndTime()
                    )
            );
            
            return Map.of("message", "booking updated successfully", "booking", saved);
        }));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> cancel(Authentication auth, @PathVariable("id") UUID id) {
        return ResponseEntity.of(repo.findById(id).map(b -> {
            if (!b.getUserId().toString().equals(auth.getName()))
                return Map.of("error", "forbidden");

            b.setStatus("CANCELLED");
            repo.save(b);

            // Clear cache entry for this booking
            String windowKey = b.getStartTime() + ":" + b.getEndTime();
            cache.evict(b.getSpotId(), windowKey);

            // Process waitlist for this spot and time window
            waitlistService.processWaitlistForSpot(
                b.getSpotId(),
                b.getStartTime(),
                b.getEndTime()
            );

            // publish booking.cancelled
            rabbit.convertAndSend(
                    exchange,
                    bookingCancelledRoutingKey,
                    new Events.BookingCancelled(b.getId(), b.getUserId())
            );

            return Map.of("message", "cancelled");
        }));
    }

    @GetMapping("/past")
    public List<Booking> past(Authentication auth) {
        return repo.findByEndTimeBeforeAndUserId(LocalDateTime.now(), UUID.fromString(auth.getName()));
    }

    @GetMapping("/future")
    public List<Booking> future(Authentication auth) {
        return repo.findByStartTimeAfterAndUserId(LocalDateTime.now(), UUID.fromString(auth.getName()));
    }
    
    // ==== Waitlist Management Endpoints ====
    
    @GetMapping("/waitlist")
    public List<Waitlist> myWaitlist(Authentication auth) {
        return waitlistService.getUserWaitlist(UUID.fromString(auth.getName()));
    }
    
    @PostMapping("/waitlist")
    public ResponseEntity<?> addToWaitlist(Authentication auth, @Valid @RequestBody CreateBookingRequest req) {
        try {
            Waitlist waitlistEntry = waitlistService.addToWaitlist(
                UUID.fromString(auth.getName()),
                req.lotId(),
                req.spotId(),
                req.startTime(),
                req.endTime()
            );
            return ResponseEntity.ok(Map.of(
                "message", "added to waitlist",
                "waitlistId", waitlistEntry.getId(),
                "position", waitlistService.getUserWaitlist(UUID.fromString(auth.getName())).size()
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
    
    @DeleteMapping("/waitlist/{id}")
    public ResponseEntity<?> cancelWaitlist(Authentication auth, @PathVariable("id") UUID id) {
        waitlistService.cancelWaitlistEntry(UUID.fromString(auth.getName()), id);
        return ResponseEntity.ok(Map.of("message", "waitlist entry cancelled"));
    }
}
