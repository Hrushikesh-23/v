package com.hashedin.parking.booking.scheduler;

import com.hashedin.parking.booking.model.Booking;
import com.hashedin.parking.booking.repo.BookingRepo;
import com.hashedin.parking.booking.service.WaitlistService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class WaitlistScheduler {
    private static final Logger log = LoggerFactory.getLogger(WaitlistScheduler.class);
    private final WaitlistService waitlistService;
    private final BookingRepo bookingRepo;

    public WaitlistScheduler(WaitlistService waitlistService, BookingRepo bookingRepo) {
        this.waitlistService = waitlistService;
        this.bookingRepo = bookingRepo;
    }

    @Scheduled(cron = "0 */5 * * * *") // Every 5 minutes
    @Transactional
    public void processWaitlist() {
        try {
            // Clean up expired waitlist entries
            waitlistService.expireWaitlistEntries();
            
            // Process waitlist for recently cancelled bookings (last 10 minutes)
            LocalDateTime cutoffTime = LocalDateTime.now().minusMinutes(10);
            List<Booking> recentCancelledBookings = bookingRepo.findByStatusAndUpdatedAtAfter("CANCELLED", cutoffTime);
            
            for (Booking cancelled : recentCancelledBookings) {
                // Process waitlist for this spot and time window
                waitlistService.processWaitlistForSpot(
                    cancelled.getSpotId(),
                    cancelled.getStartTime(),
                    cancelled.getEndTime()
                );
            }
            
            log.debug("Processed waitlist cleanup and promotions for {} cancelled bookings", recentCancelledBookings.size());
        } catch (Exception e) {
            log.error("Error processing waitlist: {}", e.getMessage());
        }
    }
}
