package com.hashedin.parking.payment.mq;

import com.hashedin.parking.common.events.Events;
import com.hashedin.parking.payment.model.Payment;
import com.hashedin.parking.payment.repo.PaymentRepo;
import com.hashedin.parking.payment.service.PaymentCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Duration;

@Component
public class BookingListener {

    private static final Logger log = LoggerFactory.getLogger(BookingListener.class);
    private final PaymentRepo repo;
    private final PaymentCache cache;

    public BookingListener(PaymentRepo repo, PaymentCache cache) {
        this.repo = repo;
        this.cache = cache;
    }

    // NOTE: nested YAML key
    @RabbitListener(queues = "${app.queues.paymentService.bookingCreated}")
    @Transactional
    public void onBookingCreated(Events.BookingCreated ev) {
        log.info("Payment init for booking {}", ev.bookingId());

        // Check if payment already exists for this booking
        if (repo.existsByBookingIdAndStatus(ev.bookingId(), "PENDING")) {
            log.info("Payment already exists for booking {}, skipping creation", ev.bookingId());
            return;
        }

        Payment p = new Payment();
        p.setBookingId(ev.bookingId());
        p.setUserId(ev.userId());
        p.setAmount(new BigDecimal("100.00"));
        p.setStatus("PENDING");
        Payment saved = repo.save(p);

        // Cache the payment
        cache.putPayment(saved, Duration.ofMinutes(30));

        // Evict related caches
        cache.evictUserPayments(saved.getUserId());
        cache.evictBookingPayments(saved.getBookingId());
        cache.evictPaymentsByStatus("PENDING");

        log.info("Created payment {} for booking {}", saved.getId(), ev.bookingId());
    }
}
