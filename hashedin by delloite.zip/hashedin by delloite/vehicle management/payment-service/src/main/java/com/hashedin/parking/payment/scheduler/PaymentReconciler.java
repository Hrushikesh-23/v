package com.hashedin.parking.payment.scheduler;

import com.hashedin.parking.payment.model.Payment;
import com.hashedin.parking.payment.repo.PaymentRepo;
import com.hashedin.parking.payment.service.PaymentCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

@Component
public class PaymentReconciler {
    private static final Logger log = LoggerFactory.getLogger(PaymentReconciler.class);
    private final PaymentRepo repo;
    private final PaymentCache cache;

    public PaymentReconciler(PaymentRepo repo, PaymentCache cache) { 
        this.repo = repo; 
        this.cache = cache;
    }

    @Scheduled(cron = "0 */30 * * * *")
    public void expirePending() {
        LocalDateTime cutoff = LocalDateTime.now().minusHours(2);
        List<Payment> all = repo.findAll();
        int changed = 0;
        for (Payment p : all) {
            if ("PENDING".equals(p.getStatus()) && p.getCreatedAt().isBefore(cutoff)) {
                p.setStatus("EXPIRED");
                Payment saved = repo.save(p);

                // Update cache
                cache.putPayment(saved, Duration.ofMinutes(30));

                // Evict related caches
                cache.evictUserPayments(saved.getUserId());
                cache.evictBookingPayments(saved.getBookingId());
                cache.evictPaymentsByStatus("PENDING");
                cache.evictPaymentsByStatus("EXPIRED");

                changed++;
            }
        }
        if (changed > 0) log.info("Expired {} pending payments", changed);
    }
}
