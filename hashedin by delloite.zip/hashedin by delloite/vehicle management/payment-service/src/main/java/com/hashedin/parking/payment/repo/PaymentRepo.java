package com.hashedin.parking.payment.repo;

import com.hashedin.parking.payment.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

public interface PaymentRepo extends JpaRepository<Payment, UUID> {
    List<Payment> findByUserId(UUID userId);
    List<Payment> findByBookingId(UUID bookingId);
    List<Payment> findByCreatedAtBetween(LocalDateTime from, LocalDateTime to);
    List<Payment> findByStatus(String status);
    List<Payment> findByUserIdAndStatus(UUID userId, String status);
    boolean existsByBookingIdAndStatus(UUID bookingId, String status);
}
