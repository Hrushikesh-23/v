package com.hashedin.parking.payment.web;

import com.hashedin.parking.common.events.Events;
import com.hashedin.parking.payment.model.Payment;
import com.hashedin.parking.payment.repo.PaymentRepo;
import com.hashedin.parking.payment.service.PaymentCache;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentRepo repo;
    private final PaymentCache cache;
    private final RabbitTemplate rabbit;
    private final String exchange;
    private final String paymentStatusRoutingKey;

    public PaymentController(
            PaymentRepo repo,
            PaymentCache cache,
            RabbitTemplate rabbit,
            @Value("${app.rabbit.exchange}") String exchange,
            @Value("${app.rabbit.routing.paymentStatus}") String paymentStatusRoutingKey
    ) {
        this.repo = repo;
        this.cache = cache;
        this.rabbit = rabbit;
        this.exchange = exchange;
        this.paymentStatusRoutingKey = paymentStatusRoutingKey;
    }

    public record InitiateRequest(@NotNull UUID bookingId, @NotNull BigDecimal amount) {}

    @PostMapping
    @Transactional
    public ResponseEntity<?> initiate(Authentication auth, @Valid @RequestBody InitiateRequest req) {
        // Check if payment already exists for this booking
        if (repo.existsByBookingIdAndStatus(req.bookingId(), "PENDING")) {
            return ResponseEntity.badRequest().body(Map.of("error", "Payment already exists for this booking"));
        }
        
        Payment p = new Payment();
        p.setBookingId(req.bookingId());
        p.setUserId(UUID.fromString(auth.getName()));
        p.setAmount(req.amount());
        p.setStatus("PENDING");
        Payment saved = repo.save(p);

        // Cache the payment
        cache.putPayment(saved, Duration.ofMinutes(30));

        // Evict related caches
        cache.evictUserPayments(saved.getUserId());
        cache.evictBookingPayments(saved.getBookingId());
        cache.evictPaymentsByStatus("PENDING");

        rabbit.convertAndSend(
                exchange,
                paymentStatusRoutingKey,
                new Events.PaymentStatusChanged(
                        saved.getId(), saved.getBookingId(), saved.getUserId(),
                        saved.getAmount(), saved.getStatus()
                )
        );
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/{id}/confirm")
    public ResponseEntity<?> confirm(@PathVariable("id") UUID id) {
        return ResponseEntity.of(repo.findById(id).map(p -> {
            p.setStatus("COMPLETED");
            Payment saved = repo.save(p);

            // Update cache
            cache.putPayment(saved, Duration.ofMinutes(30));

            // Evict related caches
            cache.evictUserPayments(saved.getUserId());
            cache.evictBookingPayments(saved.getBookingId());
            cache.evictPaymentsByStatus("PENDING");
            cache.evictPaymentsByStatus("COMPLETED");

            rabbit.convertAndSend(
                    exchange,
                    paymentStatusRoutingKey,
                    new Events.PaymentStatusChanged(
                            saved.getId(), saved.getBookingId(), saved.getUserId(),
                            saved.getAmount(), saved.getStatus()
                    )
            );
            return Map.of("message","confirmed");
        }));
    }

    @GetMapping
    public List<Payment> myPayments(Authentication auth) {
        UUID userId = UUID.fromString(auth.getName());
        
        // Try cache first
        List<Payment> cached = cache.getUserPayments(userId);
        if (cached != null) {
            return cached;
        }
        
        // Fetch from database
        List<Payment> payments = repo.findByUserId(userId);
        
        // Cache the result
        cache.putUserPayments(userId, payments, Duration.ofMinutes(15));
        
        return payments;
    }

    @GetMapping("/booking/{bookingId}")
    public List<Payment> getPaymentsByBooking(@PathVariable("bookingId") UUID bookingId) {
        // Try cache first
        List<Payment> cached = cache.getBookingPayments(bookingId);
        if (cached != null) {
            return cached;
        }
        
        // Fetch from database
        List<Payment> payments = repo.findByBookingId(bookingId);
        
        // Cache the result
        cache.putBookingPayments(bookingId, payments, Duration.ofMinutes(15));
        
        return payments;
    }

    @GetMapping("/between")
    public List<Payment> between(@RequestParam String from, @RequestParam String to) {
        return repo.findByCreatedAtBetween(LocalDateTime.parse(from), LocalDateTime.parse(to));
    }

    @GetMapping("/status/{status}")
    public List<Payment> getPaymentsByStatus(@PathVariable("status") String status) {
        // Try cache first
        List<Payment> cached = cache.getPaymentsByStatus(status);
        if (cached != null) {
            return cached;
        }
        
        // Fetch from database
        List<Payment> payments = repo.findByStatus(status);
        
        // Cache the result
        cache.putPaymentsByStatus(status, payments, Duration.ofMinutes(10));
        
        return payments;
    }

    // ==== Admin Endpoints ====
    
    @GetMapping("/admin/all")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Payment> getAllPayments() {
        return repo.findAll();
    }

    @GetMapping("/admin/user/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Payment> getPaymentsByUserForAdmin(@PathVariable("userId") UUID userId) {
        // Try cache first
        List<Payment> cached = cache.getUserPayments(userId);
        if (cached != null) {
            return cached;
        }
        
        // Fetch from database
        List<Payment> payments = repo.findByUserId(userId);
        
        // Cache the result
        cache.putUserPayments(userId, payments, Duration.ofMinutes(15));
        
        return payments;
    }

    @GetMapping("/admin/status/{status}")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Payment> getPaymentsByStatusForAdmin(@PathVariable("status") String status) {
        return getPaymentsByStatus(status);
    }

    @PostMapping("/{id}/fail")
    public ResponseEntity<?> failPayment(@PathVariable("id") UUID id, 
                                       @RequestParam(required = false) String reason,
                                       Authentication auth) {
        return ResponseEntity.of(repo.findById(id).map(p -> {
            p.setStatus("FAILED");
            Payment saved = repo.save(p);

            // Update cache
            cache.putPayment(saved, Duration.ofMinutes(30));

            // Evict related caches
            cache.evictUserPayments(saved.getUserId());
            cache.evictBookingPayments(saved.getBookingId());
            cache.evictPaymentsByStatus("PENDING");
            cache.evictPaymentsByStatus("FAILED");

            rabbit.convertAndSend(
                    exchange,
                    paymentStatusRoutingKey,
                    new Events.PaymentStatusChanged(
                            saved.getId(), saved.getBookingId(), saved.getUserId(),
                            saved.getAmount(), saved.getStatus()
                    )
            );
            return Map.of("message", "payment marked as failed", "reason", reason != null ? reason : "No reason provided");
        }));
    }

    @PostMapping("/cache/clear")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> clearCache() {
        cache.evictAllPaymentCaches();
        return ResponseEntity.ok(Map.of("message", "All payment caches cleared"));
    }

}
