package com.hashedin.parking.user.cache;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Component
public class ProfileCache {

    private final RedisTemplate<String, Object> redis;

    public ProfileCache(RedisTemplate<String, Object> redis) {
        this.redis = redis;
    }

    private String key(String userId) {
        return "user:profile:" + userId;
    }

    public Map<String, Object> get(String userId) {
        Object v = redis.opsForValue().get(key(userId));
        if (v instanceof Map<?, ?> map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> cast = (Map<String, Object>) map;
            return cast;
        }
        return null;
    }

    public void put(String userId, Map<String, Object> profile, Duration ttl) {
        redis.opsForValue().set(key(userId), profile, ttl.toSeconds(), TimeUnit.SECONDS);
    }

    public void evict(String userId) {
        redis.delete(key(userId));
    }
}
