package com.hashedin.parking.user.model;

import com.hashedin.parking.common.security.Roles;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue
    private UUID id;
    @Column(unique = true, nullable = false)
    private String email;
    private String passwordHash;
    private String fullName;
    @Enumerated(EnumType.STRING)
    private Roles role = Roles.USER;
    private boolean active = true;


    // --- booking-driven stats (filled by booking.created listener) ---
    private Integer bookingCount = 0;
    private LocalDateTime lastBookingAt;

    public Integer getBookingCount() { return bookingCount; }
    public void setBookingCount(Integer bookingCount) { this.bookingCount = bookingCount; }

    public LocalDateTime getLastBookingAt() { return lastBookingAt; }
    public void setLastBookingAt(LocalDateTime lastBookingAt) { this.lastBookingAt = lastBookingAt; }


    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public Roles getRole() { return role; }
    public void setRole(Roles role) { this.role = role; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}
