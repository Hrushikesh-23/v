package com.hashedin.parking.user.web;

import com.hashedin.parking.common.events.Events;
import com.hashedin.parking.common.security.JwtUtils;
import com.hashedin.parking.common.security.Roles;
import com.hashedin.parking.user.security.TokenBlacklistService;
import com.hashedin.parking.common.web.SecurityConstants;
import com.hashedin.parking.user.model.PasswordResetToken;
import com.hashedin.parking.user.model.User;
import com.hashedin.parking.user.repo.PasswordResetRepo;
import com.hashedin.parking.user.repo.UserRepo;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.web.bind.annotation.*;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepo repo;
    private final String jwtSecret;
    private final PasswordResetRepo resetRepo;
    private final TokenBlacklistService blacklistService;
    private final RabbitTemplate rabbit;
    private final String exchange;
    private final String notifyEmailRouting;

    public AuthController(UserRepo repo,
                          PasswordResetRepo resetRepo,
                          TokenBlacklistService blacklistService,
                          RabbitTemplate rabbit,
                          @Value("${app.rabbit.exchange}") String exchange,
                          @Value("${app.rabbit.routing.notifyEmail}") String notifyEmailRouting,
                          @Value("${app.jwt.secret}") String jwtSecret) {
        this.repo = repo;
        this.resetRepo = resetRepo;
        this.blacklistService = blacklistService;
        this.rabbit = rabbit;
        this.exchange = exchange;
        this.notifyEmailRouting = notifyEmailRouting;
        this.jwtSecret = jwtSecret;
    }

    public record RegisterRequest(@NotBlank String fullName, @Email String email, @NotBlank String password, Roles role) {}
    public record LoginRequest(@Email String email, @NotBlank String password) {}
    public record TokenResponse(String token) {}
    public record ChangePasswordRequest(@NotBlank String oldPassword, @NotBlank String newPassword) {}
    public record ForgotPasswordRequest(@Email String email) {}
    public record ResetPasswordRequest(@NotBlank String token, @NotBlank String newPassword) {}


    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        if (repo.findByEmail(req.email()).isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("error","email exists"));
        }
        User u = new User();
        u.setEmail(req.email());
        u.setFullName(req.fullName());
        u.setPasswordHash(BCrypt.hashpw(req.password(), BCrypt.gensalt()));
        // Use provided role, default to USER if not specified
        u.setRole(req.role() != null ? req.role() : Roles.USER);
        repo.save(u);
        return ResponseEntity.ok(Map.of("id", u.getId(), "email", u.getEmail(), "role", u.getRole()));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        User u = repo.findByEmail(req.email()).orElse(null);
        if (u == null || !BCrypt.checkpw(req.password(), u.getPasswordHash())) {
            return ResponseEntity.status(401).body(Map.of("error", "invalid credentials"));
        }
        JwtUtils jwt = new JwtUtils(jwtSecret, 3600);
        String token = jwt.generateToken(u.getId().toString(), Map.of("email", u.getEmail(), "role", u.getRole().name()));
        return ResponseEntity.ok(new TokenResponse(token));
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request) {
        String header = request.getHeader(SecurityConstants.AUTH_HEADER);
        if (header != null && header.startsWith(SecurityConstants.BEARER_PREFIX)) {
            String token = header.substring(SecurityConstants.BEARER_PREFIX.length());
            try {
                JwtUtils jwt = new JwtUtils(jwtSecret, 3600);
                long expMillis = jwt.parse(token).getBody().getExpiration().getTime();
                long nowMillis = System.currentTimeMillis();
                long ttlSeconds = Math.max(1, (expMillis - nowMillis) / 1000);
                blacklistService.blacklist(token, ttlSeconds);
            } catch (Exception ignored) {
                // token invalid or already expired -> nothing to do
            }
        }
        return ResponseEntity.ok(Map.of("message", "logged out"));
    }

    // ==== Change password (requires auth) ====
    @PostMapping("/change-password")
    public ResponseEntity<?> changePassword(Authentication auth, @RequestBody ChangePasswordRequest req) {
        if (auth == null) return ResponseEntity.status(401).body(Map.of("error","unauthorized"));

        return ResponseEntity.of(repo.findById(UUID.fromString(auth.getName())).map(u -> {
            if (!BCrypt.checkpw(req.oldPassword(), u.getPasswordHash())) {
                return Map.of("error", "invalid old password");
            }
            u.setPasswordHash(BCrypt.hashpw(req.newPassword(), BCrypt.gensalt()));
            repo.save(u);
            
            // Send email notification for password change
            rabbit.convertAndSend(
                    exchange,
                    notifyEmailRouting,
                    new Events.NotifyEmail(
                            u.getId(),
                            u.getEmail(),
                            "Password Changed Successfully",
                            "Hi " + (u.getFullName() == null ? "" : u.getFullName()) +
                                    ",\n\nYour password has been changed successfully. " +
                                    "If you did not make this change, please contact support immediately.\n\n" +
                                    "Best regards,\nVehicle Parking Management Team"
                    )
            );
            
            return Map.of("message", "password updated");
        }));
    }


    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody ForgotPasswordRequest req) {
        User u = repo.findByEmail(req.email()).orElse(null);
        // Always 200 (don’t leak existence)
        if (u != null) {
            String token = UUID.randomUUID().toString();
            PasswordResetToken prt = new PasswordResetToken();
            prt.setUserId(u.getId());
            prt.setToken(token);
            prt.setExpiresAt(LocalDateTime.now().plusHours(1));
            resetRepo.save(prt);

            // publish email
            String resetLink = "http://localhost:3000/reset-password?token=" +
                    URLEncoder.encode(token, StandardCharsets.UTF_8);
            rabbit.convertAndSend(
                    exchange,
                    notifyEmailRouting,
                    new Events.NotifyEmail(
                            u.getId(),
                            u.getEmail(),
                            "Password reset",
                            "Hi " + (u.getFullName() == null ? "" : u.getFullName()) +
                                    ",\n\nUse this link to reset your password:\n" + resetLink +
                                    "\n\nIf you didn’t request this, ignore this email."
                    )
            );
        }
        return ResponseEntity.ok(Map.of("message", "If the email exists, a reset link has been sent."));
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody ResetPasswordRequest req) {
        var prtOpt = resetRepo.findByToken(req.token());
        if (prtOpt.isEmpty() || prtOpt.get().getExpiresAt().isBefore(LocalDateTime.now())) {
            prtOpt.ifPresent(resetRepo::delete);
            return ResponseEntity.badRequest().body(Map.of("error", "invalid or expired token"));
        }
        var prt = prtOpt.get();
        var u = repo.findById(prt.getUserId()).orElse(null);
        if (u == null) {
            resetRepo.delete(prt);
            return ResponseEntity.badRequest().body(Map.of("error", "user not found"));
        }
        u.setPasswordHash(BCrypt.hashpw(req.newPassword(), BCrypt.gensalt()));
        repo.save(u);
        resetRepo.delete(prt);

        // optional: confirmation email
        rabbit.convertAndSend(
                exchange,
                notifyEmailRouting,
                new Events.NotifyEmail(
                        u.getId(),
                        u.getEmail(),
                        "Password reset successful",
                        "Hi " + (u.getFullName() == null ? "" : u.getFullName()) +
                                ",\n\nYour password has been reset successfully."
                )
        );

        return ResponseEntity.ok(Map.of("message", "password reset successful"));
    }
//    // ==== Forgot / Reset password (anonymous) ====
//    @PostMapping("/forgot-password")
//    public ResponseEntity<?> forgotPassword(@RequestBody ForgotPasswordRequest req) {
//        User u = repo.findByEmail(req.email()).orElse(null);
//        // Don't leak user existence
//        if (u == null) {
//            return ResponseEntity.ok(Map.of("message", "If the email exists, a reset token has been generated"));
//        }
//        String token = UUID.randomUUID().toString();
//        PasswordResetToken prt = new PasswordResetToken();
//        prt.setUserId(u.getId());
//        prt.setToken(token);
//        prt.setExpiresAt(LocalDateTime.now().plusHours(1));
//        resetRepo.save(prt);
//
//        // TODO: call Notification service to email a reset link containing the token.
//        return ResponseEntity.ok(Map.of("message", "If the email exists, a reset token has been generated"));
//    }
//
//    @PostMapping("/reset-password")
//    public ResponseEntity<?> resetPassword(@RequestBody ResetPasswordRequest req) {
//        var prtOpt = resetRepo.findByToken(req.token());
//        if (prtOpt.isEmpty()) {
//            return ResponseEntity.badRequest().body(Map.of("error", "invalid or expired token"));
//        }
//        PasswordResetToken prt = prtOpt.get();
//        if (prt.getExpiresAt().isBefore(LocalDateTime.now())) {
//            resetRepo.delete(prt);
//            return ResponseEntity.badRequest().body(Map.of("error", "invalid or expired token"));
//        }
//        User u = repo.findById(prt.getUserId()).orElse(null);
//        if (u == null) {
//            resetRepo.delete(prt);
//            return ResponseEntity.badRequest().body(Map.of("error", "user not found"));
//        }
//        u.setPasswordHash(BCrypt.hashpw(req.newPassword(), BCrypt.gensalt()));
//        repo.save(u);
//        resetRepo.delete(prt);
//        return ResponseEntity.ok(Map.of("message", "password reset successful"));
//    }
}
