package com.hashedin.parking.user.web;

import com.hashedin.parking.user.cache.ProfileCache;
import com.hashedin.parking.user.repo.UserRepo;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserRepo repo;

    private final ProfileCache cache;
    private final RabbitTemplate rabbit;
    private final String exchange;
    private final String userProfileUpdatedRouting;

    public UserController(UserRepo repo,
                          ProfileCache cache,
                          RabbitTemplate rabbit,
                          @Value("${app.rabbit.exchange}") String exchange,
                          @Value("${app.rabbit.routing.userProfileUpdated}") String userProfileUpdatedRouting) {
        this.repo = repo;
        this.cache = cache;
        this.rabbit = rabbit;
        this.exchange = exchange;
        this.userProfileUpdatedRouting = userProfileUpdatedRouting;
    }

    public record UpdateProfile( String fullName, @Email String email) {}

//    @GetMapping("/me")
//    public ResponseEntity<?> me(Authentication auth) {
//        UUID id = UUID.fromString(auth.getName());
//        return ResponseEntity.of(repo.findById(id).map(u -> Map.of("id", u.getId(), "email", u.getEmail(), "fullName", u.getFullName(), "role", u.getRole())));
//    }

//    @PutMapping("/me")
//    public ResponseEntity<?> update(Authentication auth, @RequestBody UpdateProfile req) {
//        UUID id = UUID.fromString(auth.getName());
//        return ResponseEntity.of(repo.findById(id).map(u -> {
//            u.setFullName(req.fullName());
//            repo.save(u);
//            return Map.of("message","updated");
//        }));
//    }

    @GetMapping("/me")
    public ResponseEntity<?> me(Authentication auth) {
        String uid = auth.getName();

        // cache first
        Map<String, Object> cached = cache.get(uid);
        if (cached != null) {
            return ResponseEntity.ok(cached);
        }

        return ResponseEntity.of(repo.findById(UUID.fromString(uid)).map(u -> {
            Map<String, Object> profile = new HashMap<>();
            profile.put("id", u.getId());
            profile.put("email", u.getEmail());
            profile.put("fullName", u.getFullName());          // may be null
            profile.put("role", u.getRole());                   // or u.getRole().name()
            profile.put("bookingCount", u.getBookingCount());   // may be null if DB default didn’t set
            profile.put("lastBookingAt", u.getLastBookingAt()); // may be null
            cache.put(uid, profile, Duration.ofMinutes(10));
            return profile;
        }));

    }


    @GetMapping("/test-role")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> testUserRole(Authentication auth) {
        return ResponseEntity.ok(Map.of(
            "message", "This endpoint is only accessible to USER role",
            "user", auth.getName(),
            "authorities", auth.getAuthorities()
        ));
    }

    @PutMapping("/me")
    public ResponseEntity<?> update(Authentication auth, @RequestBody @Valid UpdateProfile req) {
        UUID id = UUID.fromString(auth.getName());
        return ResponseEntity.of(repo.findById(id).map(u -> {
            boolean changed = false;

            if (req.fullName() != null && !req.fullName().isBlank()) {
                u.setFullName(req.fullName());
                changed = true;
            }

            if (req.email() != null && !req.email().isBlank() && !req.email().equalsIgnoreCase(u.getEmail())) {
                var existing = repo.findByEmail(req.email());
                if (existing.isPresent() && !existing.get().getId().equals(u.getId())) {
                    return Map.of("error", "email already in use");
                }
                u.setEmail(req.email());
                changed = true;
            }

            if (changed) {
                repo.save(u);
                
                // Update cache with new profile data
                Map<String, Object> profile = new HashMap<>();
                profile.put("id", u.getId());
                profile.put("email", u.getEmail());
                profile.put("fullName", u.getFullName());
                profile.put("role", u.getRole());
                profile.put("bookingCount", u.getBookingCount());
                profile.put("lastBookingAt", u.getLastBookingAt());
                
                try {
                    cache.put(u.getId().toString(), profile, Duration.ofMinutes(10));
                } catch (Exception e) {
                    // Log cache error but don't fail the update
                    System.err.println("Failed to update profile cache: " + e.getMessage());
                }

                // publish profile-updated event (as generic JSON payload for cross-service compatibility)
                Map<String, Object> eventPayload = new HashMap<>();
                eventPayload.put("userId", u.getId().toString());
                eventPayload.put("email", u.getEmail());
                eventPayload.put("fullName", u.getFullName()); // safe even if null
                
                try {
                    rabbit.convertAndSend(exchange, userProfileUpdatedRouting, eventPayload);
                } catch (Exception e) {
                    // Log error but don't fail the profile update
                    System.err.println("Failed to publish profile update event: " + e.getMessage());
                }

            }
            return Map.of("message", "updated");
        }));
    }

}
