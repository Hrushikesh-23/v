package com.hashedin.parking.common.dto;

import java.time.LocalDateTime;
import java.util.UUID;

public class BookingDtos {
    public record CreateBookingRequest(UUID userId, Long lotId, Long spotId,
                                       LocalDateTime startTime, LocalDateTime endTime) {}
    public record BookingResponse(UUID id, UUID userId, Long lotId, Long spotId,
                                  String status, LocalDateTime startTime, LocalDateTime endTime) {}
}
