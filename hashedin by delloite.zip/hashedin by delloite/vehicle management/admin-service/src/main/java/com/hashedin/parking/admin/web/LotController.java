package com.hashedin.parking.admin.web;

import com.hashedin.parking.admin.model.ParkingLot;
import com.hashedin.parking.admin.model.ParkingSpot;
import com.hashedin.parking.admin.repo.LotRepo;
import com.hashedin.parking.admin.repo.SpotRepo;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/lots")
public class LotController {

    private final LotRepo lots;
    private final SpotRepo spots;

    public LotController(LotRepo lots, SpotRepo spots) {
        this.lots = lots; this.spots = spots;
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public List<ParkingLot> all() { 
        return lots.findAll(); 
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ParkingLot create(@RequestBody ParkingLot lot) { 
        return lots.save(lot); 
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> update(@PathVariable("id") Long id, @RequestBody ParkingLot lot) {
        return ResponseEntity.of(lots.findById(id).map(existing -> {
            existing.setName(lot.getName());
            existing.setAddress(lot.getAddress());
            return lots.save(existing);
        }));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> delete(@PathVariable("id") Long id) {
        if (lots.existsById(id)) {
            lots.deleteById(id);
            return ResponseEntity.ok(Map.of("message", "Lot deleted successfully"));
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/{id}/spots")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public ResponseEntity<?> addSpot(@PathVariable("id") Long id, @RequestBody ParkingSpot spot) {
        return ResponseEntity.of(lots.findById(id).map(l -> {
            spot.setLot(l);
            spots.save(spot);
            return Map.of("message","spot added");
        }));
    }

    @PutMapping("/{lotId}/spots/{spotId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public ResponseEntity<?> updateSpot(@PathVariable("lotId") Long lotId, 
                                       @PathVariable("spotId") Long spotId, 
                                       @RequestBody ParkingSpot spot) {
        return ResponseEntity.of(spots.findById(spotId).map(existing -> {
            if (existing.getLot().getId().equals(lotId)) {
                existing.setCode(spot.getCode());
                existing.setAvailable(spot.isAvailable());
                return spots.save(existing);
            }
            return null;
        }));
    }

    @DeleteMapping("/{lotId}/spots/{spotId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteSpot(@PathVariable("lotId") Long lotId, 
                                       @PathVariable("spotId") Long spotId) {
        return ResponseEntity.of(spots.findById(spotId).map(spot -> {
            if (spot.getLot().getId().equals(lotId)) {
                spots.deleteById(spotId);
                return Map.of("message", "Spot deleted successfully");
            }
            return null;
        }));
    }

    @GetMapping("/{id}/spots")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public List<ParkingSpot> available(@PathVariable("id") Long id) {
        return spots.findByLotIdAndAvailableTrue(id);
    }

    @GetMapping("/{id}/spots/all")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public List<ParkingSpot> allSpots(@PathVariable("id") Long id) {
        return spots.findByLotId(id);
    }
}