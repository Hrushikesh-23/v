package com.hashedin.parking.admin.repo;

import com.hashedin.parking.admin.model.ParkingSpot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SpotRepo extends JpaRepository<ParkingSpot, Long> {
    List<ParkingSpot> findByLotIdAndAvailableTrue(Long lotId);
    List<ParkingSpot> findByLotId(Long lotId);
}
