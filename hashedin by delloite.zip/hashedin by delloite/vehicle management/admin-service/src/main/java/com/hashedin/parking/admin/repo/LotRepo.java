package com.hashedin.parking.admin.repo;

import com.hashedin.parking.admin.model.ParkingLot;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LotRepo extends JpaRepository<ParkingLot, Long> {}
