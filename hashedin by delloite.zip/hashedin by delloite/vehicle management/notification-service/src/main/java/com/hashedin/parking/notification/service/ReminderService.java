package com.hashedin.parking.notification.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

@Service
public class ReminderService {
    private static final Logger log = LoggerFactory.getLogger(ReminderService.class);
    
    private final RabbitTemplate rabbitTemplate;
    private final String exchange;
    private final String notifyEmailRouting;
    
    public ReminderService(RabbitTemplate rabbitTemplate,
                          @Value("${app.rabbit.exchange}") String exchange,
                          @Value("${app.rabbit.routing.notifyEmail}") String notifyEmailRouting) {
        this.rabbitTemplate = rabbitTemplate;
        this.exchange = exchange;
        this.notifyEmailRouting = notifyEmailRouting;
    }
    
    public void sendBookingReminder(String userEmail, String bookingId, LocalDateTime startTime, String spotId) {
        try {
            String formattedTime = startTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
            String subject = "Upcoming Parking Reservation Reminder";
            String body = String.format(
                "Hello,\n\n" +
                "This is a reminder about your upcoming parking reservation:\n\n" +
                "Booking ID: %s\n" +
                "Spot ID: %s\n" +
                "Start Time: %s\n\n" +
                "Please arrive on time for your reservation.\n\n" +
                "Best regards,\n" +
                "Vehicle Parking Management Team",
                bookingId, spotId, formattedTime
            );
            
            // Send reminder via RabbitMQ
            rabbitTemplate.convertAndSend(
                exchange,
                notifyEmailRouting,
                Map.of(
                    "userId", "system",
                    "toEmail", userEmail,
                    "subject", subject,
                    "body", body
                )
            );
            
            log.info("Sent booking reminder for booking {} to {}", bookingId, userEmail);
        } catch (Exception e) {
            log.error("Failed to send booking reminder for booking {}: {}", bookingId, e.getMessage());
        }
    }
    
    public void sendPaymentReminder(String userEmail, String paymentId, String amount) {
        try {
            String subject = "Payment Reminder - Parking Booking";
            String body = String.format(
                "Hello,\n\n" +
                "This is a reminder about your pending payment:\n\n" +
                "Payment ID: %s\n" +
                "Amount: $%s\n\n" +
                "Please complete your payment to confirm your parking reservation.\n\n" +
                "Best regards,\n" +
                "Vehicle Parking Management Team",
                paymentId, amount
            );
            
            // Send reminder via RabbitMQ
            rabbitTemplate.convertAndSend(
                exchange,
                notifyEmailRouting,
                Map.of(
                    "userId", "system",
                    "toEmail", userEmail,
                    "subject", subject,
                    "body", body
                )
            );
            
            log.info("Sent payment reminder for payment {} to {}", paymentId, userEmail);
        } catch (Exception e) {
            log.error("Failed to send payment reminder for payment {}: {}", paymentId, e.getMessage());
        }
    }
}
