package com.hashedin.parking.notification.mq;

import com.hashedin.parking.common.events.Events;
import com.hashedin.parking.notification.service.EmailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class Listeners {
    private static final Logger log = LoggerFactory.getLogger(Listeners.class);
    private final EmailService email;

    public Listeners(EmailService email) {
        this.email = email;
    }

    @RabbitListener(queues = "${app.rabbit.queues.notificationService.bookingCreated}")
    public void onBookingCreated(Events.BookingCreated ev) {
        log.info("Received BookingCreated {}", ev);
        // Note: Using hardcoded email for demo purposes. In production, you'd get user email from user service
        email.send("hrushikeshpathrabe23@gmail.com",
                "Booking Created",
                "Your booking " + ev.bookingId() + " is created.");
    }

    @RabbitListener(queues = "${app.rabbit.queues.notificationService.paymentStatus}")
    public void onPaymentStatus(Events.PaymentStatusChanged ev) {
        log.info("Received PaymentStatusChanged {}", ev);
        // Note: Using hardcoded email for demo purposes. In production, you'd get user email from user service
        email.send("hrushikeshpathrabe23@gmail.com",
                "Payment " + ev.status(),
                "Payment " + ev.paymentId() + " is " + ev.status());
    }

    @RabbitListener(queues = "${app.rabbit.queues.notificationService.notifyEmail}")
    public void onNotifyEmail(Events.NotifyEmail ev) {
        log.info("Received NotifyEmail for user {} to {}", ev.userId(), ev.toEmail());
        email.send(ev.toEmail(), ev.subject(), ev.body());
    }
}
