package com.hashedin.parking.notification.web;

import com.hashedin.parking.notification.service.EmailService;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    private final EmailService email;

    public NotificationController(EmailService email) { this.email = email; }

    public record EmailReq(@Email String to, @NotBlank String subject, @NotBlank String body) {}

    @PostMapping("/email")
    public Map<String, String> send(@RequestBody EmailReq req) {
        email.send(req.to(), req.subject(), req.body());
        return Map.of("message","sent");
    }

    @GetMapping("/status")
    public Map<String, Object> getStatus() {
        return Map.of(
            "service", "Notification Service",
            "status", "RUNNING",
            "features", Map.of(
                "emailNotifications", true,
                "eventDrivenMessaging", true,
                "scheduledReminders", true,
                "deliveryTracking", "Logs Only (No Database)"
            ),
            "endpoints", Map.of(
                "sendEmail", "POST /api/notifications/email",
                "getStatus", "GET /api/notifications/status"
            )
        );
    }
}
