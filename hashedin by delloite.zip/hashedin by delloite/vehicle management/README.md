# Vehicle Parking Management (Microservices, Java 21) — No Docker

Spring Boot microservices for a Vehicle Parking Management system.

- **Services:** discovery-service (8761), api-gateway (8080), user-service (8081), admin-service (8082), booking-service (8083), payment-service (8084), notification-service (8085)
- **Infra (install locally):** MySQL 8.x, Redis 7.x, RabbitMQ 4.x (Erlang 28.x), SMTP (optional)

## Setup
1) Ensure MySQL, Redis, RabbitMQ are running locally.
2) In each service `application.yml`, set your MySQL username/password if not root/root.
3) Start services in this order:
   - discovery-service
   - api-gateway
   - user-service, admin-service, booking-service, payment-service, notification-service

## Swagger
- http://localhost:8081/swagger-ui.html
- http://localhost:8082/swagger-ui.html
- http://localhost:8083/swagger-ui.html
- http://localhost:8084/swagger-ui.html
- http://localhost:8085/swagger-ui.html

## Sample Flow
1. Register & login to get JWT (user-service).
2. Create lot & spot (admin-service with ADMIN/LOT_MANAGER).
3. Create booking (booking-service) → emits events.
4. Payment auto-creates PENDING on booking; confirm payment to emit status.
5. Notification service emails/logs on events.

Schedulers:
- Booking: expire old CREATED bookings (15 min)
- Payment: expire PENDING > 2h (30 min)
- Admin: hourly occupancy report (log)
- Notification: daily 9AM reminder stub
