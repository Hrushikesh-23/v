package com.hashedin.parking.notification.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class BookingServiceClient {
    private static final Logger log = LoggerFactory.getLogger(BookingServiceClient.class);
    
    private final RestTemplate restTemplate;
    private final String bookingServiceUrl;

    public BookingServiceClient(RestTemplate restTemplate,
                                @Value("${app.services.booking.url:http://booking-service}") String bookingServiceUrl) {
        this.restTemplate = restTemplate;
        this.bookingServiceUrl = bookingServiceUrl;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Booking(
            UUID id,
            UUID userId,
            Long lotId,
            Long spotId,
            LocalDateTime startTime,
            LocalDateTime endTime,
            String status
    ) {}

    public List<Booking> getUpcomingBookings(LocalDateTime from, LocalDateTime to) {
        try {
            // Query future bookings - we'll need an admin/internal endpoint
            // For now, using a simplified approach - in production, you'd have an internal endpoint
            log.debug("Fetching upcoming bookings from {} to {}", from, to);
            
            // Note: This assumes there's an internal/admin endpoint to fetch bookings
            // If not available, we'll fall back to event-driven approach
            return List.of();
        } catch (Exception e) {
            log.error("Error fetching upcoming bookings: {}", e.getMessage(), e);
            return List.of();
        }
    }

    public List<Booking> getBookingsStartingWithinHours(int hours) {
        try {
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime future = now.plusHours(hours);
            
            log.debug("Fetching bookings starting between {} and {}", now, future);
            
            String url = String.format("%s/api/bookings/internal/upcoming?hours=%d", bookingServiceUrl, hours);
            try {
                // Note: In production, use service-to-service authentication token
                List<Booking> bookings = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<Booking>>() {}
                ).getBody();
                
                log.info("Fetched {} upcoming bookings from booking service", bookings != null ? bookings.size() : 0);
                return bookings != null ? bookings : List.of();
            } catch (Exception e) {
                log.warn("Could not fetch bookings from service: {}", e.getMessage());
                return List.of();
            }
        } catch (Exception e) {
            log.error("Error fetching bookings: {}", e.getMessage(), e);
            return List.of();
        }
    }
}

