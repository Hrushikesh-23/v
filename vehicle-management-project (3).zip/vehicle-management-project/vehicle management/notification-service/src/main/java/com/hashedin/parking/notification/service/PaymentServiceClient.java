package com.hashedin.parking.notification.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class PaymentServiceClient {
    private static final Logger log = LoggerFactory.getLogger(PaymentServiceClient.class);
    
    private final RestTemplate restTemplate;
    private final String paymentServiceUrl;

    public PaymentServiceClient(RestTemplate restTemplate,
                                @Value("${app.services.payment.url:http://payment-service}") String paymentServiceUrl) {
        this.restTemplate = restTemplate;
        this.paymentServiceUrl = paymentServiceUrl;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Payment(
            UUID id,
            UUID userId,
            UUID bookingId,
            BigDecimal amount,
            String status,
            LocalDateTime createdAt
    ) {}

    public List<Payment> getPendingPaymentsOlderThanHours(int hours) {
        try {
            log.debug("Fetching pending payments older than {} hours", hours);
            
            String url = String.format("%s/api/payments/internal/pending?olderThanHours=%d", paymentServiceUrl, hours);
            try {
                // Note: In production, use service-to-service authentication token
                List<Payment> payments = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<Payment>>() {}
                ).getBody();
                
                log.info("Fetched {} pending payments from payment service", payments != null ? payments.size() : 0);
                return payments != null ? payments : List.of();
            } catch (Exception e) {
                log.warn("Could not fetch payments from service: {}", e.getMessage());
                return List.of();
            }
        } catch (Exception e) {
            log.error("Error fetching pending payments: {}", e.getMessage(), e);
            return List.of();
        }
    }
}

