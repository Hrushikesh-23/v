package com.hashedin.parking.notification.web;

import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hashedin.parking.notification.service.NotificationService;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) { 
        this.notificationService = notificationService; 
    }

    public record SendEmailRequest(@Email String to, @NotBlank String subject, @NotBlank String body) {}

    @PostMapping("/email")
    public Map<String, String> sendEmailNotification(@RequestBody SendEmailRequest req) {
        return notificationService.sendEmail(req.to(), req.subject(), req.body());
    }

    @GetMapping("/status")
    public Map<String, Object> getNotificationServiceStatus() {
        return notificationService.getServiceStatus();
    }
}
