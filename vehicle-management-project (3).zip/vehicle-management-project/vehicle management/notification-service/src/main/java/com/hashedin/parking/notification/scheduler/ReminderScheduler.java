package com.hashedin.parking.notification.scheduler;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hashedin.parking.notification.service.BookingServiceClient;
import com.hashedin.parking.notification.service.PaymentServiceClient;
import com.hashedin.parking.notification.service.ReminderService;
import com.hashedin.parking.notification.service.UserServiceClient;

@Component
public class ReminderScheduler {
    private static final Logger log = LoggerFactory.getLogger(ReminderScheduler.class);
    private final ReminderService reminderService;
    private final BookingServiceClient bookingServiceClient;
    private final PaymentServiceClient paymentServiceClient;
    private final UserServiceClient userServiceClient;

    public ReminderScheduler(ReminderService reminderService,
                             BookingServiceClient bookingServiceClient,
                             PaymentServiceClient paymentServiceClient,
                             UserServiceClient userServiceClient) {
        this.reminderService = reminderService;
        this.bookingServiceClient = bookingServiceClient;
        this.paymentServiceClient = paymentServiceClient;
        this.userServiceClient = userServiceClient;
    }

    // Send reminders for bookings starting in the next 24 hours (runs every 6 hours)
    @Scheduled(cron = "0 0 */6 * * *")
    public void sendBookingReminders() {
        log.info("Running booking reminder scheduler...");
        
        try {
            // Fetch bookings starting within next 24 hours
            List<BookingServiceClient.Booking> upcomingBookings = bookingServiceClient.getBookingsStartingWithinHours(24);
            
            if (upcomingBookings.isEmpty()) {
                log.info("No upcoming bookings found for reminders");
                return;
            }
            
            log.info("Found {} upcoming bookings, sending reminders...", upcomingBookings.size());
            
            int sentCount = 0;
            for (BookingServiceClient.Booking booking : upcomingBookings) {
                try {
                    // Get user email
                    String userEmail = userServiceClient.getUserEmail(booking.userId());
                    
                    if (userEmail == null || userEmail.isEmpty()) {
                        log.warn("Could not fetch email for user {}, skipping reminder", booking.userId());
                        continue;
                    }
                    
                    // Send reminder
                    reminderService.sendBookingReminder(
                        userEmail,
                        booking.id().toString(),
                        booking.startTime(),
                        booking.spotId().toString()
                    );
                    sentCount++;
                    log.debug("Sent booking reminder to {} for booking {}", userEmail, booking.id());
                } catch (Exception e) {
                    log.error("Error sending reminder for booking {}: {}", booking.id(), e.getMessage());
                }
            }
            
            log.info("Successfully sent {} booking reminders out of {} bookings", sentCount, upcomingBookings.size());
        } catch (Exception e) {
            log.error("Error in booking reminder scheduler: {}", e.getMessage(), e);
        }
    }

    // Send payment reminders for pending payments (runs every 12 hours)
    @Scheduled(cron = "0 0 */12 * * *")
    public void sendPaymentReminders() {
        log.info("Running payment reminder scheduler...");
        
        try {
            // Fetch pending payments older than 1 hour
            List<PaymentServiceClient.Payment> pendingPayments = paymentServiceClient.getPendingPaymentsOlderThanHours(1);
            
            if (pendingPayments.isEmpty()) {
                log.info("No pending payments found for reminders");
                return;
            }
            
            log.info("Found {} pending payments, sending reminders...", pendingPayments.size());
            
            int sentCount = 0;
            for (PaymentServiceClient.Payment payment : pendingPayments) {
                try {
                    // Get user email
                    String userEmail = userServiceClient.getUserEmail(payment.userId());
                    
                    if (userEmail == null || userEmail.isEmpty()) {
                        log.warn("Could not fetch email for user {}, skipping payment reminder", payment.userId());
                        continue;
                    }
                    
                    // Send reminder
                    reminderService.sendPaymentReminder(
                        userEmail,
                        payment.id().toString(),
                        payment.amount().toString()
                    );
                    sentCount++;
                    log.debug("Sent payment reminder to {} for payment {}", userEmail, payment.id());
                } catch (Exception e) {
                    log.error("Error sending payment reminder for payment {}: {}", payment.id(), e.getMessage());
                }
            }
            
            log.info("Successfully sent {} payment reminders out of {} pending payments", sentCount, pendingPayments.size());
        } catch (Exception e) {
            log.error("Error in payment reminder scheduler: {}", e.getMessage(), e);
        }
    }

    // Send daily summary (runs at 9 AM every day)
    @Scheduled(cron = "0 0 9 * * *")
    public void sendDailySummary() {
        log.info("Running daily summary scheduler...");
        
        // In a real implementation, you would:
        // 1. Query all services for user activity
        // 2. Send daily summary emails to users
        
        log.info("Daily summary scheduler completed (placeholder implementation)");
    }
}
