package com.hashedin.parking.notification.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;

@Configuration
@EnableRabbit
public class RabbitConfig {

    @Value("${app.rabbit.exchange}")
    private String exchange;

    @Value("${app.rabbit.queues.notificationService.bookingCreated}")
    private String bookingCreatedQueue;

    @Value("${app.rabbit.queues.notificationService.paymentStatus}")
    private String paymentStatusQueue;

    @Value("${app.rabbit.queues.notificationService.notifyEmail}")
    private String notifyEmailQueue;

    @Value("${app.rabbit.routing.bookingCreated}")
    private String bookingCreatedRouting;

    @Value("${app.rabbit.routing.paymentStatus}")
    private String paymentStatusRouting;

    @Value("${app.rabbit.routing.notifyEmail}")
    private String notifyEmailRouting;

    // Use TOPIC (matches your other services)
    @Bean
    public TopicExchange bookingExchange() {
        return new TopicExchange(exchange, true, false);
    }

    @Bean public Queue notificationBookingCreatedQueue() { return new Queue(bookingCreatedQueue, true); }
    @Bean public Queue notificationPaymentStatusQueue() { return new Queue(paymentStatusQueue, true); }
    @Bean public Queue notificationNotifyEmailQueue() { return new Queue(notifyEmailQueue, true); }

    @Bean
    public Binding bookingCreatedBinding() {
        return BindingBuilder.bind(notificationBookingCreatedQueue())
                .to(bookingExchange()).with(bookingCreatedRouting);
    }

    @Bean
    public Binding paymentStatusBinding() {
        return BindingBuilder.bind(notificationPaymentStatusQueue())
                .to(bookingExchange()).with(paymentStatusRouting);
    }

    @Bean
    public Binding notifyEmailBinding() {
        return BindingBuilder.bind(notificationNotifyEmailQueue())
                .to(bookingExchange()).with(notifyEmailRouting);
    }

    // --- JSON converter + factories (IMPORTANT) ---

    @Bean
    public Jackson2JsonMessageConverter jacksonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    // This exact bean name is the default used by @RabbitListener
    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
            ConnectionFactory cf, Jackson2JsonMessageConverter converter) {
        SimpleRabbitListenerContainerFactory f = new SimpleRabbitListenerContainerFactory();
        f.setConnectionFactory(cf);
        f.setMessageConverter(converter);
        return f;
    }

    // Optional: if you ever publish messages from this service
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory cf, Jackson2JsonMessageConverter converter) {
        RabbitTemplate rt = new RabbitTemplate(cf);
        rt.setMessageConverter(converter);
        return rt;
    }
}
