package com.hashedin.parking.notification.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

@Service
public class UserServiceClient {
    private static final Logger log = LoggerFactory.getLogger(UserServiceClient.class);
    
    private final RestTemplate restTemplate;
    private final String userServiceUrl;

    public UserServiceClient(RestTemplate restTemplate,
                             @Value("${app.services.user.url:http://user-service}") String userServiceUrl) {
        this.restTemplate = restTemplate;
        this.userServiceUrl = userServiceUrl;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record UserProfile(
            UUID id,
            String email,
            String fullName
    ) {}

    public String getUserEmail(UUID userId) {
        try {
            String url = String.format("%s/api/users/internal/%s/email", userServiceUrl, userId);
            try {
                String email = restTemplate.getForObject(url, String.class);
                return email != null ? email : null;
            } catch (Exception e) {
                log.warn("Could not fetch user email (may need internal endpoint): {}", e.getMessage());
                return null;
            }
        } catch (Exception e) {
            log.error("Error fetching user email for user {}: {}", userId, e.getMessage(), e);
            return null;
        }
    }
}

