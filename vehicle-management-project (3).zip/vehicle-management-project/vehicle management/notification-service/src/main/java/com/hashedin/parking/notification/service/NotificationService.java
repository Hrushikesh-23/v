package com.hashedin.parking.notification.service;

import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    private final EmailService emailService;
    private final ReminderService reminderService;

    public NotificationService(EmailService emailService, ReminderService reminderService) {
        this.emailService = emailService;
        this.reminderService = reminderService;
    }

    public Map<String, String> sendEmail(String to, String subject, String body) {
        emailService.send(to, subject, body);
        return Map.of("message", "sent");
    }

    public Map<String, Object> getServiceStatus() {
        return Map.of(
            "service", "Notification Service",
            "status", "RUNNING",
            "features", Map.of(
                "emailNotifications", true,
                "eventDrivenMessaging", true,
                "scheduledReminders", true,
                "deliveryTracking", "Logs Only (No Database)"
            ),
            "endpoints", Map.of(
                "sendEmail", "POST /api/notifications/email",
                "getStatus", "GET /api/notifications/status"
            )
        );
    }

    public void processBookingCreated(String bookingId, String userId, String lotId, 
                                    String spotId, String startTime, String endTime) {
        // Process booking created notification
        String subject = "Booking Confirmed";
        String body = String.format(
            "Your parking booking has been confirmed.\n" +
            "Booking ID: %s\n" +
            "Spot: %s\n" +
            "Time: %s to %s\n" +
            "Thank you for using our service!",
            bookingId, spotId, startTime, endTime
        );
        
        // In a real implementation, you would get user email from user service
        // For now, we'll just log it
        System.out.println("Sending booking confirmation email to user: " + userId);
        System.out.println("Subject: " + subject);
        System.out.println("Body: " + body);
    }

    public void processBookingCancelled(String bookingId, String userId) {
        // Process booking cancelled notification
        String subject = "Booking Cancelled";
        String body = String.format(
            "Your parking booking has been cancelled.\n" +
            "Booking ID: %s\n" +
            "If you have any questions, please contact support.",
            bookingId
        );
        
        System.out.println("Sending booking cancellation email to user: " + userId);
        System.out.println("Subject: " + subject);
        System.out.println("Body: " + body);
    }

    public void processPaymentStatusChanged(String paymentId, String bookingId, String userId, 
                                          String amount, String status) {
        // Process payment status notification
        String subject = "Payment " + status;
        String body = String.format(
            "Your payment has been %s.\n" +
            "Payment ID: %s\n" +
            "Booking ID: %s\n" +
            "Amount: %s\n" +
            "Status: %s",
            status.toLowerCase(), paymentId, bookingId, amount, status
        );
        
        System.out.println("Sending payment status email to user: " + userId);
        System.out.println("Subject: " + subject);
        System.out.println("Body: " + body);
    }

    public void processUserProfileUpdated(String userId, String email, String fullName, String role) {
        // Process profile update notification
        String subject = "Profile Updated";
        String body = String.format(
            "Your profile has been successfully updated.\n" +
            "Name: %s\n" +
            "Email: %s\n" +
            "Role: %s\n" +
            "If you did not make this change, please contact support immediately.",
            fullName, email, role
        );
        
        System.out.println("Sending profile update email to user: " + userId);
        System.out.println("Subject: " + subject);
        System.out.println("Body: " + body);
    }

    public void processNotifyEmail(String userId, String toEmail, String subject, String body) {
        // Process general email notification
        emailService.send(toEmail, subject, body);
        System.out.println("Email sent to: " + toEmail + " for user: " + userId);
    }
}


