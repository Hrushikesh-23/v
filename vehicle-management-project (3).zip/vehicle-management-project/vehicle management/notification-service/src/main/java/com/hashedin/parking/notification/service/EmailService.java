package com.hashedin.parking.notification.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@Service
public class EmailService {
    private static final Logger log = LoggerFactory.getLogger(EmailService.class);
    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) { this.mailSender = mailSender; }

    public void send(String to, String subject, String body) {
        String notificationId = UUID.randomUUID().toString();
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        
        try {
            // Log notification attempt
            log.info("NOTIFICATION_TRACKING: ID={}, TO={}, SUBJECT={}, STATUS=ATTEMPTING, TIMESTAMP={}", 
                    notificationId, to, subject, timestamp);
            
            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setTo(to);
            msg.setSubject(subject);
            msg.setText(body);
            mailSender.send(msg);
            
            // Log successful delivery
            log.info("NOTIFICATION_TRACKING: ID={}, TO={}, SUBJECT={}, STATUS=DELIVERED, TIMESTAMP={}", 
                    notificationId, to, subject, timestamp);
            
        } catch (Exception e) {
            // Log failed delivery
            log.error("NOTIFICATION_TRACKING: ID={}, TO={}, SUBJECT={}, STATUS=FAILED, ERROR={}, TIMESTAMP={}", 
                    notificationId, to, subject, e.getMessage(), timestamp);
        }
    }
//
//    // Method to get notification history (logs only, no database)
//    public void logNotificationHistory() {
//        log.info("NOTIFICATION_HISTORY: Service provides delivery tracking via logs only (no database storage)");
//        log.info("NOTIFICATION_HISTORY: All email attempts, successes, and failures are logged with unique IDs");
//        log.info("NOTIFICATION_HISTORY: Log format: NOTIFICATION_TRACKING: ID=<uuid>, TO=<email>, SUBJECT=<subject>, STATUS=<status>, TIMESTAMP=<timestamp>");
//    }
}
