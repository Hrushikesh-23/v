# Vehicle Parking Management System - Architecture Diagrams

## Diagram 1: Services and Databases Architecture

### Mermaid Code (for Mermaid Live Editor / GitHub)

```mermaid
graph TB
    subgraph "Client Layer"
        CLIENT[Client Applications]
    end
    
    subgraph "Gateway Layer"
        GATEWAY[API Gateway<br/>Port: 8080]
    end
    
    subgraph "Service Discovery"
        EUREKA[Eureka Server<br/>Port: 8761]
    end
    
    subgraph "Microservices Layer"
        USER_SVC[User Service<br/>Port: 8081]
        ADMIN_SVC[Admin Service<br/>Port: 8082]
        BOOKING_SVC[Booking Service<br/>Port: 8083]
        PAYMENT_SVC[Payment Service<br/>Port: 8084]
        NOTIF_SVC[Notification Service<br/>Port: 8085]
    end
    
    subgraph "Database Layer"
        USER_DB[(user_service<br/>MySQL)]
        ADMIN_DB[(admin_service<br/>MySQL)]
        BOOKING_DB[(booking_service<br/>MySQL)]
        PAYMENT_DB[(payment_service<br/>MySQL)]
        NOTIF_DB[(notification_service<br/>MySQL)]
    end
    
    subgraph "Infrastructure Layer"
        REDIS[(Redis Cache<br/>Port: 6379)]
        RABBITMQ[RabbitMQ<br/>Port: 5672]
    end
    
    CLIENT -->|HTTPS Requests| GATEWAY
    GATEWAY -->|Route Discovery| EUREKA
    GATEWAY -->|/api/auth/**<br/>/api/users/**| USER_SVC
    GATEWAY -->|/api/lots/**<br/>/api/admin/**| ADMIN_SVC
    GATEWAY -->|/api/bookings/**| BOOKING_SVC
    GATEWAY -->|/api/payments/**| PAYMENT_SVC
    GATEWAY -->|/api/notifications/**| NOTIF_SVC
    
    USER_SVC -->|Register| EUREKA
    ADMIN_SVC -->|Register| EUREKA
    BOOKING_SVC -->|Register| EUREKA
    PAYMENT_SVC -->|Register| EUREKA
    NOTIF_SVC -->|Register| EUREKA
    
    USER_SVC -->|Read/Write| USER_DB
    USER_SVC -->|Cache| REDIS
    
    ADMIN_SVC -->|Read/Write| ADMIN_DB
    ADMIN_SVC -->|Service Calls| BOOKING_SVC
    ADMIN_SVC -->|Service Calls| PAYMENT_SVC
    
    BOOKING_SVC -->|Read/Write| BOOKING_DB
    BOOKING_SVC -->|Cache| REDIS
    BOOKING_SVC -->|Events| RABBITMQ
    BOOKING_SVC -->|Service Calls| USER_SVC
    
    PAYMENT_SVC -->|Read/Write| PAYMENT_DB
    PAYMENT_SVC -->|Cache| REDIS
    PAYMENT_SVC -->|Events| RABBITMQ
    
    NOTIF_SVC -->|Read/Write| NOTIF_DB
    NOTIF_SVC -->|Events| RABBITMQ
    NOTIF_SVC -->|Service Calls| USER_SVC
    NOTIF_SVC -->|Service Calls| BOOKING_SVC
    NOTIF_SVC -->|Service Calls| PAYMENT_SVC
    
    RABBITMQ -.->|booking.created| BOOKING_SVC
    RABBITMQ -.->|payment.status| BOOKING_SVC
    RABBITMQ -.->|payment.status| NOTIF_SVC
    RABBITMQ -.->|booking.created| PAYMENT_SVC
    RABBITMQ -.->|booking.created| NOTIF_SVC
    
    style USER_SVC fill:#e1f5ff
    style ADMIN_SVC fill:#e1f5ff
    style BOOKING_SVC fill:#e1f5ff
    style PAYMENT_SVC fill:#e1f5ff
    style NOTIF_SVC fill:#e1f5ff
    style GATEWAY fill:#fff4e1
    style EUREKA fill:#e8f5e9
    style REDIS fill:#ffebee
    style RABBITMQ fill:#f3e5f5
```

---

## Diagram 2: Complete Booking Flow (End-to-End)

### Mermaid Code

```mermaid
sequenceDiagram
    participant Client
    participant Gateway as API Gateway
    participant Booking as Booking Service
    participant Payment as Payment Service
    participant Notification as Notification Service
    participant User as User Service
    participant RabbitMQ as RabbitMQ
    participant Redis as Redis Cache
    participant DB_Booking as Booking DB
    participant DB_Payment as Payment DB
    
    Client->>Gateway: POST /api/bookings
    Gateway->>Booking: Create Booking
    Booking->>Redis: Check Spot Availability
    Booking->>DB_Booking: Save Booking
    Booking->>Redis: Cache Availability
    Booking->>RabbitMQ: Publish booking.created
    Booking-->>Gateway: Booking Created (CONFIRMED)
    Gateway-->>Client: 200 OK
    
    RabbitMQ->>Payment: booking.created event
    Payment->>DB_Payment: Create Payment (PENDING)
    Payment->>Redis: Cache Payment
    Payment->>RabbitMQ: Publish payment.status (PENDING)
    
    RabbitMQ->>Notification: booking.created event
    Notification->>User: Get User Email
    Notification->>Notification: Send Confirmation Email
    
    Client->>Gateway: POST /api/payments/{id}/confirm
    Gateway->>Payment: Confirm Payment
    Payment->>DB_Payment: Update to COMPLETED
    Payment->>Redis: Update Cache
    Payment->>RabbitMQ: Publish payment.status (COMPLETED)
    
    RabbitMQ->>Notification: payment.status (COMPLETED)
    Notification->>Notification: Send Payment Confirmation Email
    
    alt Payment Fails
        Client->>Gateway: POST /api/payments/{id}/fail
        Gateway->>Payment: Fail Payment
        Payment->>DB_Payment: Update to FAILED
        Payment->>RabbitMQ: Publish payment.status (FAILED)
        RabbitMQ->>Booking: payment.status (FAILED)
        Booking->>DB_Booking: Cancel Booking
        Booking->>Redis: Clear Cache
        Booking->>RabbitMQ: Process Waitlist
    end
```

---

## Diagram 3: Waitlist Auto-Promotion Flow

### Mermaid Code

```mermaid
sequenceDiagram
    participant UserA
    participant UserB
    participant Booking as Booking Service
    participant Waitlist as Waitlist Service
    participant Payment as Payment Service
    participant RabbitMQ as RabbitMQ
    participant Redis as Redis Cache
    
    UserA->>Booking: Create Booking
    Booking->>Redis: Mark Spot Unavailable
    Booking->>Booking: Save Booking (CONFIRMED)
    Booking->>RabbitMQ: booking.created
    Booking-->>UserA: Booking Confirmed
    
    UserB->>Booking: Create Booking (Same Slot)
    Booking->>Redis: Check Availability
    Redis-->>Booking: Unavailable
    Booking->>Waitlist: Add to Waitlist
    Booking-->>UserB: Added to Waitlist (Position 1)
    
    UserA->>Booking: Cancel Booking
    Booking->>Booking: Update Status (CANCELLED)
    Booking->>Redis: Clear Cache (Make Available)
    Booking->>Waitlist: Process Waitlist
    Waitlist->>Booking: Create Booking for UserB
    Booking->>RabbitMQ: booking.created (UserB)
    Booking->>RabbitMQ: booking.cancelled (UserA)
    Waitlist-->>UserB: Booking Created from Waitlist
```

---

## Diagram 4: Payment Failure → Booking Cancellation Flow

### Mermaid Code

```mermaid
sequenceDiagram
    participant Client
    participant Booking as Booking Service
    participant Payment as Payment Service
    participant RabbitMQ as RabbitMQ
    participant Waitlist as Waitlist Service
    participant Redis as Redis Cache
    
    Client->>Booking: Create Booking
    Booking->>Booking: Save Booking (CONFIRMED)
    Booking->>RabbitMQ: booking.created
    
    RabbitMQ->>Payment: booking.created event
    Payment->>Payment: Create Payment (PENDING)
    Payment->>RabbitMQ: payment.status (PENDING)
    
    Client->>Payment: POST /payments/{id}/fail
    Payment->>Payment: Update Status (FAILED)
    Payment->>RabbitMQ: Publish payment.status (FAILED)
    
    RabbitMQ->>Booking: payment.status (FAILED)
    Booking->>Booking: Cancel Booking (CANCELLED)
    Booking->>Redis: Clear Availability Cache
    Booking->>Waitlist: Process Waitlist
    Booking->>RabbitMQ: booking.cancelled
    
    Waitlist->>Waitlist: Check Pending Entries
    Waitlist->>Booking: Create Booking for Next User
    Booking->>RabbitMQ: booking.created (New User)
```

---

## Diagram 5: Admin Dashboard Data Flow

### Mermaid Code

```mermaid
graph LR
    subgraph "Admin Service"
        ADMIN[Admin Controller]
        DASHBOARD[Dashboard Stats]
        REPORTS[Reports]
    end
    
    subgraph "Local Data"
        LOTS[(Parking Lots)]
        SPOTS[(Parking Spots)]
    end
    
    subgraph "External Services"
        BOOKING[Booking Service<br/>Client]
        PAYMENT[Payment Service<br/>Client]
    end
    
    ADMIN -->|Get Stats| DASHBOARD
    ADMIN -->|Generate| REPORTS
    
    DASHBOARD -->|Query| LOTS
    DASHBOARD -->|Query| SPOTS
    DASHBOARD -->|REST Call| BOOKING
    DASHBOARD -->|REST Call| PAYMENT
    
    REPORTS -->|Query| LOTS
    REPORTS -->|REST Call| BOOKING
    REPORTS -->|REST Call| PAYMENT
    
    BOOKING -->|Eureka Discovery| BOOKING_API[Booking Service API]
    PAYMENT -->|Eureka Discovery| PAYMENT_API[Payment Service API]
    
    style ADMIN fill:#e1f5ff
    style DASHBOARD fill:#fff4e1
    style REPORTS fill:#fff4e1
```

---

## Draw.io XML Format

For Draw.io (diagrams.net), use the following XML:

```xml
<mxfile host="app.diagrams.net">
  <diagram id="architecture" name="Services and Databases">
    <mxGraphModel dx="1422" dy="794" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1169" pageHeight="827" math="0" shadow="0">
      <root>
        <mxCell id="0" />
        <mxCell id="1" parent="0" />
        
        <!-- Client Layer -->
        <mxCell id="client" value="Client Applications" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
          <mxGeometry x="460" y="40" width="200" height="60" as="geometry" />
        </mxCell>
        
        <!-- API Gateway -->
        <mxCell id="gateway" value="API Gateway&#xa;Port: 8080" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc;strokeColor=#d6b656;" vertex="1" parent="1">
          <mxGeometry x="480" y="140" width="160" height="60" as="geometry" />
        </mxCell>
        
        <!-- Eureka -->
        <mxCell id="eureka" value="Eureka Server&#xa;Port: 8761" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#d5e8d4;strokeColor=#82b366;" vertex="1" parent="1">
          <mxGeometry x="480" y="240" width="160" height="60" as="geometry" />
        </mxCell>
        
        <!-- Services -->
        <mxCell id="user-svc" value="User Service&#xa;Port: 8081" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;" vertex="1" parent="1">
          <mxGeometry x="80" y="360" width="140" height="60" as="geometry" />
        </mxCell>
        
        <mxCell id="admin-svc" value="Admin Service&#xa;Port: 8082" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;" vertex="1" parent="1">
          <mxGeometry x="260" y="360" width="140" height="60" as="geometry" />
        </mxCell>
        
        <mxCell id="booking-svc" value="Booking Service&#xa;Port: 8083" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;" vertex="1" parent="1">
          <mxGeometry x="440" y="360" width="140" height="60" as="geometry" />
        </mxCell>
        
        <mxCell id="payment-svc" value="Payment Service&#xa;Port: 8084" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;" vertex="1" parent="1">
          <mxGeometry x="620" y="360" width="140" height="60" as="geometry" />
        </mxCell>
        
        <mxCell id="notif-svc" value="Notification Service&#xa;Port: 8085" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e1d5e7;strokeColor=#9673a6;" vertex="1" parent="1">
          <mxGeometry x="800" y="360" width="140" height="60" as="geometry" />
        </mxCell>
        
        <!-- Databases -->
        <mxCell id="user-db" value="user_service&#xa;MySQL" style="shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=15;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
          <mxGeometry x="80" y="480" width="140" height="80" as="geometry" />
        </mxCell>
        
        <mxCell id="admin-db" value="admin_service&#xa;MySQL" style="shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=15;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
          <mxGeometry x="260" y="480" width="140" height="80" as="geometry" />
        </mxCell>
        
        <mxCell id="booking-db" value="booking_service&#xa;MySQL" style="shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=15;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
          <mxGeometry x="440" y="480" width="140" height="80" as="geometry" />
        </mxCell>
        
        <mxCell id="payment-db" value="payment_service&#xa;MySQL" style="shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=15;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
          <mxGeometry x="620" y="480" width="140" height="80" as="geometry" />
        </mxCell>
        
        <mxCell id="notif-db" value="notification_service&#xa;MySQL" style="shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=15;fillColor=#f8cecc;strokeColor=#b85450;" vertex="1" parent="1">
          <mxGeometry x="800" y="480" width="140" height="80" as="geometry" />
        </mxCell>
        
        <!-- Infrastructure -->
        <mxCell id="redis" value="Redis Cache&#xa;Port: 6379" style="shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=15;fillColor=#ffe6cc;strokeColor=#d79b00;" vertex="1" parent="1">
          <mxGeometry x="260" y="620" width="140" height="80" as="geometry" />
        </mxCell>
        
        <mxCell id="rabbitmq" value="RabbitMQ&#xa;Port: 5672" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#f5f5f5;strokeColor=#666666;" vertex="1" parent="1">
          <mxGeometry x="620" y="620" width="140" height="60" as="geometry" />
        </mxCell>
        
        <!-- Connections -->
        <mxCell id="edge1" value="" style="endArrow=classic;html=1;rounded=0;" edge="1" parent="1" source="client" target="gateway">
          <mxGeometry width="50" height="50" relative="1" as="geometry" />
        </mxCell>
        
        <mxCell id="edge2" value="" style="endArrow=classic;html=1;rounded=0;" edge="1" parent="1" source="gateway" target="eureka">
          <mxGeometry width="50" height="50" relative="1" as="geometry" />
        </mxCell>
        
        <mxCell id="edge3" value="" style="endArrow=classic;html=1;rounded=0;" edge="1" parent="1" source="gateway" target="user-svc">
          <mxGeometry width="50" height="50" relative="1" as="geometry" />
        </mxCell>
        
        <mxCell id="edge4" value="" style="endArrow=classic;html=1;rounded=0;" edge="1" parent="1" source="gateway" target="booking-svc">
          <mxGeometry width="50" height="50" relative="1" as="geometry" />
        </mxCell>
        
        <mxCell id="edge5" value="" style="endArrow=classic;html=1;rounded=0;" edge="1" parent="1" source="user-svc" target="user-db">
          <mxGeometry width="50" height="50" relative="1" as="geometry" />
        </mxCell>
        
        <mxCell id="edge6" value="" style="endArrow=classic;html=1;rounded=0;" edge="1" parent="1" source="booking-svc" target="booking-db">
          <mxGeometry width="50" height="50" relative="1" as="geometry" />
        </mxCell>
        
        <mxCell id="edge7" value="" style="endArrow=classic;html=1;rounded=0;dashed=1;" edge="1" parent="1" source="user-svc" target="redis">
          <mxGeometry width="50" height="50" relative="1" as="geometry" />
        </mxCell>
        
        <mxCell id="edge8" value="" style="endArrow=classic;html=1;rounded=0;dashed=1;" edge="1" parent="1" source="booking-svc" target="rabbitmq">
          <mxGeometry width="50" height="50" relative="1" as="geometry" />
        </mxCell>
        
      </root>
    </mxGraphModel>
  </diagram>
</mxfile>
```

---

---

## Diagram 6: Detailed Service-to-Database Mapping

### Mermaid Code

```mermaid
graph TB
    subgraph "Service: User Service (Port 8081)"
        USER_API[User Controller]
        USER_SVC[User Service]
        USER_REPO[User Repository]
    end
    
    subgraph "Service: Admin Service (Port 8082)"
        ADMIN_API[Admin Controller]
        ADMIN_SVC[Lot Service]
        ADMIN_REPO[Lot/Spot Repository]
        ADMIN_CLIENT[Booking/Payment Clients]
    end
    
    subgraph "Service: Booking Service (Port 8083)"
        BOOKING_API[Booking Controller]
        BOOKING_SVC[Booking Service]
        BOOKING_REPO[Booking Repository]
        WAITLIST_SVC[Waitlist Service]
        WAITLIST_REPO[Waitlist Repository]
    end
    
    subgraph "Service: Payment Service (Port 8084)"
        PAYMENT_API[Payment Controller]
        PAYMENT_SVC[Payment Service]
        PAYMENT_REPO[Payment Repository]
    end
    
    subgraph "Service: Notification Service (Port 8085)"
        NOTIF_API[Notification Controller]
        NOTIF_SVC[Notification Service]
        NOTIF_CLIENTS[Service Clients]
    end
    
    USER_API --> USER_SVC
    USER_SVC --> USER_REPO
    USER_REPO --> USER_DB[(user_service DB)]
    
    ADMIN_API --> ADMIN_SVC
    ADMIN_SVC --> ADMIN_REPO
    ADMIN_REPO --> ADMIN_DB[(admin_service DB)]
    ADMIN_API --> ADMIN_CLIENT
    ADMIN_CLIENT -.->|REST| BOOKING_API
    ADMIN_CLIENT -.->|REST| PAYMENT_API
    
    BOOKING_API --> BOOKING_SVC
    BOOKING_SVC --> BOOKING_REPO
    BOOKING_REPO --> BOOKING_DB[(booking_service DB)]
    BOOKING_SVC --> WAITLIST_SVC
    WAITLIST_SVC --> WAITLIST_REPO
    WAITLIST_REPO --> BOOKING_DB
    
    PAYMENT_API --> PAYMENT_SVC
    PAYMENT_SVC --> PAYMENT_REPO
    PAYMENT_REPO --> PAYMENT_DB[(payment_service DB)]
    
    NOTIF_API --> NOTIF_SVC
    NOTIF_SVC --> NOTIF_CLIENTS
    NOTIF_CLIENTS -.->|REST| USER_API
    NOTIF_CLIENTS -.->|REST| BOOKING_API
    NOTIF_CLIENTS -.->|REST| PAYMENT_API
    
    style USER_DB fill:#f8cecc
    style ADMIN_DB fill:#f8cecc
    style BOOKING_DB fill:#f8cecc
    style PAYMENT_DB fill:#f8cecc
```

---

## Diagram 7: RabbitMQ Event Flow

### Mermaid Code

```mermaid
graph LR
    subgraph "Event Publishers"
        BOOKING_PUB[Booking Service]
        PAYMENT_PUB[Payment Service]
        USER_PUB[User Service]
    end
    
    subgraph "RabbitMQ Exchange"
        EXCHANGE[booking.events<br/>Topic Exchange]
    end
    
    subgraph "Event Consumers"
        BOOKING_CONS[Booking Service<br/>payment.status]
        PAYMENT_CONS[Payment Service<br/>booking.created]
        NOTIF_CONS[Notification Service<br/>booking.created<br/>payment.status]
        USER_CONS[User Service<br/>booking.created]
        ADMIN_CONS[Admin Service<br/>user.profile.updated]
    end
    
    BOOKING_PUB -->|booking.created| EXCHANGE
    BOOKING_PUB -->|booking.cancelled| EXCHANGE
    PAYMENT_PUB -->|payment.status| EXCHANGE
    USER_PUB -->|user.profile.updated| EXCHANGE
    
    EXCHANGE -->|routing: booking.created| PAYMENT_CONS
    EXCHANGE -->|routing: booking.created| NOTIF_CONS
    EXCHANGE -->|routing: booking.created| USER_CONS
    EXCHANGE -->|routing: payment.status| BOOKING_CONS
    EXCHANGE -->|routing: payment.status| NOTIF_CONS
    EXCHANGE -->|routing: user.profile.updated| ADMIN_CONS
    
    style EXCHANGE fill:#f3e5f5
    style BOOKING_PUB fill:#e1d5e7
    style PAYMENT_PUB fill:#e1d5e7
    style USER_PUB fill:#e1d5e7
```

---

## Quick Reference: Service Details

| Service | Port | Database | Cache | Events |
|---------|------|----------|-------|--------|
| **User Service** | 8081 | user_service | Redis | user.profile.updated |
| **Admin Service** | 8082 | admin_service | - | user.profile.updated |
| **Booking Service** | 8083 | booking_service | Redis | booking.created, booking.cancelled |
| **Payment Service** | 8084 | payment_service | Redis | payment.status |
| **Notification Service** | 8085 | notification_service | - | booking.created, payment.status |
| **API Gateway** | 8080 | - | - | - |
| **Eureka Server** | 8761 | - | - | - |

---

## How to Use These Diagrams

### For Mermaid:
1. Copy the mermaid code blocks
2. Go to https://mermaid.live/ or use GitHub markdown
3. Paste the code
4. Export as PNG/SVG

### For Draw.io:
1. Go to https://app.diagrams.net/
2. File → Open → Paste the XML code
3. Customize as needed
4. Export in desired format

---

**Note**: These diagrams show the complete architecture, data flows, and service interactions in the Vehicle Parking Management System.

