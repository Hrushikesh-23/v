package com.hashedin.parking.admin.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

@Entity
public class ParkingSpot {
    @Id @GeneratedValue
    private Long id;
    private String code;
    private boolean available = true;

    @ManyToOne
    @JoinColumn(name = "lot_id")
    @JsonBackReference
    private ParkingLot lot;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
    public ParkingLot getLot() { return lot; }
    public void setLot(ParkingLot lot) { this.lot = lot; }
}
