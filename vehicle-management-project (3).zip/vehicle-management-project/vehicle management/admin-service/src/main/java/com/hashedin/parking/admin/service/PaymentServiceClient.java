package com.hashedin.parking.admin.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class PaymentServiceClient {
    private static final Logger log = LoggerFactory.getLogger(PaymentServiceClient.class);
    
    private final RestTemplate restTemplate;
    private final String paymentServiceUrl;

    public PaymentServiceClient(RestTemplate restTemplate,
                                @Value("${app.services.payment.url:http://payment-service}") String paymentServiceUrl) {
        this.restTemplate = restTemplate;
        this.paymentServiceUrl = paymentServiceUrl;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Payment(
            UUID id,
            UUID userId,
            UUID bookingId,
            BigDecimal amount,
            String status,
            LocalDateTime createdAt
    ) {}

    public List<Payment> getAllCompletedPayments() {
        try {
            String url = String.format("%s/api/payments/admin/status/COMPLETED", paymentServiceUrl);
            List<Payment> payments = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<Payment>>() {}
            ).getBody();
            
            return payments != null ? payments : List.of();
        } catch (Exception e) {
            log.warn("Could not fetch completed payments: {}", e.getMessage());
            return List.of();
        }
    }

    public List<Payment> getPaymentsByDateRange(LocalDateTime from, LocalDateTime to) {
        try {
            String url = String.format("%s/api/payments/date-range?from=%s&to=%s", 
                paymentServiceUrl, from.toString(), to.toString());
            List<Payment> payments = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<Payment>>() {}
            ).getBody();
            
            return payments != null ? payments : List.of();
        } catch (Exception e) {
            log.warn("Could not fetch payments by date range: {}", e.getMessage());
            return List.of();
        }
    }

    public List<Payment> getAllPayments() {
        try {
            String url = String.format("%s/api/payments/admin/all", paymentServiceUrl);
            List<Payment> payments = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<Payment>>() {}
            ).getBody();
            
            return payments != null ? payments : List.of();
        } catch (Exception e) {
            log.warn("Could not fetch all payments: {}", e.getMessage());
            return List.of();
        }
    }
}

