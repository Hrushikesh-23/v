package com.hashedin.parking.admin.scheduler;

import com.hashedin.parking.admin.repo.LotRepo;
import com.hashedin.parking.admin.repo.SpotRepo;
import com.hashedin.parking.admin.service.BookingServiceClient;
import com.hashedin.parking.admin.service.PaymentServiceClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;

@Component
@EnableScheduling
public class ReportingJobs {
    private static final Logger log = LoggerFactory.getLogger(ReportingJobs.class);
    private final SpotRepo spots;
    private final LotRepo lots;
    private final PaymentServiceClient paymentServiceClient;
    private final BookingServiceClient bookingServiceClient;

    public ReportingJobs(SpotRepo spots, 
                         LotRepo lots,
                         PaymentServiceClient paymentServiceClient,
                         BookingServiceClient bookingServiceClient) { 
        this.spots = spots; 
        this.lots = lots;
        this.paymentServiceClient = paymentServiceClient;
        this.bookingServiceClient = bookingServiceClient;
    }

    // Generate occupancy statistics every hour
    @Scheduled(cron = "0 0 * * * *")
    public void occupancyReport() {
        try {
            long totalSpots = spots.count();
            long availableSpots = spots.findByLotIdAndAvailableTrue(1L).size(); // Simplified for demo
            long occupiedSpots = totalSpots - availableSpots;
            double occupancyRate = totalSpots > 0 ? (double) occupiedSpots / totalSpots * 100 : 0;
            
            log.info("=== OCCUPANCY REPORT ===");
            log.info("Total Spots: {}", totalSpots);
            log.info("Available Spots: {}", availableSpots);
            log.info("Occupied Spots: {}", occupiedSpots);
            log.info("Occupancy Rate: {:.2f}%", occupancyRate);
            log.info("Generated at: {}", java.time.LocalDateTime.now());
        } catch (Exception e) {
            log.error("Error generating occupancy report: {}", e.getMessage());
        }
    }

    // Generate revenue analysis every 6 hours
    @Scheduled(cron = "0 0 */6 * * *")
    public void revenueAnalysis() {
        try {
            log.info("=== REVENUE ANALYSIS REPORT ===");
            log.info("Total Lots: {}", lots.count());
            log.info("Total Spots: {}", spots.count());
            
            // Fetch real payment data
            List<PaymentServiceClient.Payment> completedPayments = paymentServiceClient.getAllCompletedPayments();
            
            if (!completedPayments.isEmpty()) {
                BigDecimal totalRevenue = completedPayments.stream()
                    .map(PaymentServiceClient.Payment::amount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
                
                BigDecimal avgTransactionValue = totalRevenue.divide(
                    BigDecimal.valueOf(completedPayments.size()), 
                    2, 
                    RoundingMode.HALF_UP
                );
                
                BigDecimal dailyRevenue = totalRevenue.divide(BigDecimal.valueOf(365), 2, RoundingMode.HALF_UP);
                
                log.info("Total Completed Payments: {}", completedPayments.size());
                log.info("Total Revenue (All Time): ${}", totalRevenue);
                log.info("Daily Revenue (Average): ${}", dailyRevenue);
                log.info("Average Transaction Value: ${}", avgTransactionValue);
            } else {
                log.info("No completed payments found. Revenue: $0.00");
            }
            
            log.info("Generated at: {}", java.time.LocalDateTime.now());
        } catch (Exception e) {
            log.error("Error generating revenue analysis: {}", e.getMessage(), e);
        }
    }

    // Generate daily summary report at 9 PM
    @Scheduled(cron = "0 0 21 * * *")
    public void dailySummary() {
        try {
            LocalDateTime todayStart = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0);
            LocalDateTime todayEnd = LocalDateTime.now().withHour(23).withMinute(59).withSecond(59);
            
            log.info("=== DAILY SUMMARY REPORT ===");
            log.info("Date: {}", java.time.LocalDate.now());
            log.info("Total Lots: {}", lots.count());
            log.info("Total Spots: {}", spots.count());
            
            // Fetch today's bookings
            List<BookingServiceClient.Booking> allBookings = bookingServiceClient.getAllBookings();
            long dailyBookings = allBookings.stream()
                .filter(b -> b.startTime().isAfter(todayStart) && b.startTime().isBefore(todayEnd))
                .count();
            log.info("Daily Bookings: {}", dailyBookings);
            
            // Fetch today's payments
            List<PaymentServiceClient.Payment> todayPayments = paymentServiceClient.getPaymentsByDateRange(todayStart, todayEnd);
            BigDecimal dailyRevenue = todayPayments.stream()
                .filter(p -> "COMPLETED".equals(p.status()))
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            log.info("Daily Revenue: ${}", dailyRevenue);
            
            // Calculate occupancy (simplified - would need real-time booking data)
            long totalSpots = spots.count();
            long occupiedSpots = allBookings.stream()
                .filter(b -> List.of("CREATED", "CONFIRMED").contains(b.status()))
                .filter(b -> b.startTime().isBefore(LocalDateTime.now()) && b.endTime().isAfter(LocalDateTime.now()))
                .map(BookingServiceClient.Booking::spotId)
                .distinct()
                .count();
            
            double peakOccupancy = totalSpots > 0 ? (double) occupiedSpots / totalSpots * 100 : 0;
            double avgOccupancy = peakOccupancy * 0.7; // Simplified calculation
            
            log.info("Current Occupancy: {:.2f}%", peakOccupancy);
            log.info("Average Occupancy (Estimated): {:.2f}%", avgOccupancy);
            log.info("Generated at: {}", java.time.LocalDateTime.now());
        } catch (Exception e) {
            log.error("Error generating daily summary: {}", e.getMessage(), e);
        }
    }

    // Generate weekly report every Sunday at 8 AM
    @Scheduled(cron = "0 0 8 * * SUN")
    public void weeklyReport() {
        try {
            LocalDateTime weekStart = LocalDateTime.now().minusDays(7).withHour(0).withMinute(0).withSecond(0);
            LocalDateTime weekEnd = LocalDateTime.now().withHour(23).withMinute(59).withSecond(59);
            
            log.info("=== WEEKLY REPORT ===");
            log.info("Week of: {} to {}", weekStart.toLocalDate(), LocalDateTime.now().toLocalDate());
            log.info("Total Lots: {}", lots.count());
            log.info("Total Spots: {}", spots.count());
            
            // Fetch weekly bookings
            List<BookingServiceClient.Booking> allBookings = bookingServiceClient.getAllBookings();
            long weeklyBookings = allBookings.stream()
                .filter(b -> b.startTime().isAfter(weekStart) && b.startTime().isBefore(weekEnd))
                .count();
            log.info("Weekly Bookings: {}", weeklyBookings);
            
            // Fetch weekly payments
            List<PaymentServiceClient.Payment> weeklyPayments = paymentServiceClient.getPaymentsByDateRange(weekStart, weekEnd);
            BigDecimal weeklyRevenue = weeklyPayments.stream()
                .filter(p -> "COMPLETED".equals(p.status()))
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            log.info("Weekly Revenue: ${}", weeklyRevenue);
            
            // Calculate average daily occupancy (simplified)
            long totalSpots = spots.count();
            double avgOccupancy = 0.0;
            if (totalSpots > 0 && weeklyBookings > 0) {
                // Simplified calculation: average bookings per day / total spots
                avgOccupancy = ((double) weeklyBookings / 7.0 / totalSpots) * 100;
            }
            log.info("Average Daily Occupancy: {:.2f}%", avgOccupancy);
            
            log.info("Generated at: {}", java.time.LocalDateTime.now());
        } catch (Exception e) {
            log.error("Error generating weekly report: {}", e.getMessage(), e);
        }
    }
}
