package com.hashedin.parking.admin.web;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hashedin.parking.admin.model.ParkingLot;
import com.hashedin.parking.admin.model.ParkingSpot;
import com.hashedin.parking.admin.service.LotService;

@RestController
@RequestMapping("/api/lots")
public class LotController {

    private final LotService lotService;

    public LotController(LotService lotService) {
        this.lotService = lotService;
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public List<ParkingLot> getAllParkingLots() { 
        return lotService.getAllLots(); 
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ParkingLot createParkingLot(@RequestBody ParkingLot lot) { 
        return lotService.createLot(lot); 
    }

    @PutMapping("/{lotId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> updateParkingLot(@PathVariable("lotId") Long lotId, @RequestBody ParkingLot lot) {
        return ResponseEntity.of(lotService.updateLot(lotId, lot));
    }

    @DeleteMapping("/{lotId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteParkingLot(@PathVariable("lotId") Long lotId) {
        if (lotService.deleteLot(lotId)) {
            return ResponseEntity.ok(Map.of("message", "Lot deleted successfully"));
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/{lotId}/spots")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public ResponseEntity<?> addParkingSpot(@PathVariable("lotId") Long lotId, @RequestBody ParkingSpot spot) {
        return ResponseEntity.of(lotService.addSpot(lotId, spot));
    }

    @PutMapping("/{lotId}/spots/{spotId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public ResponseEntity<?> updateParkingSpot(@PathVariable("lotId") Long lotId, 
                                       @PathVariable("spotId") Long spotId, 
                                       @RequestBody ParkingSpot spot) {
        return ResponseEntity.of(lotService.updateSpot(lotId, spotId, spot));
    }

    @DeleteMapping("/{lotId}/spots/{spotId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteParkingSpot(@PathVariable("lotId") Long lotId, 
                                       @PathVariable("spotId") Long spotId) {
        return ResponseEntity.of(lotService.deleteSpot(lotId, spotId));
    }

    @GetMapping("/{lotId}/spots/available")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public List<ParkingSpot> getAvailableSpots(@PathVariable("lotId") Long lotId) {
        return lotService.getAvailableSpots(lotId);
    }

    @GetMapping("/{lotId}/spots")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public List<ParkingSpot> getAllSpotsByLot(@PathVariable("lotId") Long lotId) {
        return lotService.getAllSpots(lotId);
    }

    // Public endpoint for validation by booking service
    @GetMapping("/{lotId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER') or hasRole('USER')")
    public ResponseEntity<?> getLotById(@PathVariable("lotId") Long lotId) {
        return ResponseEntity.of(lotService.getLotById(lotId));
    }
}