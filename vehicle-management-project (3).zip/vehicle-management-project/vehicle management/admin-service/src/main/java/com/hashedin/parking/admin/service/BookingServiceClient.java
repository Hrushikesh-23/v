package com.hashedin.parking.admin.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class BookingServiceClient {
    private static final Logger log = LoggerFactory.getLogger(BookingServiceClient.class);
    
    private final RestTemplate restTemplate;
    private final String bookingServiceUrl;

    public BookingServiceClient(RestTemplate restTemplate,
                                @Value("${app.services.booking.url:http://booking-service}") String bookingServiceUrl) {
        this.restTemplate = restTemplate;
        this.bookingServiceUrl = bookingServiceUrl;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Booking(
            UUID id,
            UUID userId,
            Long lotId,
            Long spotId,
            LocalDateTime startTime,
            LocalDateTime endTime,
            String status
    ) {}

    public List<Booking> getAllBookings() {
        try {
            // Use internal endpoint to get all bookings (requires admin auth in production)
            String url = String.format("%s/api/bookings/internal/upcoming?hours=8760", bookingServiceUrl); // 1 year
            List<Booking> bookings = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<Booking>>() {}
            ).getBody();
            
            return bookings != null ? bookings : List.of();
        } catch (Exception e) {
            log.warn("Could not fetch all bookings: {}", e.getMessage());
            return List.of();
        }
    }
}

