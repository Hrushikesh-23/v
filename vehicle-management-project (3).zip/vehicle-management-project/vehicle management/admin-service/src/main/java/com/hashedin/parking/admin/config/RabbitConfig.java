package com.hashedin.parking.admin.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.beans.factory.annotation.Value;

@Configuration
@EnableRabbit
public class RabbitConfig {

    @Bean
    public TopicExchange bookingExchange(@Value("${app.rabbit.exchange}") String exchange) {
        return new TopicExchange(exchange, true, false);
    }

    @Bean
    public Queue adminUserProfileUpdatedQueue(
            @Value("${app.rabbit.queues.adminService.userProfileUpdated}") String qName) {
        return QueueBuilder.durable(qName).build();
    }

    @Bean
    public Binding bindAdminUserProfileUpdated(Queue adminUserProfileUpdatedQueue,
                                               TopicExchange bookingExchange,
                                               @Value("${app.rabbit.routing.userProfileUpdated}") String rk) {
        return BindingBuilder.bind(adminUserProfileUpdatedQueue).to(bookingExchange).with(rk);
    }

    @Bean
    public Jackson2JsonMessageConverter jacksonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }
}
