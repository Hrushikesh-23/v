package com.hashedin.parking.admin.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Configuration
public class RestTemplateConfig {
    private static final Logger log = LoggerFactory.getLogger(RestTemplateConfig.class);
    
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate();
        
        // Add interceptor to forward Authorization header
        List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
        interceptors.add(new AuthHeaderInterceptor());
        restTemplate.setInterceptors(interceptors);
        
        return restTemplate;
    }
    
    private static class AuthHeaderInterceptor implements ClientHttpRequestInterceptor {
        @Override
        public ClientHttpResponse intercept(
                HttpRequest request,
                byte[] body,
                ClientHttpRequestExecution execution) throws IOException {
            
            try {
                // Get the current HTTP request to extract Authorization header
                ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
                if (attributes != null) {
                    HttpServletRequest httpRequest = attributes.getRequest();
                    String authHeader = httpRequest.getHeader("Authorization");
                    
                    if (authHeader != null && !authHeader.isEmpty()) {
                        request.getHeaders().set("Authorization", authHeader);
                        log.debug("Forwarding Authorization header to downstream service");
                    } else {
                        log.warn("No Authorization header found in current request");
                    }
                }
            } catch (Exception e) {
                log.warn("Could not forward Authorization header: {}", e.getMessage());
            }
            
            return execution.execute(request, body);
        }
    }
}
