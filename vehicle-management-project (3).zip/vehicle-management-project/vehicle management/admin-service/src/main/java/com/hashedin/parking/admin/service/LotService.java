package com.hashedin.parking.admin.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hashedin.parking.admin.model.ParkingLot;
import com.hashedin.parking.admin.model.ParkingSpot;
import com.hashedin.parking.admin.repo.LotRepo;
import com.hashedin.parking.admin.repo.SpotRepo;

@Service
public class LotService {

    private final LotRepo lotRepo;
    private final SpotRepo spotRepo;

    public LotService(LotRepo lotRepo, SpotRepo spotRepo) {
        this.lotRepo = lotRepo;
        this.spotRepo = spotRepo;
    }

    public List<ParkingLot> getAllLots() {
        return lotRepo.findAll();
    }

    @Transactional
    public ParkingLot createLot(ParkingLot lot) {
        return lotRepo.save(lot);
    }

    @Transactional
    public Optional<ParkingLot> updateLot(Long id, ParkingLot lot) {
        return lotRepo.findById(id).map(existing -> {
            existing.setName(lot.getName());
            existing.setAddress(lot.getAddress());
            return lotRepo.save(existing);
        });
    }

    @Transactional
    public boolean deleteLot(Long id) {
        if (lotRepo.existsById(id)) {
            lotRepo.deleteById(id);
            return true;
        }
        return false;
    }

    @Transactional
    public Optional<Map<String, String>> addSpot(Long lotId, ParkingSpot spot) {
        return lotRepo.findById(lotId).map(lot -> {
            spot.setLot(lot);
            spotRepo.save(spot);
            return Map.of("message", "spot added");
        });
    }

    @Transactional
    public Optional<ParkingSpot> updateSpot(Long lotId, Long spotId, ParkingSpot spot) {
        return spotRepo.findById(spotId).map(existing -> {
            if (existing.getLot().getId().equals(lotId)) {
                existing.setCode(spot.getCode());
                existing.setAvailable(spot.isAvailable());
                return spotRepo.save(existing);
            }
            return null;
        });
    }

    @Transactional
    public Optional<Map<String, String>> deleteSpot(Long lotId, Long spotId) {
        return spotRepo.findById(spotId).map(spot -> {
            if (spot.getLot().getId().equals(lotId)) {
                spotRepo.deleteById(spotId);
                return Map.of("message", "Spot deleted successfully");
            }
            return null;
        });
    }

    public List<ParkingSpot> getAvailableSpots(Long lotId) {
        return spotRepo.findByLotIdAndAvailableTrue(lotId);
    }

    public List<ParkingSpot> getAllSpots(Long lotId) {
        return spotRepo.findByLotId(lotId);
    }

    public Optional<ParkingLot> getLotById(Long id) {
        return lotRepo.findById(id);
    }

    public Optional<ParkingSpot> getSpotById(Long id) {
        return spotRepo.findById(id);
    }
}


