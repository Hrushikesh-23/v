package com.hashedin.parking.admin.web;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hashedin.parking.admin.repo.LotRepo;
import com.hashedin.parking.admin.repo.SpotRepo;
import com.hashedin.parking.admin.service.BookingServiceClient;
import com.hashedin.parking.admin.service.PaymentServiceClient;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    private final LotRepo lotRepo;
    private final SpotRepo spotRepo;
    private final BookingServiceClient bookingServiceClient;
    private final PaymentServiceClient paymentServiceClient;

    public AdminController(LotRepo lotRepo, 
                          SpotRepo spotRepo,
                          BookingServiceClient bookingServiceClient,
                          PaymentServiceClient paymentServiceClient) {
        this.lotRepo = lotRepo;
        this.spotRepo = spotRepo;
        this.bookingServiceClient = bookingServiceClient;
        this.paymentServiceClient = paymentServiceClient;
    }

    @GetMapping("/bookings/history")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public ResponseEntity<?> getBookingHistory(@RequestParam(required = false) String lotId,
                                             @RequestParam(required = false) String status,
                                             @RequestParam(required = false) String fromDate,
                                             @RequestParam(required = false) String toDate) {
        try {
            log.info("Fetching booking history with filters - lotId: {}, status: {}, fromDate: {}, toDate: {}", 
                    lotId, status, fromDate, toDate);
            
            // Fetch real booking data from booking service
            List<BookingServiceClient.Booking> allBookings = bookingServiceClient.getAllBookings();
            
            // Parse date filters - handle gracefully to allow use in lambda
            LocalDateTime parsedFromDate = null;
            LocalDateTime parsedToDate = null;
            if (fromDate != null && !fromDate.isEmpty()) {
                try {
                    // Try parsing as LocalDateTime first
                    parsedFromDate = LocalDateTime.parse(fromDate);
                } catch (Exception e1) {
                    try {
                        // If that fails, try parsing as LocalDate and convert to start of day
                        parsedFromDate = java.time.LocalDate.parse(fromDate).atStartOfDay();
                    } catch (Exception e2) {
                        log.warn("Invalid fromDate format: {}, ignoring filter", fromDate);
                    }
                }
            }
            if (toDate != null && !toDate.isEmpty()) {
                try {
                    // Try parsing as LocalDateTime first
                    parsedToDate = LocalDateTime.parse(toDate);
                } catch (Exception e1) {
                    try {
                        // If that fails, try parsing as LocalDate and convert to end of day
                        parsedToDate = java.time.LocalDate.parse(toDate).atTime(23, 59, 59);
                    } catch (Exception e2) {
                        log.warn("Invalid toDate format: {}, ignoring filter", toDate);
                    }
                }
            }
            
            final LocalDateTime finalFromDateTime = parsedFromDate;
            final LocalDateTime finalToDateTime = parsedToDate;
            
            // Apply filters if provided
            List<BookingServiceClient.Booking> filteredBookings = allBookings.stream()
                .filter(b -> lotId == null || (b.lotId() != null && b.lotId().toString().equals(lotId)))
                .filter(b -> status == null || (b.status() != null && b.status().equals(status)))
                .filter(b -> finalFromDateTime == null || (b.startTime() != null && !b.startTime().isBefore(finalFromDateTime)))
                .filter(b -> finalToDateTime == null || (b.startTime() != null && !b.startTime().isAfter(finalToDateTime)))
                .toList();
            
            return ResponseEntity.ok(Map.of(
                "message", "Booking history retrieved",
                "filters", Map.of(
                    "lotId", lotId != null ? lotId : "all",
                    "status", status != null ? status : "all",
                    "fromDate", fromDate != null ? fromDate : "all",
                    "toDate", toDate != null ? toDate : "all"
                ),
                "totalBookings", filteredBookings.size(),
                "bookings", filteredBookings
            ));
        } catch (Exception e) {
            log.error("Error retrieving booking history: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to retrieve booking history: " + e.getMessage()));
        }
    }

    @GetMapping("/transactions/logs")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getTransactionLogs(@RequestParam(required = false) String userId,
                                              @RequestParam(required = false) String status,
                                              @RequestParam(required = false) String fromDate,
                                              @RequestParam(required = false) String toDate) {
        try {
            log.info("Fetching transaction logs with filters - userId: {}, status: {}, fromDate: {}, toDate: {}", 
                    userId, status, fromDate, toDate);
            
            // Fetch real payment data from payment service
            List<PaymentServiceClient.Payment> allPayments = paymentServiceClient.getAllPayments();
            
            // Parse date filters - handle gracefully to allow use in lambda
            LocalDateTime parsedFromDate = null;
            LocalDateTime parsedToDate = null;
            if (fromDate != null && !fromDate.isEmpty()) {
                try {
                    // Try parsing as LocalDateTime first
                    parsedFromDate = LocalDateTime.parse(fromDate);
                } catch (Exception e1) {
                    try {
                        // If that fails, try parsing as LocalDate and convert to start of day
                        parsedFromDate = java.time.LocalDate.parse(fromDate).atStartOfDay();
                    } catch (Exception e2) {
                        log.warn("Invalid fromDate format: {}, ignoring filter", fromDate);
                    }
                }
            }
            if (toDate != null && !toDate.isEmpty()) {
                try {
                    // Try parsing as LocalDateTime first
                    parsedToDate = LocalDateTime.parse(toDate);
                } catch (Exception e1) {
                    try {
                        // If that fails, try parsing as LocalDate and convert to end of day
                        parsedToDate = java.time.LocalDate.parse(toDate).atTime(23, 59, 59);
                    } catch (Exception e2) {
                        log.warn("Invalid toDate format: {}, ignoring filter", toDate);
                    }
                }
            }
            
            final LocalDateTime finalFromDateTime = parsedFromDate;
            final LocalDateTime finalToDateTime = parsedToDate;
            
            // Apply all filters
            List<PaymentServiceClient.Payment> filteredPayments = allPayments.stream()
                .filter(p -> userId == null || (p.userId() != null && p.userId().toString().equals(userId)))
                .filter(p -> status == null || status.isEmpty() || (p.status() != null && p.status().equals(status)))
                .filter(p -> finalFromDateTime == null || (p.createdAt() != null && !p.createdAt().isBefore(finalFromDateTime)))
                .filter(p -> finalToDateTime == null || (p.createdAt() != null && !p.createdAt().isAfter(finalToDateTime)))
                .toList();
            
            // Calculate total revenue
            BigDecimal totalRevenue = filteredPayments.stream()
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            return ResponseEntity.ok(Map.of(
                "message", "Transaction logs retrieved",
                "filters", Map.of(
                    "userId", userId != null ? userId : "all",
                    "status", status != null ? status : "all",
                    "fromDate", fromDate != null ? fromDate : "all",
                    "toDate", toDate != null ? toDate : "all"
                ),
                "totalTransactions", filteredPayments.size(),
                "totalRevenue", "$" + totalRevenue.setScale(2, RoundingMode.HALF_UP),
                "transactions", filteredPayments
            ));
        } catch (Exception e) {
            log.error("Error retrieving transaction logs: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to retrieve transaction logs: " + e.getMessage()));
        }
    }

    @GetMapping("/dashboard/stats")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public ResponseEntity<?> getDashboardStats() {
        try {
            // Get real data from repositories
            long totalLots = lotRepo.count();
            long totalSpots = spotRepo.count();
            long availableSpots = spotRepo.findAll().stream()
                .filter(spot -> spot.isAvailable())
                .count();
            long occupiedSpots = totalSpots - availableSpots;
            
            // Get booking data from booking service
            List<BookingServiceClient.Booking> allBookings = bookingServiceClient.getAllBookings();
            long totalBookings = allBookings.size();
            
            // Calculate active bookings (bookings that are currently active)
            LocalDateTime now = LocalDateTime.now();
            long activeBookings = allBookings.stream()
                .filter(b -> List.of("CREATED", "CONFIRMED").contains(b.status()))
                .filter(b -> b.startTime().isBefore(now) && b.endTime().isAfter(now))
                .count();
            
            // Get revenue from payment service
            List<PaymentServiceClient.Payment> completedPayments = paymentServiceClient.getAllCompletedPayments();
            BigDecimal totalRevenue = completedPayments.stream()
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Calculate occupancy rate
            double occupancyRate = totalSpots > 0 
                ? (double) occupiedSpots / totalSpots * 100 
                : 0.0;
            
            return ResponseEntity.ok(Map.of(
                "totalLots", totalLots,
                "totalSpots", totalSpots,
                "availableSpots", availableSpots,
                "occupiedSpots", occupiedSpots,
                "totalBookings", totalBookings,
                "activeBookings", activeBookings,
                "totalRevenue", "$" + totalRevenue.setScale(2, RoundingMode.HALF_UP),
                "occupancyRate", String.format("%.1f%%", occupancyRate),
                "lastUpdated", LocalDateTime.now().toString()
            ));
        } catch (Exception e) {
            log.error("Error retrieving dashboard stats: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to retrieve dashboard stats: " + e.getMessage()));
        }
    }

    @GetMapping("/reports/occupancy")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public ResponseEntity<?> getOccupancyReport(@RequestParam(required = false) String period) {
        try {
            // Get real data
            long totalSpots = spotRepo.count();
            long availableSpots = spotRepo.findAll().stream()
                .filter(spot -> spot.isAvailable())
                .count();
            long occupiedSpots = totalSpots - availableSpots;
            double averageOccupancy = totalSpots > 0 
                ? (double) occupiedSpots / totalSpots * 100 
                : 0.0;
            
            // Get booking data to calculate peak/low hours
            List<BookingServiceClient.Booking> allBookings = bookingServiceClient.getAllBookings();
            LocalDateTime now = LocalDateTime.now();
            
            // Calculate current occupancy
            long currentlyOccupied = allBookings.stream()
                .filter(b -> List.of("CREATED", "CONFIRMED").contains(b.status()))
                .filter(b -> b.startTime().isBefore(now) && b.endTime().isAfter(now))
                .map(BookingServiceClient.Booking::spotId)
                .distinct()
                .count();
            
            double currentOccupancy = totalSpots > 0 
                ? (double) currentlyOccupied / totalSpots * 100 
                : 0.0;
            
            // Get revenue from payment service
            List<PaymentServiceClient.Payment> completedPayments = paymentServiceClient.getAllCompletedPayments();
            BigDecimal totalRevenue = completedPayments.stream()
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Calculate real peak/low hours by analyzing booking patterns across hours
            Map<Integer, Long> bookingsByHour = new HashMap<>();
            Map<Integer, Long> occupancyByHour = new HashMap<>();
            
            // Analyze bookings from the last 30 days to find patterns
            LocalDateTime thirtyDaysAgo = now.minusDays(30);
            List<BookingServiceClient.Booking> recentBookings = allBookings.stream()
                .filter(b -> b.startTime().isAfter(thirtyDaysAgo))
                .filter(b -> List.of("CREATED", "CONFIRMED").contains(b.status()))
                .toList();
            
            // Count bookings and occupancy by hour
            for (BookingServiceClient.Booking booking : recentBookings) {
                int hour = booking.startTime().getHour();
                bookingsByHour.put(hour, bookingsByHour.getOrDefault(hour, 0L) + 1);
                
                // Calculate occupancy for this hour (simplified: count bookings that were active during this hour)
                LocalDateTime hourStart = booking.startTime().withMinute(0).withSecond(0).withNano(0);
                if (booking.startTime().isBefore(hourStart.plusHours(1)) && booking.endTime().isAfter(hourStart)) {
                    occupancyByHour.put(hour, occupancyByHour.getOrDefault(hour, 0L) + 1);
                }
            }
            
            // Find peak hour (hour with most bookings)
            int peakHour = bookingsByHour.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(10);
            
            // Find low hour (hour with least bookings)
            int lowHour = bookingsByHour.entrySet().stream()
                .min(Map.Entry.comparingByValue())
                .filter(e -> e.getValue() > 0) // Only consider hours with some bookings
                .map(Map.Entry::getKey)
                .orElse(2);
            
            // Calculate peak and low occupancy based on actual data
            long peakOccupancyCount = occupancyByHour.values().stream()
                .mapToLong(Long::longValue)
                .max()
                .orElse(0L);
            double peakOccupancy = totalSpots > 0 
                ? (double) peakOccupancyCount / totalSpots * 100 
                : 0.0;
            
            long lowOccupancyCount = occupancyByHour.values().stream()
                .mapToLong(Long::longValue)
                .filter(v -> v > 0) // Only consider hours with bookings
                .min()
                .orElse(0L);
            double lowOccupancy = totalSpots > 0 
                ? (double) lowOccupancyCount / totalSpots * 100 
                : 0.0;
            
            String peakHours = String.format("%02d:00-%02d:00", peakHour, (peakHour + 2) % 24);
            String lowHours = String.format("%02d:00-%02d:00", lowHour, (lowHour + 2) % 24);
            
            return ResponseEntity.ok(Map.of(
                "reportType", "Occupancy Report",
                "period", period != null ? period : "daily",
                "data", Map.of(
                    "totalSpots", totalSpots,
                    "availableSpots", availableSpots,
                    "occupiedSpots", occupiedSpots,
                    "currentOccupancy", String.format("%.1f%%", currentOccupancy),
                    "averageOccupancy", String.format("%.1f%%", averageOccupancy),
                    "peakHours", Map.of("hour", peakHours, "occupancy", String.format("%.1f%%", peakOccupancy)),
                    "lowHours", Map.of("hour", lowHours, "occupancy", String.format("%.1f%%", lowOccupancy)),
                    "totalRevenue", "$" + totalRevenue.setScale(2, RoundingMode.HALF_UP)
                ),
                "generatedAt", LocalDateTime.now().toString()
            ));
        } catch (Exception e) {
            log.error("Error generating occupancy report: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to generate occupancy report: " + e.getMessage()));
        }
    }

    @GetMapping("/reports/revenue")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getRevenueReport(@RequestParam(required = false) String period) {
        try {
            // Get real payment data
            List<PaymentServiceClient.Payment> allPayments = paymentServiceClient.getAllPayments();
            List<PaymentServiceClient.Payment> completedPayments = allPayments.stream()
                .filter(p -> "COMPLETED".equals(p.status()))
                .toList();
            
            // Calculate total revenue
            BigDecimal totalRevenue = completedPayments.stream()
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Calculate average transaction value
            BigDecimal avgTransaction = completedPayments.isEmpty() 
                ? BigDecimal.ZERO
                : totalRevenue.divide(BigDecimal.valueOf(completedPayments.size()), 2, RoundingMode.HALF_UP);
            
            // Get booking data to calculate revenue by lot
            List<BookingServiceClient.Booking> allBookings = bookingServiceClient.getAllBookings();
            Map<Long, BigDecimal> revenueByLot = completedPayments.stream()
                .collect(java.util.stream.Collectors.groupingBy(
                    p -> {
                        // Find booking for this payment
                        return allBookings.stream()
                            .filter(b -> b.id().equals(p.bookingId()))
                            .findFirst()
                            .map(BookingServiceClient.Booking::lotId)
                            .orElse(null);
                    },
                    java.util.stream.Collectors.reducing(
                        BigDecimal.ZERO,
                        PaymentServiceClient.Payment::amount,
                        BigDecimal::add
                    )
                ));
            
            // Get lot names for display
            Map<String, String> revenueByLotFormatted = new HashMap<>();
            for (Map.Entry<Long, BigDecimal> entry : revenueByLot.entrySet()) {
                if (entry.getKey() != null) {
                    lotRepo.findById(entry.getKey())
                        .ifPresent(lot -> revenueByLotFormatted.put(
                            lot.getName(), 
                            "$" + entry.getValue().setScale(2, RoundingMode.HALF_UP)
                        ));
                }
            }
            
            // Calculate payment statistics from real data
            // Since payment method is not in the model, calculate other useful metrics
            long pendingPayments = allPayments.stream()
                .filter(p -> "PENDING".equals(p.status()))
                .count();
            long failedPayments = allPayments.stream()
                .filter(p -> "FAILED".equals(p.status()))
                .count();
            long cancelledPayments = allPayments.stream()
                .filter(p -> "CANCELLED".equals(p.status()))
                .count();
            
            // Calculate success rate
            long totalProcessedPayments = completedPayments.size() + failedPayments + cancelledPayments;
            double successRate = totalProcessedPayments > 0
                ? (double) completedPayments.size() / totalProcessedPayments * 100
                : 0.0;
            
            // Calculate revenue trends (compare last 30 days vs previous 30 days)
            LocalDateTime sixtyDaysAgo = LocalDateTime.now().minusDays(60);
            LocalDateTime thirtyDaysAgo = LocalDateTime.now().minusDays(30);
            
            BigDecimal recentRevenue = completedPayments.stream()
                .filter(p -> p.createdAt() != null && p.createdAt().isAfter(thirtyDaysAgo))
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            BigDecimal previousRevenue = completedPayments.stream()
                .filter(p -> p.createdAt() != null && 
                           p.createdAt().isAfter(sixtyDaysAgo) && 
                           p.createdAt().isBefore(thirtyDaysAgo))
                .map(PaymentServiceClient.Payment::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            String revenueTrend = previousRevenue.compareTo(BigDecimal.ZERO) > 0
                ? String.format("%.1f%%", 
                    recentRevenue.subtract(previousRevenue)
                        .divide(previousRevenue, 4, RoundingMode.HALF_UP)
                        .multiply(BigDecimal.valueOf(100))
                        .doubleValue())
                : "N/A";
            
            Map<String, Object> paymentMethods = Map.of(
                "pendingPayments", pendingPayments,
                "failedPayments", failedPayments,
                "cancelledPayments", cancelledPayments,
                "successRate", String.format("%.1f%%", successRate),
                "revenueTrend", revenueTrend,
                "note", "Payment method tracking not in model. Showing payment statistics instead."
            );
            
            return ResponseEntity.ok(Map.of(
                "reportType", "Revenue Analysis Report",
                "period", period != null ? period : "monthly",
                "data", Map.of(
                    "totalRevenue", "$" + totalRevenue.setScale(2, RoundingMode.HALF_UP),
                    "totalTransactions", completedPayments.size(),
                    "averageTransaction", "$" + avgTransaction.setScale(2, RoundingMode.HALF_UP),
                    "paymentMethods", paymentMethods,
                    "revenueByLot", revenueByLotFormatted.isEmpty() ? Map.of("note", "No revenue data by lot yet") : revenueByLotFormatted
                ),
                "generatedAt", LocalDateTime.now().toString()
            ));
        } catch (Exception e) {
            log.error("Error generating revenue report: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to generate revenue report: " + e.getMessage()));
        }
    }
}
