#!/bin/bash

# Complete Notification Service API Testing with RabbitMQ Event Testing

BASE_URL="http://localhost:8085"
GATEWAY_URL="http://localhost:8080"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

echo "========================================="
echo "COMPREHENSIVE NOTIFICATION SERVICE TESTING"
echo "========================================="
echo ""

# Get admin token for authenticated requests
ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ -z "$ADMIN_TOKEN" ]; then
    curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
        -H "Content-Type: application/json" \
        -d '{"fullName":"Test Admin","email":"admintest@example.com","password":"admin123","role":"ADMIN"}' > /dev/null
    sleep 1
    ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
        -H "Content-Type: application/json" \
        -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)
fi

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local token=$5
    local expected_code=${6:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ -z "$token" ]; then
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -d "${data}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
        fi
    else
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        fi
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "$body" | python3 -m json.tool 2>/dev/null | head -25 || echo "$body" | head -10
        echo "$body" > /tmp/last_response.json
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "$body"
        return 1
    fi
    echo ""
}

echo "========================================="
echo "PHASE 1: Service Status & Health"
echo "========================================="

# Test 1: Get service status
test_api "GET" "/api/notifications/status" "" "1.1 Get notification service status" "$ADMIN_TOKEN"

# Test 2: Health check
echo -e "${COLOR_YELLOW}[TEST] 1.2 Health check${COLOR_NC}"
HEALTH=$(curl -s http://localhost:8085/actuator/health)
echo "$HEALTH" | python3 -m json.tool 2>/dev/null || echo "$HEALTH"
if echo "$HEALTH" | grep -q "UP"; then
    echo -e "${COLOR_GREEN}✓ Service is UP${COLOR_NC}"
else
    echo -e "${COLOR_RED}✗ Service might be down${COLOR_NC}"
fi
echo ""

echo "========================================="
echo "PHASE 2: Direct Email Notifications"
echo "========================================="

# Test 3: Send email notification
TEST_EMAIL="test_$(date +%s)@example.com"
test_api "POST" "/api/notifications/email" "{\"to\":\"${TEST_EMAIL}\",\"subject\":\"Test Notification\",\"body\":\"This is a test email from the notification service.\"}" "2.1 Send test email notification" "$ADMIN_TOKEN"

# Test 4: Send email with HTML body
test_api "POST" "/api/notifications/email" "{\"to\":\"${TEST_EMAIL}\",\"subject\":\"Test HTML Email\",\"body\":\"<h1>Test</h1><p>This is an HTML email.</p>\"}" "2.2 Send HTML email notification" "$ADMIN_TOKEN"

# Test 5: Invalid email (validation test)
test_api "POST" "/api/notifications/email" "{\"to\":\"invalid-email\",\"subject\":\"Test\",\"body\":\"Test body\"}" "2.3 Send email with invalid email address (should fail)" "$ADMIN_TOKEN" 400

# Test 6: Missing fields (validation test)
test_api "POST" "/api/notifications/email" "{\"to\":\"test@example.com\"}" "2.4 Send email with missing fields (should fail)" "$ADMIN_TOKEN" 400

echo ""
echo "========================================="
echo "PHASE 3: RabbitMQ Event-Driven Notifications"
echo "========================================="

echo -e "${COLOR_BLUE}[INFO] Testing event-driven notifications...${COLOR_NC}"
echo ""

# Check RabbitMQ queues for notification service
echo "Checking RabbitMQ queues..."
RABBITMQ_QUEUES=$(curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "
import sys, json
data = json.load(sys.stdin)
notification_queues = [q for q in data if 'notification' in q['name'].lower()]
for q in notification_queues:
    print(f\"  Queue: {q['name']}\")
    print(f\"    Messages: {q.get('messages', 0)}\")
    print(f\"    Consumers: {q.get('consumers', 0)}\")
    print(f\"    Rate: {q.get('message_stats', {}).get('publish_details', {}).get('rate', 'N/A')}\")
    print()
" 2>/dev/null)

if [ ! -z "$RABBITMQ_QUEUES" ]; then
    echo "$RABBITMQ_QUEUES"
else
    echo "  No notification queues found or RabbitMQ not accessible"
fi

echo ""
echo "To test event-driven notifications:"
echo "  1. Create a booking → Should trigger booking.created event"
echo "  2. Complete a payment → Should trigger payment.status event"
echo "  3. Notification service should consume these events and send emails"
echo ""

echo "========================================="
echo "PHASE 4: Integration with Other Services"
echo "========================================="

# Test notification service's ability to call other services
echo -e "${COLOR_YELLOW}[TEST] 4.1 Check service integration${COLOR_NC}"
echo "  Testing if notification service can reach other services via Eureka..."

# Check Eureka registration
echo "Checking Eureka registration..."
EUREKA_SERVICES=$(curl -s http://localhost:8761/eureka/apps 2>/dev/null | grep -i "name>" | head -10)
if [ ! -z "$EUREKA_SERVICES" ]; then
    echo "  Registered services in Eureka:"
    echo "$EUREKA_SERVICES" | while read line; do
        echo "    - $line"
    done
else
    echo "  Could not fetch Eureka services"
fi
echo ""

echo "========================================="
echo "PHASE 5: Scheduled Reminders"
echo "========================================="

echo -e "${COLOR_YELLOW}[INFO] Scheduled Reminders${COLOR_NC}"
echo "  The notification service runs scheduled jobs to:"
echo "    - Send booking reminders (24 hours before)"
echo "    - Send payment reminders"
echo ""
echo "  These run via @Scheduled annotations and consume RabbitMQ events"
echo "  To verify, check service logs or wait for scheduled execution"
echo ""

echo "========================================="
echo "PHASE 6: Error Handling"
echo "========================================="

# Test error scenarios
echo -e "${COLOR_YELLOW}[TEST] 6.1 Test invalid request format${COLOR_NC}"
ERROR_RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}/api/notifications/email" \
    -H "Content-Type: application/json" \
    -d "{\"invalid\":\"data\"}")
ERROR_CODE=$(echo "$ERROR_RESPONSE" | tail -n1)
ERROR_BODY=$(echo "$ERROR_RESPONSE" | sed '$d')

if [ "$ERROR_CODE" -ge 400 ]; then
    echo -e "${COLOR_GREEN}✓ Error handling working (${ERROR_CODE})${COLOR_NC}"
    echo "$ERROR_BODY" | python3 -m json.tool 2>/dev/null | head -10 || echo "$ERROR_BODY" | head -5
else
    echo -e "${COLOR_YELLOW}⚠ Expected error but got ${ERROR_CODE}${COLOR_NC}"
fi
echo ""

echo "========================================="
echo "MONITORING SUMMARY"
echo "========================================="

echo -e "${COLOR_BLUE}[RABBITMQ] Notification service queues:${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "
import sys, json
data = json.load(sys.stdin)
notification_queues = [q for q in data if 'notification' in q['name'].lower()]
if notification_queues:
    for q in notification_queues:
        print(f\"  - {q['name']}: {q.get('messages', 0)} messages, {q.get('consumers', 0)} consumers\")
else:
    print('  No notification queues found')
" 2>/dev/null

echo ""
echo -e "${COLOR_BLUE}[REDIS] Cache status:${COLOR_NC}"
redis-cli PING 2>/dev/null && echo "  ✅ Redis is connected" || echo "  ❌ Redis not accessible"

echo ""
echo -e "${COLOR_BLUE}[EUREKA] Service registration:${COLOR_NC}"
EUREKA_CHECK=$(curl -s http://localhost:8761/eureka/apps/NOTIFICATION-SERVICE 2>/dev/null | grep -i "status>" | head -1)
if [ ! -z "$EUREKA_CHECK" ]; then
    echo "  ✅ Notification service registered in Eureka"
else
    echo "  ⚠️  Could not verify Eureka registration"
fi

echo ""
echo "========================================="
echo "NOTIFICATION SERVICE TESTING COMPLETE"
echo "========================================="

