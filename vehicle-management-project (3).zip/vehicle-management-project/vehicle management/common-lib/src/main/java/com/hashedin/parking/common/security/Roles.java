package com.hashedin.parking.common.security;

public enum Roles {
    USER, ADMIN, LOT_MANAGER
}
