package com.hashedin.parking.common.model;

public enum BookingStatus {
    CREATED,      // initial state before payment
    CONFIRMED,    // after payment success
    CANCELLED,    // user or system cancelled
    EXPIRED       // optional: booking time expired
}
