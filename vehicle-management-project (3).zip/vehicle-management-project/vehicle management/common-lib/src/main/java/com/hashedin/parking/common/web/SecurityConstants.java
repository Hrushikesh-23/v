package com.hashedin.parking.common.web;

public class SecurityConstants {
    public static final String AUTH_HEADER = "Authorization";
    public static final String BEARER_PREFIX = "Bearer ";
}
