package com.hashedin.parking.common.model;

public enum PaymentStatus {
    PENDING,       // created but not finalized
    COMPLETED,     // success
    FAILED,        // failure
    CANCELLED,     // cancelled due to booking cancel
    REFUND_REQUESTED, // completed then refund started
    EXPIRED
}