package com.hashedin.parking.common.events;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

import com.hashedin.parking.common.security.Roles;

public class Events {
    public record BookingCreated(UUID bookingId, UUID userId, Long lotId, Long spotId,
                                 LocalDateTime startTime, LocalDateTime endTime) {}
    public record BookingCancelled(UUID bookingId, UUID userId) {}
    public record PaymentStatusChanged(UUID paymentId, UUID bookingId, UUID userId,
                                       BigDecimal amount, String status) {}
    public record NotifyEmail(UUID userId, String toEmail, String subject, String body) {}
    public record UserProfileUpdated(UUID userId, String email, String fullName, Roles role) {}
}
