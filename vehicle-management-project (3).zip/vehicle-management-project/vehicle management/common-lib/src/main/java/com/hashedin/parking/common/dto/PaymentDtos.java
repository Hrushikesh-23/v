package com.hashedin.parking.common.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

public class PaymentDtos {
    public enum PaymentStatus { PENDING, COMPLETED, FAILED, EXPIRED }
    public record InitiatePaymentRequest(UUID bookingId, BigDecimal amount) {}
    public record PaymentResponse(UUID paymentId, UUID bookingId, BigDecimal amount, PaymentStatus status, LocalDateTime createdAt) {}
}
