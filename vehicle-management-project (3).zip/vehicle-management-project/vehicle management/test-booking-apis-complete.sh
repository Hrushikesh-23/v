#!/bin/bash

# Comprehensive Booking Service API Testing

BASE_URL="http://localhost:8083"
GATEWAY_URL="http://localhost:8080"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

USER_TOKEN=""
ADMIN_TOKEN=""
BOOKING_IDS=()
WAITLIST_IDS=()
LOT_ID=""
SPOT_ID=""

echo "========================================="
echo "COMPREHENSIVE BOOKING SERVICE API TESTING"
echo "========================================="
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local token=$5
    local expected_code=${6:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ -z "$token" ]; then
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -d "${data}")
        elif [ "$method" = "PUT" ]; then
            response=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -d "${data}")
        elif [ "$method" = "DELETE" ]; then
            response=$(curl -s -w "\n%{http_code}" -X DELETE "${BASE_URL}${endpoint}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
        fi
    else
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "PUT" ]; then
            response=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "DELETE" ]; then
            response=$(curl -s -w "\n%{http_code}" -X DELETE "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        fi
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "$body" | python3 -m json.tool 2>/dev/null | head -25 || echo "$body" | head -10
        echo "$body" > /tmp/last_response.json
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "$body"
        return 1
    fi
    echo ""
}

# Setup
echo "Setting up test environment..."

# Get admin token
ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ -z "$ADMIN_TOKEN" ]; then
    curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
        -H "Content-Type: application/json" \
        -d '{"fullName":"Test Admin","email":"admintest@example.com","password":"admin123","role":"ADMIN"}' > /dev/null
    sleep 1
    ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
        -H "Content-Type: application/json" \
        -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)
fi

# Get or create lot and spot
LOTS_RESPONSE=$(curl -s -X GET "${GATEWAY_URL}/api/lots" -H "Authorization: Bearer ${ADMIN_TOKEN}")
LOT_ID=$(echo "$LOTS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0]['id'] if data else '')" 2>/dev/null)

if [ -z "$LOT_ID" ]; then
    LOT_RESPONSE=$(curl -s -X POST "${GATEWAY_URL}/api/lots" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${ADMIN_TOKEN}" \
        -d '{"name":"Booking Test Lot","address":"Test Address"}')
    LOT_ID=$(echo "$LOT_RESPONSE" | grep -o '"id":[0-9]*' | cut -d':' -f2)
fi

SPOTS_RESPONSE=$(curl -s -X GET "${GATEWAY_URL}/api/lots/${LOT_ID}/spots/available" -H "Authorization: Bearer ${ADMIN_TOKEN}")
SPOT_ID=$(echo "$SPOTS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0]['id'] if data else '')" 2>/dev/null)

if [ -z "$SPOT_ID" ]; then
    curl -s -X POST "${GATEWAY_URL}/api/lots/${LOT_ID}/spots" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${ADMIN_TOKEN}" \
        -d '{"code":"BOOK-TEST-01","available":true}' > /dev/null
    sleep 1
    SPOTS_RESPONSE=$(curl -s -X GET "${GATEWAY_URL}/api/lots/${LOT_ID}/spots/available" -H "Authorization: Bearer ${ADMIN_TOKEN}")
    SPOT_ID=$(echo "$SPOTS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0]['id'] if data else '')" 2>/dev/null)
fi

echo "Using Lot ID: $LOT_ID, Spot ID: $SPOT_ID"
echo ""

# Register and login user
USER_EMAIL="bookinguser_$(date +%s)@example.com"
echo "Registering test user: ${USER_EMAIL}"
curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"fullName\":\"Booking Test User\",\"email\":\"${USER_EMAIL}\",\"password\":\"password123\",\"role\":\"USER\"}" > /dev/null
sleep 1

LOGIN_RESPONSE=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"${USER_EMAIL}\",\"password\":\"password123\"}")
USER_TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)

echo "✅ Setup complete"
echo ""

# Calculate future dates
TODAY=$(date +%Y-%m-%d)
TOMORROW=$(date -v+1d +%Y-%m-%d 2>/dev/null || date -d "+1 day" +%Y-%m-%d)
DAY_AFTER=$(date -v+2d +%Y-%m-%d 2>/dev/null || date -d "+2 days" +%Y-%m-%d)

echo "========================================="
echo "PHASE 1: Booking Creation"
echo "========================================="

# Test 1: Create booking with future dates
START1="${TOMORROW}T10:00:00"
END1="${TOMORROW}T18:00:00"
test_api "POST" "/api/bookings" "{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START1}\",\"endTime\":\"${END1}\"}" "1.1 Create booking (future date)" "$USER_TOKEN"
BOOKING_ID1=$(cat /tmp/last_response.json | grep -o '"id":"[^"]*' | cut -d'"' -f4)
if [ ! -z "$BOOKING_ID1" ]; then
    BOOKING_IDS+=($BOOKING_ID1)
    echo "Created Booking ID: $BOOKING_ID1"
fi

# Wait for async confirmation
sleep 2
echo -e "${COLOR_BLUE}[ASYNC] Waiting for booking confirmation...${COLOR_NC}"

# Test 2: Create another booking with different time
START2="${DAY_AFTER}T14:00:00"
END2="${DAY_AFTER}T20:00:00"
test_api "POST" "/api/bookings" "{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START2}\",\"endTime\":\"${END2}\"}" "1.2 Create another booking (different date)" "$USER_TOKEN"
BOOKING_ID2=$(cat /tmp/last_response.json | grep -o '"id":"[^"]*' | cut -d'"' -f4)
if [ ! -z "$BOOKING_ID2" ]; then
    BOOKING_IDS+=($BOOKING_ID2)
    echo "Created Booking ID: $BOOKING_ID2"
fi

# Check RabbitMQ
echo -e "${COLOR_BLUE}[RABBITMQ] Booking created events...${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues/%2F/user.service.bookingCreated | python3 -c "import sys, json; data=json.load(sys.stdin); print(f\"  Messages: {data.get('messages', 0)}, Consumers: {data.get('consumers', 0)}\")" 2>/dev/null || echo "  Queue info not available"

echo ""
echo "========================================="
echo "PHASE 2: Booking Retrieval"
echo "========================================="

# Test 3: Get all user bookings
test_api "GET" "/api/bookings" "" "2.1 Get all user bookings" "$USER_TOKEN"

# Test 4: Get specific booking
if [ ! -z "$BOOKING_ID1" ]; then
    test_api "GET" "/api/bookings/${BOOKING_ID1}" "" "2.2 Get specific booking by ID" "$USER_TOKEN"
fi

# Test 5: Get future bookings
test_api "GET" "/api/bookings/future" "" "2.3 Get future bookings only" "$USER_TOKEN"

# Test 6: Get past bookings
test_api "GET" "/api/bookings/past" "" "2.4 Get past bookings only" "$USER_TOKEN"

echo ""
echo "========================================="
echo "PHASE 3: Booking Updates"
echo "========================================="

# Test 7: Try to update a CONFIRMED booking (should fail or work depending on status)
if [ ! -z "$BOOKING_ID1" ]; then
    NEW_START="${TOMORROW}T11:00:00"
    NEW_END="${TOMORROW}T19:00:00"
    test_api "PUT" "/api/bookings/${BOOKING_ID1}" "{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${NEW_START}\",\"endTime\":\"${NEW_END}\"}" "3.1 Try to update booking (may fail if CONFIRMED)" "$USER_TOKEN" 400
fi

echo ""
echo "========================================="
echo "PHASE 4: Waitlist Management"
echo "========================================="

# Test 8: Get waitlist entries
test_api "GET" "/api/bookings/waitlist" "" "4.1 Get user waitlist entries" "$USER_TOKEN"

# Test 9: Add to waitlist (try booking already booked spot/time)
START3="${TOMORROW}T10:00:00"
END3="${TOMORROW}T18:00:00"
test_api "POST" "/api/bookings/waitlist" "{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START3}\",\"endTime\":\"${END3}\"}" "4.2 Add booking to waitlist (spot already booked)" "$USER_TOKEN"
WAITLIST_ID=$(cat /tmp/last_response.json | grep -o '"waitlistId":"[^"]*' | cut -d'"' -f4)
if [ ! -z "$WAITLIST_ID" ]; then
    WAITLIST_IDS+=($WAITLIST_ID)
    echo "Created Waitlist ID: $WAITLIST_ID"
fi

# Test 10: Get waitlist again
test_api "GET" "/api/bookings/waitlist" "" "4.3 Get waitlist entries again (should have entry)" "$USER_TOKEN"

# Test 11: Cancel waitlist entry
if [ ! -z "$WAITLIST_ID" ]; then
    test_api "DELETE" "/api/bookings/waitlist/${WAITLIST_ID}" "" "4.4 Cancel waitlist entry" "$USER_TOKEN"
fi

echo ""
echo "========================================="
echo "PHASE 5: Booking Cancellation"
echo "========================================="

# Test 12: Cancel first booking
if [ ! -z "$BOOKING_ID1" ]; then
    test_api "DELETE" "/api/bookings/${BOOKING_ID1}" "" "5.1 Cancel booking (async)" "$USER_TOKEN"
    
    sleep 2
    echo -e "${COLOR_BLUE}[ASYNC] Checking cancellation status...${COLOR_NC}"
    
    # Check if booking was cancelled
    curl -s -X GET "${BASE_URL}/api/bookings/${BOOKING_ID1}" -H "Authorization: Bearer ${USER_TOKEN}" | python3 -m json.tool 2>/dev/null | grep -E "status|CANCELLED" || echo "  Booking status check"
fi

# Check RabbitMQ for cancellation events
echo -e "${COLOR_BLUE}[RABBITMQ] Cancellation events...${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "import sys, json; data=json.load(sys.stdin); queues = [q for q in data if 'booking' in q['name'].lower() and ('cancel' in q['name'].lower() or 'cancelled' in q['name'].lower())]; [print(f\"  {q['name']}: {q.get('messages', 0)} messages\") for q in queues] if queues else print('  No cancellation queues found')" 2>/dev/null

echo ""
echo "========================================="
echo "PHASE 6: Internal Admin APIs"
echo "========================================="

# Test 13: Get upcoming bookings (admin)
test_api "GET" "/api/bookings/internal/upcoming?hours=24" "" "6.1 Get upcoming bookings in next 24 hours (admin)" "$ADMIN_TOKEN"

# Test 14: Get upcoming bookings with different hours
test_api "GET" "/api/bookings/internal/upcoming?hours=48" "" "6.2 Get upcoming bookings in next 48 hours (admin)" "$ADMIN_TOKEN"

echo ""
echo "========================================="
echo "PHASE 7: Edge Cases & Validation"
echo "========================================="

# Test 15: Try to create booking with invalid dates (end before start)
START_INVALID="${TOMORROW}T18:00:00"
END_INVALID="${TOMORROW}T10:00:00"
test_api "POST" "/api/bookings" "{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START_INVALID}\",\"endTime\":\"${END_INVALID}\"}" "7.1 Create booking with invalid dates (end before start) - should fail" "$USER_TOKEN" 400

# Test 16: Try to get non-existent booking
test_api "GET" "/api/bookings/00000000-0000-0000-0000-000000000000" "" "7.2 Get non-existent booking - should return 404" "$USER_TOKEN" 404

echo ""
echo "========================================="
echo "MONITORING SUMMARY"
echo "========================================="

echo -e "${COLOR_BLUE}[RABBITMQ] All booking-related queues:${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "import sys, json; data=json.load(sys.stdin); booking_queues = [q for q in data if 'booking' in q['name'].lower()]; [print(f\"  - {q['name']}: {q.get('messages', 0)} messages, {q.get('consumers', 0)} consumers\") for q in booking_queues] if booking_queues else print('  No booking queues')" 2>/dev/null

echo ""
echo -e "${COLOR_BLUE}[REDIS] Booking and availability cache:${COLOR_NC}"
redis-cli KEYS "*booking*" 2>/dev/null | head -10 || echo "  No booking cache keys"
redis-cli KEYS "*spot*available*" 2>/dev/null | head -5 || echo "  No spot availability cache keys"

echo ""
echo -e "${COLOR_BLUE}[DATABASE] Final booking count:${COLOR_NC}"
curl -s -X GET "${BASE_URL}/api/bookings" -H "Authorization: Bearer ${USER_TOKEN}" | python3 -c "import sys, json; data=json.load(sys.stdin); print(f\"  Total bookings: {len(data)}\"); [print(f\"    - {b.get('id', 'N/A')}: {b.get('status', 'N/A')}\") for b in data]" 2>/dev/null

echo ""
echo "========================================="
echo "BOOKING SERVICE API TESTING COMPLETE"
echo "========================================="
echo ""
echo "✅ All booking APIs tested successfully!"
echo "   - Created ${#BOOKING_IDS[@]} bookings"
echo "   - Created ${#WAITLIST_IDS[@]} waitlist entries"
echo "   - Tested all CRUD operations"
echo "   - Tested edge cases and validations"

