#!/bin/bash

# Vehicle Parking Management System - Complete Testing Script
# This script tests all services step by step following the complete flow

BASE_URL="http://localhost:8080"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_NC='\033[0m' # No Color

echo "========================================="
echo "Vehicle Parking Management System"
echo "Complete API Testing Flow"
echo "========================================="
echo ""

# Function to test endpoint
test_endpoint() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local token=$5
    
    echo -e "${COLOR_YELLOW}Testing: ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ -z "$token" ]; then
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -d "${data}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
        fi
    else
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "PUT" ]; then
            response=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "DELETE" ]; then
            response=$(curl -s -w "\n%{http_code}" -X DELETE "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        fi
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo -e "${COLOR_GREEN}✓ Success (${http_code})${COLOR_NC}"
        echo "  Response: $body" | head -c 200
        echo ""
        echo "$body"
        return 0
    else
        echo -e "${COLOR_RED}✗ Failed (${http_code})${COLOR_NC}"
        echo "  Response: $body"
        return 1
    fi
    echo ""
}

# Wait for service to be ready
wait_for_service() {
    local port=$1
    local service_name=$2
    echo "Waiting for ${service_name} to be ready on port ${port}..."
    
    for i in {1..30}; do
        if curl -s "http://localhost:${port}/actuator/health" > /dev/null 2>&1; then
            echo -e "${COLOR_GREEN}✓ ${service_name} is ready!${COLOR_NC}"
            return 0
        fi
        sleep 2
    done
    
    echo -e "${COLOR_RED}✗ ${service_name} did not become ready${COLOR_NC}"
    return 1
}

echo "========================================="
echo "STEP 1: User Registration & Authentication"
echo "========================================="

# Register User
USER_DATA='{"fullName":"John Doe","email":"john.doe@example.com","password":"password123","role":"USER"}'
test_endpoint "POST" "/api/auth/register" "$USER_DATA" "Register new user"

# Register Admin
ADMIN_DATA='{"fullName":"Admin User","email":"admin@example.com","password":"admin123","role":"ADMIN"}'
test_endpoint "POST" "/api/auth/register" "$ADMIN_DATA" "Register admin user"

# Login User
LOGIN_DATA='{"email":"john.doe@example.com","password":"password123"}'
echo "Logging in user..."
USER_TOKEN_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "$LOGIN_DATA")
USER_TOKEN=$(echo "$USER_TOKEN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
echo "User Token: ${USER_TOKEN:0:50}..."

# Login Admin
ADMIN_LOGIN_DATA='{"email":"admin@example.com","password":"admin123"}'
echo "Logging in admin..."
ADMIN_TOKEN_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "$ADMIN_LOGIN_DATA")
ADMIN_TOKEN=$(echo "$ADMIN_TOKEN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
echo "Admin Token: ${ADMIN_TOKEN:0:50}..."

# Get User Profile
test_endpoint "GET" "/api/users/profile" "" "Get user profile" "$USER_TOKEN"

echo ""
echo "========================================="
echo "STEP 2: Admin - Parking Lot & Spot Management"
echo "========================================="

# Create Parking Lot
LOT_DATA='{"name":"Downtown Parking","address":"123 Main Street, City"}'
LOT_RESPONSE=$(test_endpoint "POST" "/api/lots" "$LOT_DATA" "Create parking lot" "$ADMIN_TOKEN")
LOT_ID=$(echo "$LOT_RESPONSE" | grep -o '"id":[0-9]*' | cut -d':' -f2)
echo "Created Lot ID: $LOT_ID"

# Add Parking Spot
SPOT_DATA='{"code":"A-01","available":true}'
SPOT_RESPONSE=$(test_endpoint "POST" "/api/lots/${LOT_ID}/spots" "$SPOT_DATA" "Add parking spot" "$ADMIN_TOKEN")
SPOT_ID=$(echo "$SPOT_RESPONSE" | grep -o '"id":[0-9]*' | cut -d':' -f2)
echo "Created Spot ID: $SPOT_ID"

# Get All Lots
test_endpoint "GET" "/api/lots" "" "Get all parking lots" "$ADMIN_TOKEN"

# Get Available Spots
test_endpoint "GET" "/api/lots/${LOT_ID}/spots/available" "" "Get available spots" "$ADMIN_TOKEN"

echo ""
echo "========================================="
echo "STEP 3: User - Booking Management"
echo "========================================="

# Create Booking
START_TIME=$(date -u -v+1H +"%Y-%m-%dT%H:00:00" 2>/dev/null || date -u -d "+1 hour" +"%Y-%m-%dT%H:00:00" 2>/dev/null || echo "2024-12-01T10:00:00")
END_TIME=$(date -u -v+9H +"%Y-%m-%dT%H:00:00" 2>/dev/null || date -u -d "+9 hours" +"%Y-%m-%dT%H:00:00" 2>/dev/null || echo "2024-12-01T18:00:00")

BOOKING_DATA="{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START_TIME}\",\"endTime\":\"${END_TIME}\"}"
BOOKING_RESPONSE=$(test_endpoint "POST" "/api/bookings" "$BOOKING_DATA" "Create booking" "$USER_TOKEN")
BOOKING_ID=$(echo "$BOOKING_RESPONSE" | grep -o '"id":"[^"]*' | cut -d'"' -f4)
echo "Created Booking ID: $BOOKING_ID"

# Get My Bookings
test_endpoint "GET" "/api/bookings" "" "Get user bookings" "$USER_TOKEN"

# Get Specific Booking
if [ ! -z "$BOOKING_ID" ]; then
    test_endpoint "GET" "/api/bookings/${BOOKING_ID}" "" "Get specific booking" "$USER_TOKEN"
fi

echo ""
echo "========================================="
echo "STEP 4: Payment Processing"
echo "========================================="

# Initiate Payment
PAYMENT_DATA="{\"bookingId\":\"${BOOKING_ID}\",\"amount\":25.50}"
PAYMENT_RESPONSE=$(test_endpoint "POST" "/api/payments" "$PAYMENT_DATA" "Initiate payment" "$USER_TOKEN")
PAYMENT_ID=$(echo "$PAYMENT_RESPONSE" | grep -o '"id":"[^"]*' | cut -d'"' -f4)
echo "Created Payment ID: $PAYMENT_ID"

# Confirm Payment
if [ ! -z "$PAYMENT_ID" ]; then
    echo "Confirming payment (will process asynchronously with 3 second delay)..."
    test_endpoint "POST" "/api/payments/${PAYMENT_ID}/confirm" "" "Confirm payment" "$USER_TOKEN"
    echo "Waiting 5 seconds for async processing..."
    sleep 5
fi

# Get My Payments
test_endpoint "GET" "/api/payments" "" "Get user payments" "$USER_TOKEN"

echo ""
echo "========================================="
echo "STEP 5: Profile Management"
echo "========================================="

# Update Profile
UPDATE_PROFILE_DATA='{"fullName":"John Updated Doe","email":"john.updated@example.com"}'
test_endpoint "PUT" "/api/users/profile" "$UPDATE_PROFILE_DATA" "Update user profile" "$USER_TOKEN"

echo ""
echo "========================================="
echo "STEP 6: Admin Operations"
echo "========================================="

# Get All Payments (Admin)
test_endpoint "GET" "/api/payments/admin/all" "" "Get all payments (admin)" "$ADMIN_TOKEN"

# Get Dashboard Stats
test_endpoint "GET" "/api/admin/dashboard/stats" "" "Get dashboard stats" "$ADMIN_TOKEN"

echo ""
echo "========================================="
echo "Testing Complete!"
echo "========================================="

