#!/bin/bash

# Complete User Service API Testing with RabbitMQ and Redis Monitoring

BASE_URL="http://localhost:8081"
GATEWAY_URL="http://localhost:8080"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

USER_TOKEN=""
ADMIN_TOKEN=""
USER_ID=""
TEST_USER_EMAIL="testuser_$(date +%s)@example.com"

echo "========================================="
echo "COMPREHENSIVE USER SERVICE API TESTING"
echo "========================================="
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local token=$5
    local expected_code=${6:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ -z "$token" ]; then
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -d "${data}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
        fi
    else
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "PUT" ]; then
            response=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "DELETE" ]; then
            response=$(curl -s -w "\n%{http_code}" -X DELETE "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        fi
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "  Response: $body" | head -c 300
        echo ""
        echo "$body" > /tmp/last_response.json
        echo "$body"
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "  Response: $body"
        return 1
    fi
    echo ""
}

# Check RabbitMQ queue
check_rabbitmq() {
    echo -e "${COLOR_BLUE}[RABBITMQ] Checking queue: $1${COLOR_NC}"
    curl -s -u guest:guest http://localhost:15672/api/queues | python3 -m json.tool 2>/dev/null | grep -A 5 "$1" || echo "  Queue info not available"
}

# Check Redis cache
check_redis() {
    echo -e "${COLOR_BLUE}[REDIS] Checking key: $1${COLOR_NC}"
    redis-cli GET "$1" 2>/dev/null || echo "  Key not found or Redis not accessible"
}

echo "========================================="
echo "PHASE 1: Authentication APIs"
echo "========================================="

# 1. Register User
REGISTER_DATA="{\"fullName\":\"John Test Doe\",\"email\":\"${TEST_USER_EMAIL}\",\"password\":\"password123\",\"role\":\"USER\"}"
test_api "POST" "/api/auth/register" "$REGISTER_DATA" "1.1 Register new USER"
USER_ID=$(cat /tmp/last_response.json | grep -o '"id":"[^"]*' | cut -d'"' -f4)
echo "Registered User ID: $USER_ID"

# 2. Register Admin
ADMIN_EMAIL="admin_$(date +%s)@example.com"
ADMIN_REGISTER_DATA="{\"fullName\":\"Admin Test User\",\"email\":\"${ADMIN_EMAIL}\",\"password\":\"admin123\",\"role\":\"ADMIN\"}"
test_api "POST" "/api/auth/register" "$ADMIN_REGISTER_DATA" "1.2 Register ADMIN user"

# 3. Login User
LOGIN_DATA="{\"email\":\"${TEST_USER_EMAIL}\",\"password\":\"password123\"}"
echo -e "${COLOR_YELLOW}[TEST] 1.3 User Login${COLOR_NC}"
LOGIN_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "$LOGIN_DATA")
USER_TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
if [ ! -z "$USER_TOKEN" ]; then
    echo -e "${COLOR_GREEN}✓ PASS - Token received${COLOR_NC}"
    echo "  Token: ${USER_TOKEN:0:50}..."
else
    echo -e "${COLOR_RED}✗ FAIL - No token received${COLOR_NC}"
fi
echo ""

# 4. Login Admin
ADMIN_LOGIN_DATA="{\"email\":\"${ADMIN_EMAIL}\",\"password\":\"admin123\"}"
echo -e "${COLOR_YELLOW}[TEST] 1.4 Admin Login${COLOR_NC}"
ADMIN_LOGIN_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "$ADMIN_LOGIN_DATA")
ADMIN_TOKEN=$(echo "$ADMIN_LOGIN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
if [ ! -z "$ADMIN_TOKEN" ]; then
    echo -e "${COLOR_GREEN}✓ PASS - Admin token received${COLOR_NC}"
else
    echo -e "${COLOR_RED}✗ FAIL - No admin token received${COLOR_NC}"
fi
echo ""

# Check Redis after registration
sleep 2
check_redis "user:profile:${USER_ID}"

echo ""
echo "========================================="
echo "PHASE 2: User Profile APIs"
echo "========================================="

# 5. Get User Profile
test_api "GET" "/api/users/profile" "" "2.1 Get current user profile" "$USER_TOKEN"

# Check Redis cache after profile fetch
check_redis "user:profile:${USER_ID}"

# 6. Update User Profile
UPDATE_DATA="{\"fullName\":\"John Updated Doe\",\"email\":\"${TEST_USER_EMAIL}\"}"
test_api "PUT" "/api/users/profile" "$UPDATE_DATA" "2.2 Update user profile" "$USER_TOKEN"

# Check RabbitMQ for profile update event
sleep 2
check_rabbitmq "user.service.userProfileUpdated"
check_redis "user:profile:${USER_ID}"

# 7. Get Updated Profile
test_api "GET" "/api/users/profile" "" "2.3 Get updated profile (verify cache)" "$USER_TOKEN"

echo ""
echo "========================================="
echo "PHASE 3: Password Management APIs"
echo "========================================="

# 8. Change Password
CHANGE_PWD_DATA="{\"oldPassword\":\"password123\",\"newPassword\":\"newpassword123\"}"
test_api "POST" "/api/auth/change-password" "$CHANGE_PWD_DATA" "3.1 Change password" "$USER_TOKEN"

# 9. Test login with new password
NEW_LOGIN_DATA="{\"email\":\"${TEST_USER_EMAIL}\",\"password\":\"newpassword123\"}"
echo -e "${COLOR_YELLOW}[TEST] 3.2 Login with new password${COLOR_NC}"
NEW_LOGIN_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "$NEW_LOGIN_DATA")
NEW_USER_TOKEN=$(echo "$NEW_LOGIN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
if [ ! -z "$NEW_USER_TOKEN" ]; then
    echo -e "${COLOR_GREEN}✓ PASS - Login successful with new password${COLOR_NC}"
    USER_TOKEN=$NEW_USER_TOKEN
else
    echo -e "${COLOR_RED}✗ FAIL - Login failed with new password${COLOR_NC}"
fi
echo ""

# 10. Forgot Password
FORGOT_PWD_EMAIL="forgot_$(date +%s)@example.com"
# First register a user for forgot password test
REGISTER_FORGOT_DATA="{\"fullName\":\"Forgot Test User\",\"email\":\"${FORGOT_PWD_EMAIL}\",\"password\":\"oldpass123\",\"role\":\"USER\"}"
curl -s -X POST "${BASE_URL}/api/auth/register" -H "Content-Type: application/json" -d "$REGISTER_FORGOT_DATA" > /dev/null
sleep 1

FORGOT_DATA="{\"email\":\"${FORGOT_PWD_EMAIL}\"}"
test_api "POST" "/api/auth/forgot-password" "$FORGOT_DATA" "3.3 Request password reset (forgot password)"

# 11. Reset Password (this would need actual token from email in production)
RESET_DATA="{\"token\":\"test-token-123\",\"newPassword\":\"resetpass123\"}"
test_api "POST" "/api/auth/reset-password" "$RESET_DATA" "3.4 Reset password with token" "" 400

echo ""
echo "========================================="
echo "PHASE 4: Logout API"
echo "========================================="

# 12. Logout
test_api "POST" "/api/auth/logout" "" "4.1 User logout" "$USER_TOKEN"

# 13. Test that token is blacklisted (should fail)
test_api "GET" "/api/users/profile" "" "4.2 Access profile after logout (should fail)" "$USER_TOKEN" 401

echo ""
echo "========================================="
echo "PHASE 5: Internal/Admin APIs"
echo "========================================="

# 14. Get User Email by ID (Internal Admin API)
test_api "GET" "/api/users/internal/${USER_ID}/email" "" "5.1 Get user email by ID (admin only)" "$ADMIN_TOKEN"

# 15. Test User Role Access
test_api "GET" "/api/users/test-role" "" "5.2 Test user role access endpoint" "$USER_TOKEN"

echo ""
echo "========================================="
echo "PHASE 6: Gateway Routing Test"
echo "========================================="

# 16. Test via Gateway
echo -e "${COLOR_YELLOW}[TEST] 6.1 Test registration via API Gateway${COLOR_NC}"
GATEWAY_TEST_EMAIL="gateway_$(date +%s)@example.com"
GATEWAY_REGISTER_DATA="{\"fullName\":\"Gateway Test User\",\"email\":\"${GATEWAY_TEST_EMAIL}\",\"password\":\"pass123\",\"role\":\"USER\"}"
GATEWAY_RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "${GATEWAY_URL}/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "${GATEWAY_REGISTER_DATA}")
GATEWAY_CODE=$(echo "$GATEWAY_RESPONSE" | tail -n1)
if [ "$GATEWAY_CODE" -eq 200 ]; then
    echo -e "${COLOR_GREEN}✓ PASS - Gateway routing working${COLOR_NC}"
else
    echo -e "${COLOR_RED}✗ FAIL - Gateway routing failed (${GATEWAY_CODE})${COLOR_NC}"
fi
echo ""

echo ""
echo "========================================="
echo "FINAL MONITORING CHECK"
echo "========================================="

echo -e "${COLOR_BLUE}[RABBITMQ] Listing all queues:${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -m json.tool 2>/dev/null | grep -E '"name"|"messages"' | head -20

echo ""
echo -e "${COLOR_BLUE}[REDIS] Checking user profile cache keys:${COLOR_NC}"
redis-cli KEYS "user:profile:*" 2>/dev/null | head -10

echo ""
echo "========================================="
echo "USER SERVICE TESTING COMPLETE"
echo "========================================="
echo ""
echo "Summary:"
echo "- All authentication APIs tested"
echo "- All profile management APIs tested"
echo "- Password management APIs tested"
echo "- Logout and token blacklisting tested"
echo "- Admin/internal APIs tested"
echo "- Gateway routing verified"
echo "- RabbitMQ events monitored"
echo "- Redis cache operations verified"

