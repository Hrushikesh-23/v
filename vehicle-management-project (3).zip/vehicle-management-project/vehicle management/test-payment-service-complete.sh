#!/bin/bash

# Complete Payment Service API Testing with RabbitMQ and Redis Monitoring

BASE_URL="http://localhost:8084"
GATEWAY_URL="http://localhost:8080"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

USER_TOKEN=""
ADMIN_TOKEN=""
BOOKING_ID=""
PAYMENT_ID=""

echo "========================================="
echo "COMPREHENSIVE PAYMENT SERVICE API TESTING"
echo "========================================="
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local token=$5
    local expected_code=${6:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ -z "$token" ]; then
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -d "${data}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
        fi
    else
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        fi
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "$body" | python3 -m json.tool 2>/dev/null | head -20 || echo "$body" | head -10
        echo "$body" > /tmp/last_response.json
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "$body"
        return 1
    fi
    echo ""
}

# Setup: Get admin token
echo "Getting admin token..."
ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ -z "$ADMIN_TOKEN" ]; then
    echo "Creating admin user..."
    curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
        -H "Content-Type: application/json" \
        -d '{"fullName":"Test Admin","email":"admintest@example.com","password":"admin123","role":"ADMIN"}' > /dev/null
    sleep 1
    ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
        -H "Content-Type: application/json" \
        -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)
fi

# Register and login user
USER_EMAIL="paymentuser_$(date +%s)@example.com"
echo "Registering test user..."
curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"fullName\":\"Payment Test User\",\"email\":\"${USER_EMAIL}\",\"password\":\"password123\",\"role\":\"USER\"}" > /dev/null
sleep 1

LOGIN_RESPONSE=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"${USER_EMAIL}\",\"password\":\"password123\"}")
USER_TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)

# Create a booking for payment testing
echo "Creating booking for payment test..."
BOOKING_RESPONSE=$(curl -s -X POST "${GATEWAY_URL}/api/bookings" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${USER_TOKEN}" \
    -d "{\"lotId\":1,\"spotId\":2,\"startTime\":\"2025-11-02T10:00:00\",\"endTime\":\"2025-11-02T18:00:00\"}")
BOOKING_ID=$(echo "$BOOKING_RESPONSE" | grep -o '"id":"[^"]*' | cut -d'"' -f4)

if [ -z "$BOOKING_ID" ]; then
    # Try to get existing booking
    BOOKINGS_RESPONSE=$(curl -s -X GET "${GATEWAY_URL}/api/bookings" -H "Authorization: Bearer ${USER_TOKEN}")
    BOOKING_ID=$(echo "$BOOKINGS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0]['id'] if data else '')" 2>/dev/null)
fi

echo "Using Booking ID: $BOOKING_ID"
echo "✅ Setup complete"
echo ""

echo "========================================="
echo "PHASE 1: Payment Initiation & Management"
echo "========================================="

# 1. Initiate Payment
if [ ! -z "$BOOKING_ID" ]; then
    test_api "POST" "/api/payments" "{\"bookingId\":\"${BOOKING_ID}\",\"amount\":25.50}" "1.1 Initiate payment" "$USER_TOKEN"
    PAYMENT_ID=$(cat /tmp/last_response.json | grep -o '"id":"[^"]*' | cut -d'"' -f4)
    echo "Created Payment ID: $PAYMENT_ID"
    
    # Check RabbitMQ for payment status changed event
    sleep 2
    echo -e "${COLOR_BLUE}[RABBITMQ] Checking payment.statusChanged queue...${COLOR_NC}"
    curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "import sys, json; data=json.load(sys.stdin); queues = [q for q in data if 'payment' in q['name'].lower()]; [print(f\"  Queue: {q['name']}, Messages: {q.get('messages', 0)}\") for q in queues] if queues else print('  No payment queues')" 2>/dev/null
    
    # Check Redis cache
    echo -e "${COLOR_BLUE}[REDIS] Checking payment cache...${COLOR_NC}"
    redis-cli KEYS "*payment*" 2>/dev/null | head -5 || echo "  No payment cache keys yet"
fi

# 2. Get My Payments
test_api "GET" "/api/payments" "" "1.2 Get user payments" "$USER_TOKEN"

# 3. Get Payment by Booking
if [ ! -z "$BOOKING_ID" ]; then
    test_api "GET" "/api/payments/booking/${BOOKING_ID}" "" "1.3 Get payments by booking ID" "$USER_TOKEN"
fi

echo ""
echo "========================================="
echo "PHASE 2: Payment Confirmation"
echo "========================================="

# 4. Confirm Payment (async)
if [ ! -z "$PAYMENT_ID" ]; then
    test_api "POST" "/api/payments/${PAYMENT_ID}/confirm" "" "2.1 Confirm payment (async)" ""
    
    # Wait for async processing
    sleep 3
    echo "Waiting for async payment confirmation..."
    
    # Check payment status
    echo "Checking updated payment status..."
    curl -s -X GET "${BASE_URL}/api/payments/booking/${BOOKING_ID}" -H "Authorization: Bearer ${USER_TOKEN}" | python3 -m json.tool 2>/dev/null | grep -E "status|amount" | head -5
fi

echo ""
echo "========================================="
echo "PHASE 3: Payment Queries & Filters"
echo "========================================="

# 5. Get Payments by Date Range (with Redis caching)
FROM_DATE=$(date -u -v-7d +"%Y-%m-%dT00:00:00" 2>/dev/null || date -u -d "7 days ago" +"%Y-%m-%dT00:00:00" 2>/dev/null || echo "2024-11-01T00:00:00")
TO_DATE=$(date -u +"%Y-%m-%dT23:59:59" 2>/dev/null || echo "2024-12-01T23:59:59")
test_api "GET" "/api/payments/date-range?from=${FROM_DATE}&to=${TO_DATE}" "" "3.1 Get payments by date range (CACHED)" "$USER_TOKEN"

# Check Redis cache for date range query
echo -e "${COLOR_BLUE}[REDIS] Checking date range cache...${COLOR_NC}"
redis-cli KEYS "*dateRange*" 2>/dev/null | head -3 || echo "  No date range cache keys"

# 6. Get Payments by Status
test_api "GET" "/api/payments/status/COMPLETED" "" "3.2 Get payments by status (CACHED)" "$USER_TOKEN"
test_api "GET" "/api/payments/status/PENDING" "" "3.3 Get pending payments (CACHED)" "$USER_TOKEN"

# Check Redis cache for status query
echo -e "${COLOR_BLUE}[REDIS] Checking status cache...${COLOR_NC}"
redis-cli KEYS "*status*" 2>/dev/null | head -3 || echo "  No status cache keys"

echo ""
echo "========================================="
echo "PHASE 4: Admin APIs"
echo "========================================="

# 7. Get All Payments (Admin)
test_api "GET" "/api/payments/admin/all" "" "4.1 Get all payments (admin)" "$ADMIN_TOKEN"

# 8. Get Payments by User ID (Admin)
if [ ! -z "$USER_TOKEN" ]; then
    USER_ID=$(curl -s -X GET "${GATEWAY_URL}/api/users/profile" -H "Authorization: Bearer ${USER_TOKEN}" | grep -o '"id":"[^"]*' | cut -d'"' -f4)
    if [ ! -z "$USER_ID" ]; then
        test_api "GET" "/api/payments/admin/user/${USER_ID}" "" "4.2 Get payments by user ID (admin)" "$ADMIN_TOKEN"
    fi
fi

# 9. Get Payments by Status (Admin)
test_api "GET" "/api/payments/admin/status/COMPLETED" "" "4.3 Get completed payments (admin)" "$ADMIN_TOKEN"

echo ""
echo "========================================="
echo "PHASE 5: Payment Failure & Cache Management"
echo "========================================="

# 10. Mark Payment as Failed (create new payment first for failure test)
if [ ! -z "$BOOKING_ID" ]; then
    # Create another payment for failure test
    FAIL_PAYMENT_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/payments" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${USER_TOKEN}" \
        -d "{\"bookingId\":\"${BOOKING_ID}\",\"amount\":30.00}")
    FAIL_PAYMENT_ID=$(echo "$FAIL_PAYMENT_RESPONSE" | grep -o '"id":"[^"]*' | cut -d'"' -f4)
    
    if [ ! -z "$FAIL_PAYMENT_ID" ]; then
        test_api "POST" "/api/payments/${FAIL_PAYMENT_ID}/fail?reason=Insufficient+funds" "" "5.1 Mark payment as failed" "$USER_TOKEN"
    fi
fi

# 11. Clear Payment Cache (Admin)
test_api "POST" "/api/payments/admin/cache/clear" "" "5.2 Clear payment cache (admin)" "$ADMIN_TOKEN"

# Verify cache cleared
echo -e "${COLOR_BLUE}[REDIS] Verifying cache cleared...${COLOR_NC}"
redis-cli KEYS "*payment*" 2>/dev/null | head -5 || echo "  Cache cleared successfully"

echo ""
echo "========================================="
echo "PHASE 6: Internal Service APIs"
echo "========================================="

# 12. Get Pending Payments Older Than (Internal Admin API)
test_api "GET" "/api/payments/internal/pending?olderThanHours=1" "" "6.1 Get pending payments older than 1 hour (internal)" "$ADMIN_TOKEN"

echo ""
echo "========================================="
echo "MONITORING SUMMARY"
echo "========================================="

echo -e "${COLOR_BLUE}[RABBITMQ] All payment-related queues:${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "import sys, json; data=json.load(sys.stdin); payment_queues = [q for q in data if 'payment' in q['name'].lower()]; [print(f\"  - {q['name']}: {q.get('messages', 0)} messages, {q.get('consumers', 0)} consumers\") for q in payment_queues] if payment_queues else print('  No payment queues found')" 2>/dev/null

echo ""
echo -e "${COLOR_BLUE}[REDIS] Payment cache keys summary:${COLOR_NC}"
redis-cli KEYS "*payment*" 2>/dev/null | head -10 || echo "  No payment cache keys"
redis-cli KEYS "*dateRange*" 2>/dev/null | head -5 || echo "  No date range cache keys"
redis-cli KEYS "*status*" 2>/dev/null | head -5 || echo "  No status cache keys"

echo ""
echo "========================================="
echo "PAYMENT SERVICE TESTING COMPLETE"
echo "========================================="

