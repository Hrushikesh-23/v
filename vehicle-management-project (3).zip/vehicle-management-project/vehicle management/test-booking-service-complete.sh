#!/bin/bash

# Complete Booking Service API Testing with RabbitMQ and Redis Monitoring

BASE_URL="http://localhost:8083"
GATEWAY_URL="http://localhost:8080"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

USER_TOKEN=""
BOOKING_ID=""
WAITLIST_ID=""
LOT_ID=""
SPOT_ID=""

echo "========================================="
echo "COMPREHENSIVE BOOKING SERVICE API TESTING"
echo "========================================="
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local token=$5
    local expected_code=${6:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ -z "$token" ]; then
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -d "${data}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
        fi
    else
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "PUT" ]; then
            response=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "DELETE" ]; then
            response=$(curl -s -w "\n%{http_code}" -X DELETE "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        fi
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "$body" | python3 -m json.tool 2>/dev/null | head -20 || echo "$body" | head -10
        echo "$body" > /tmp/last_response.json
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "$body"
        return 1
    fi
    echo ""
}

# Setup: Get admin token to create lots/spots first, then get user token
echo "Setting up test data..."
ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ -z "$ADMIN_TOKEN" ]; then
    echo "Creating admin user..."
    curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
        -H "Content-Type: application/json" \
        -d '{"fullName":"Test Admin","email":"admintest@example.com","password":"admin123","role":"ADMIN"}' > /dev/null
    sleep 1
    ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
        -H "Content-Type: application/json" \
        -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)
fi

# Get or create a lot and spot for booking
echo "Getting available lot and spot..."
LOTS_RESPONSE=$(curl -s -X GET "${GATEWAY_URL}/api/lots" -H "Authorization: Bearer ${ADMIN_TOKEN}")
LOT_ID=$(echo "$LOTS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0]['id'] if data else '')" 2>/dev/null)

if [ -z "$LOT_ID" ]; then
    echo "Creating test lot..."
    LOT_RESPONSE=$(curl -s -X POST "${GATEWAY_URL}/api/lots" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${ADMIN_TOKEN}" \
        -d '{"name":"Booking Test Lot","address":"Test Address"}')
    LOT_ID=$(echo "$LOT_RESPONSE" | grep -o '"id":[0-9]*' | cut -d':' -f2)
fi

# Get available spot
SPOTS_RESPONSE=$(curl -s -X GET "${GATEWAY_URL}/api/lots/${LOT_ID}/spots/available" -H "Authorization: Bearer ${ADMIN_TOKEN}")
SPOT_ID=$(echo "$SPOTS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0]['id'] if data else '')" 2>/dev/null)

if [ -z "$SPOT_ID" ]; then
    echo "Creating test spot..."
    SPOT_RESPONSE=$(curl -s -X POST "${GATEWAY_URL}/api/lots/${LOT_ID}/spots" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${ADMIN_TOKEN}" \
        -d '{"code":"BOOKING-TEST-01","available":true}')
    SPOT_ID=$(echo "$SPOT_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data.get('id', ''))" 2>/dev/null || echo "3")
fi

echo "Using Lot ID: $LOT_ID, Spot ID: $SPOT_ID"
echo ""

# Register and login user
USER_EMAIL="bookinguser_$(date +%s)@example.com"
echo "Registering test user..."
curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"fullName\":\"Booking Test User\",\"email\":\"${USER_EMAIL}\",\"password\":\"password123\",\"role\":\"USER\"}" > /dev/null
sleep 1

LOGIN_RESPONSE=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"${USER_EMAIL}\",\"password\":\"password123\"}")
USER_TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
echo "✅ User token obtained"
echo ""

echo "========================================="
echo "PHASE 1: Booking Management APIs"
echo "========================================="

# Calculate dates
START_TIME=$(date -u -v+1H +"%Y-%m-%dT%H:00:00" 2>/dev/null || date -u -d "+1 hour" +"%Y-%m-%dT%H:00:00" 2>/dev/null || echo "2024-12-01T10:00:00")
END_TIME=$(date -u -v+9H +"%Y-%m-%dT%H:00:00" 2>/dev/null || date -u -d "+9 hours" +"%Y-%m-%dT%H:00:00" 2>/dev/null || echo "2024-12-01T18:00:00")

# 1. Create Booking
BOOKING_DATA="{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START_TIME}\",\"endTime\":\"${END_TIME}\"}"
test_api "POST" "/api/bookings" "$BOOKING_DATA" "1.1 Create booking" "$USER_TOKEN"
BOOKING_ID=$(cat /tmp/last_response.json | grep -o '"id":"[^"]*' | cut -d'"' -f4)
echo "Created Booking ID: $BOOKING_ID"

# Check RabbitMQ for booking created event
sleep 2
echo -e "${COLOR_BLUE}[RABBITMQ] Checking booking.created queue...${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "import sys, json; data=json.load(sys.stdin); queues = [q for q in data if 'booking' in q['name'].lower() and 'created' in q['name'].lower()]; [print(f\"  Queue: {q['name']}, Messages: {q.get('messages', 0)}\") for q in queues] if queues else print('  Queue info not available')" 2>/dev/null

# Check Redis cache
echo -e "${COLOR_BLUE}[REDIS] Checking booking cache...${COLOR_NC}"
redis-cli KEYS "*booking*" 2>/dev/null | head -5 || echo "  No booking cache keys yet"

# 2. Get My Bookings
test_api "GET" "/api/bookings" "" "1.2 Get user bookings" "$USER_TOKEN"

# 3. Get Specific Booking
if [ ! -z "$BOOKING_ID" ]; then
    test_api "GET" "/api/bookings/${BOOKING_ID}" "" "1.3 Get specific booking" "$USER_TOKEN"
fi

# 4. Get Future Bookings
test_api "GET" "/api/bookings/future" "" "1.4 Get future bookings" "$USER_TOKEN"

# 5. Get Past Bookings
test_api "GET" "/api/bookings/past" "" "1.5 Get past bookings" "$USER_TOKEN"

# 6. Update Booking
if [ ! -z "$BOOKING_ID" ]; then
    NEW_START=$(date -u -v+2H +"%Y-%m-%dT%H:00:00" 2>/dev/null || date -u -d "+2 hours" +"%Y-%m-%dT%H:00:00" 2>/dev/null || echo "2024-12-01T11:00:00")
    NEW_END=$(date -u -v+10H +"%Y-%m-%dT%H:00:00" 2>/dev/null || date -u -d "+10 hours" +"%Y-%m-%dT%H:00:00" 2>/dev/null || echo "2024-12-01T19:00:00")
    UPDATE_DATA="{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${NEW_START}\",\"endTime\":\"${NEW_END}\"}"
    test_api "PUT" "/api/bookings/${BOOKING_ID}" "$UPDATE_DATA" "1.6 Update booking" "$USER_TOKEN"
fi

echo ""
echo "========================================="
echo "PHASE 2: Waitlist Management APIs"
echo "========================================="

# 7. Get My Waitlist Entries
test_api "GET" "/api/bookings/waitlist" "" "2.1 Get user waitlist entries" "$USER_TOKEN"

# 8. Add to Waitlist (try booking already taken spot)
if [ ! -z "$LOT_ID" ] && [ ! -z "$SPOT_ID" ]; then
    WAITLIST_DATA="{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START_TIME}\",\"endTime\":\"${END_TIME}\"}"
    test_api "POST" "/api/bookings/waitlist" "$WAITLIST_DATA" "2.2 Add booking to waitlist" "$USER_TOKEN"
    WAITLIST_ID=$(cat /tmp/last_response.json | grep -o '"id":"[^"]*' | cut -d'"' -f4)
    echo "Created Waitlist ID: $WAITLIST_ID"
fi

# 9. Cancel Waitlist Entry
if [ ! -z "$WAITLIST_ID" ]; then
    test_api "DELETE" "/api/bookings/waitlist/${WAITLIST_ID}" "" "2.3 Cancel waitlist entry" "$USER_TOKEN"
fi

echo ""
echo "========================================="
echo "PHASE 3: Booking Cancellation"
echo "========================================="

# 10. Cancel Booking
if [ ! -z "$BOOKING_ID" ]; then
    test_api "DELETE" "/api/bookings/${BOOKING_ID}" "" "3.1 Cancel booking" "$USER_TOKEN"
    
    # Check RabbitMQ for booking cancelled event
    sleep 2
    echo -e "${COLOR_BLUE}[RABBITMQ] Checking booking.cancelled queue...${COLOR_NC}"
    curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "import sys, json; data=json.load(sys.stdin); queues = [q for q in data if 'booking' in q['name'].lower() and ('cancelled' in q['name'].lower() or 'cancel' in q['name'].lower())]; [print(f\"  Queue: {q['name']}, Messages: {q.get('messages', 0)}\") for q in queues] if queues else print('  Queue info not available')" 2>/dev/null
fi

echo ""
echo "========================================="
echo "PHASE 4: Internal Admin APIs"
echo "========================================="

# 11. Get Upcoming Bookings (Internal Admin API)
ADMIN_TOKEN_FOR_BOOKING=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)

test_api "GET" "/api/bookings/internal/upcoming?hours=24" "" "4.1 Get upcoming bookings (admin)" "$ADMIN_TOKEN_FOR_BOOKING"

echo ""
echo "========================================="
echo "MONITORING SUMMARY"
echo "========================================="

echo -e "${COLOR_BLUE}[RABBITMQ] All booking-related queues:${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "import sys, json; data=json.load(sys.stdin); booking_queues = [q for q in data if 'booking' in q['name'].lower()]; [print(f\"  - {q['name']}: {q.get('messages', 0)} messages, {q.get('consumers', 0)} consumers\") for q in booking_queues] if booking_queues else print('  No booking queues found')" 2>/dev/null

echo ""
echo -e "${COLOR_BLUE}[REDIS] Booking and availability cache keys:${COLOR_NC}"
redis-cli KEYS "*booking*" 2>/dev/null | head -10 || echo "  No booking cache keys"
redis-cli KEYS "*spot*" 2>/dev/null | head -5 || echo "  No spot cache keys"
redis-cli KEYS "*available*" 2>/dev/null | head -5 || echo "  No availability cache keys"

echo ""
echo "========================================="
echo "BOOKING SERVICE TESTING COMPLETE"
echo "========================================="

