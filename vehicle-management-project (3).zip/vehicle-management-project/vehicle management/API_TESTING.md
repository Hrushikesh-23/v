# Vehicle Parking Management System - API Testing Guide

## 🔑 Prerequisites

1. All services are running (see STARTUP_GUIDE.md)
2. Use API Gateway URL: `http://localhost:8080` (recommended)
3. Or direct service URLs: `http://localhost:8081-8085`
4. Use **Postman** or **curl** for testing

## 📝 Testing Workflow

### Step 1: User Registration & Authentication

#### 1.1 Register a New User
```bash
POST http://localhost:8080/api/auth/register
Content-Type: application/json

{
  "fullName": "John Doe",
  "email": "john.doe@example.com",
  "password": "password123",
  "role": "USER"
}
```

**Expected Response (200 OK):**
```json
{
  "id": "uuid-here",
  "email": "john.doe@example.com",
  "fullName": "John Doe",
  "role": "USER",
  "message": "User registered successfully"
}
```

#### 1.2 Register an Admin User
```bash
POST http://localhost:8080/api/auth/register
Content-Type: application/json

{
  "fullName": "Admin User",
  "email": "admin@example.com",
  "password": "admin123",
  "role": "ADMIN"
}
```

#### 1.3 Login User
```bash
POST http://localhost:8080/api/auth/login
Content-Type: application/json

{
  "email": "john.doe@example.com",
  "password": "password123"
}
```

**Expected Response (200 OK):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**⚠️ IMPORTANT**: Save this token for subsequent requests!

#### 1.4 Get User Profile
```bash
GET http://localhost:8080/api/users/profile
Authorization: Bearer {YOUR_TOKEN_HERE}
```

**Expected Response (200 OK):**
```json
{
  "id": "uuid-here",
  "email": "john.doe@example.com",
  "fullName": "John Doe",
  "role": "USER"
}
```

---

### Step 2: Admin Setup (Parking Lots & Spots)

#### 2.1 Login as Admin
```bash
POST http://localhost:8080/api/auth/login
Content-Type: application/json

{
  "email": "admin@example.com",
  "password": "admin123"
}
```
**Save the admin token!**

#### 2.2 Create Parking Lot
```bash
POST http://localhost:8080/api/lots
Authorization: Bearer {ADMIN_TOKEN}
Content-Type: application/json

{
  "name": "Downtown Parking",
  "address": "123 Main Street, City"
}
```

**Expected Response (200 OK):**
```json
{
  "id": 1,
  "name": "Downtown Parking",
  "address": "123 Main Street, City",
  "createdAt": "2024-01-15T10:00:00",
  "updatedAt": "2024-01-15T10:00:00"
}
```

#### 2.3 Add Parking Spot
```bash
POST http://localhost:8080/api/lots/1/spots
Authorization: Bearer {ADMIN_TOKEN}
Content-Type: application/json

{
  "code": "A-01",
  "available": true
}
```

**Expected Response (200 OK):**
```json
{
  "id": 1,
  "lotId": 1,
  "code": "A-01",
  "available": true,
  "createdAt": "2024-01-15T10:05:00",
  "updatedAt": "2024-01-15T10:05:00"
}
```

#### 2.4 Get All Parking Lots
```bash
GET http://localhost:8080/api/lots
Authorization: Bearer {ADMIN_TOKEN}
```

#### 2.5 Get Available Spots
```bash
GET http://localhost:8080/api/lots/1/spots/available
Authorization: Bearer {ADMIN_TOKEN}
```

---

### Step 3: User Booking Flow

#### 3.1 Create Booking
```bash
POST http://localhost:8080/api/bookings
Authorization: Bearer {USER_TOKEN}
Content-Type: application/json

{
  "lotId": 1,
  "spotId": 1,
  "startTime": "2024-01-16T09:00:00",
  "endTime": "2024-01-16T17:00:00"
}
```

**Expected Response (200 OK):**
```json
{
  "id": "booking-uuid",
  "userId": "user-uuid",
  "lotId": 1,
  "spotId": 1,
  "startTime": "2024-01-16T09:00:00",
  "endTime": "2024-01-16T17:00:00",
  "status": "CREATED",
  "createdAt": "2024-01-15T10:10:00"
}
```

#### 3.2 Get My Bookings
```bash
GET http://localhost:8080/api/bookings
Authorization: Bearer {USER_TOKEN}
```

**Expected Response (200 OK):**
```json
[
  {
    "id": "booking-uuid",
    "userId": "user-uuid",
    "lotId": 1,
    "spotId": 1,
    "startTime": "2024-01-16T09:00:00",
    "endTime": "2024-01-16T17:00:00",
    "status": "CREATED"
  }
]
```

#### 3.3 Get Specific Booking
```bash
GET http://localhost:8080/api/bookings/{bookingId}
Authorization: Bearer {USER_TOKEN}
```

#### 3.4 Get Future Bookings
```bash
GET http://localhost:8080/api/bookings/future
Authorization: Bearer {USER_TOKEN}
```

#### 3.5 Get Past Bookings
```bash
GET http://localhost:8080/api/bookings/past
Authorization: Bearer {USER_TOKEN}
```

---

### Step 4: Payment Flow

#### 4.1 Initiate Payment
```bash
POST http://localhost:8080/api/payments
Authorization: Bearer {USER_TOKEN}
Content-Type: application/json

{
  "bookingId": "booking-uuid-from-step-3",
  "amount": 25.50
}
```

**Expected Response (200 OK):**
```json
{
  "id": "payment-uuid",
  "userId": "user-uuid",
  "bookingId": "booking-uuid",
  "amount": 25.50,
  "status": "PENDING",
  "createdAt": "2024-01-15T10:15:00"
}
```

#### 4.2 Confirm Payment
```bash
POST http://localhost:8080/api/payments/{paymentId}/confirm
Authorization: Bearer {USER_TOKEN}
```

**Expected Response (200 OK):**
```json
{
  "message": "Payment confirmed successfully",
  "paymentId": "payment-uuid"
}
```

**Note**: Payment processing happens asynchronously (3 second delay configured)

#### 4.3 Get My Payments
```bash
GET http://localhost:8080/api/payments
Authorization: Bearer {USER_TOKEN}
```

#### 4.4 Get Payments by Booking
```bash
GET http://localhost:8080/api/payments/booking/{bookingId}
Authorization: Bearer {USER_TOKEN}
```

#### 4.5 Get Payments by Date Range
```bash
GET http://localhost:8080/api/payments/date-range?from=2024-01-01T00:00:00&to=2024-01-31T23:59:59
Authorization: Bearer {USER_TOKEN}
```

---

### Step 5: Profile Management

#### 5.1 Update Profile
```bash
PUT http://localhost:8080/api/users/profile
Authorization: Bearer {USER_TOKEN}
Content-Type: application/json

{
  "fullName": "John Updated Doe",
  "email": "john.updated@example.com"
}
```

**Expected Response (200 OK):**
```json
{
  "message": "Profile updated successfully",
  "profile": {
    "id": "user-uuid",
    "email": "john.updated@example.com",
    "fullName": "John Updated Doe",
    "role": "USER"
  }
}
```

#### 5.2 Change Password
```bash
POST http://localhost:8080/api/auth/change-password
Authorization: Bearer {USER_TOKEN}
Content-Type: application/json

{
  "oldPassword": "password123",
  "newPassword": "newpassword123"
}
```

---

### Step 6: Admin Operations

#### 6.1 Get All Payments (Admin)
```bash
GET http://localhost:8080/api/payments/admin/all
Authorization: Bearer {ADMIN_TOKEN}
```

#### 6.2 Get Dashboard Stats
```bash
GET http://localhost:8080/api/admin/dashboard/stats
Authorization: Bearer {ADMIN_TOKEN}
```

#### 6.3 Get Booking History
```bash
GET http://localhost:8080/api/admin/bookings/history?lotId=1&status=CREATED
Authorization: Bearer {ADMIN_TOKEN}
```

#### 6.4 Get Transaction Logs
```bash
GET http://localhost:8080/api/admin/transactions/logs?status=COMPLETED
Authorization: Bearer {ADMIN_TOKEN}
```

---

### Step 7: Waitlist Management

#### 7.1 Add to Waitlist (when spot unavailable)
```bash
POST http://localhost:8080/api/bookings/waitlist
Authorization: Bearer {USER_TOKEN}
Content-Type: application/json

{
  "lotId": 1,
  "spotId": 1,
  "startTime": "2024-01-16T09:00:00",
  "endTime": "2024-01-16T17:00:00"
}
```

#### 7.2 Get My Waitlist Entries
```bash
GET http://localhost:8080/api/bookings/waitlist
Authorization: Bearer {USER_TOKEN}
```

#### 7.3 Cancel Waitlist Entry
```bash
DELETE http://localhost:8080/api/bookings/waitlist/{waitlistId}
Authorization: Bearer {USER_TOKEN}
```

---

## 🧪 Complete Test Scenario

### End-to-End Booking and Payment Flow:

1. ✅ Register user → Get token
2. ✅ Admin: Create parking lot → Add spots
3. ✅ User: Create booking → Get booking ID
4. ✅ User: Initiate payment → Get payment ID
5. ✅ User: Confirm payment → Wait 3 seconds
6. ✅ User: Check payment status
7. ✅ User: Get booking details
8. ✅ Admin: View all bookings and payments

---

## 📋 Postman Collection

Use the provided Postman collection:
- **File**: `Vehicle_Parking_Management_APIs.postman_collection.json`
- Import into Postman
- Update environment variables:
  - `base_url`: `http://localhost:8080`
  - `user_token`: (from login)
  - `admin_token`: (from admin login)

---

## ✅ Expected Test Results

### Successful Responses:
- **200 OK**: Request successful
- **201 Created**: Resource created
- **202 Accepted**: Request accepted (waitlist)

### Error Responses:
- **400 Bad Request**: Invalid input/validation error
- **401 Unauthorized**: Missing or invalid token
- **403 Forbidden**: Insufficient permissions
- **404 Not Found**: Resource not found
- **409 Conflict**: Resource conflict (e.g., spot already booked)

---

## 🔍 Testing Tips

1. **Use API Gateway**: Always use `http://localhost:8080` for routing
2. **Save Tokens**: Store JWT tokens after login
3. **Check Headers**: Ensure `Authorization: Bearer {token}` is set
4. **Date Format**: Use ISO 8601 format: `2024-01-16T09:00:00`
5. **UUID Format**: Booking IDs, Payment IDs are UUIDs
6. **Async Operations**: Wait for async payment processing (3 seconds)
7. **Eureka Dashboard**: Check service registration at http://localhost:8761

---

## 🐛 Common Testing Issues

### Issue: 401 Unauthorized
- Check token is included in Authorization header
- Verify token hasn't expired
- Ensure "Bearer " prefix is included

### Issue: 404 Not Found
- Check service is running
- Verify URL path is correct
- Check service is registered in Eureka

### Issue: 500 Internal Server Error
- Check service logs
- Verify database connection
- Check Redis/RabbitMQ connections

---

## 📊 API Endpoints Summary

| Service | Endpoints | Base URL |
|---------|-----------|----------|
| Auth | `/api/auth/*` | http://localhost:8080 |
| Users | `/api/users/*` | http://localhost:8080 |
| Admin | `/api/lots/*`, `/api/admin/*` | http://localhost:8080 |
| Bookings | `/api/bookings/*` | http://localhost:8080 |
| Payments | `/api/payments/*` | http://localhost:8080 |
| Notifications | `/api/notifications/*` | http://localhost:8080 |

---

## 🎯 Quick Test Checklist

- [ ] User registration works
- [ ] User login returns token
- [ ] Token authentication works
- [ ] Admin can create parking lots
- [ ] Admin can add parking spots
- [ ] User can create booking
- [ ] User can initiate payment
- [ ] User can confirm payment
- [ ] Payment processes asynchronously
- [ ] User can view bookings
- [ ] Admin can view all data
- [ ] Waitlist functionality works
- [ ] Profile update works
- [ ] All services registered in Eureka

