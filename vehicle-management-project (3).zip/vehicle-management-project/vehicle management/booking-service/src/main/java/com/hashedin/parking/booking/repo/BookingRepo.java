package com.hashedin.parking.booking.repo;

import com.hashedin.parking.booking.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;


public interface BookingRepo extends JpaRepository<Booking, UUID> {
    List<Booking> findByUserId(UUID userId);
    List<Booking> findByStartTimeAfterAndUserId(LocalDateTime start, UUID userId);
    List<Booking> findByEndTimeBeforeAndUserId(LocalDateTime end, UUID userId);
    boolean existsBySpotIdAndStatusInAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(Long spotId, List<String> statuses, LocalDateTime end, LocalDateTime start);
    List<Booking> findByStatusAndUpdatedAtAfter(String status, LocalDateTime updatedAt);
}
