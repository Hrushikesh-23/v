package com.hashedin.parking.booking.service;

import com.hashedin.parking.booking.model.Booking;
import com.hashedin.parking.booking.model.Waitlist;
import com.hashedin.parking.booking.repo.BookingRepo;
import com.hashedin.parking.booking.repo.WaitlistRepo;
import com.hashedin.parking.common.events.Events;
import com.hashedin.parking.common.model.BookingStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class WaitlistService {
    
    private static final Logger log = LoggerFactory.getLogger(WaitlistService.class);
    
    private final WaitlistRepo waitlistRepo;
    private final BookingRepo bookingRepo;
    private final AdminServiceClient adminServiceClient;
    private final RabbitTemplate rabbit;
    private final String exchange;
    private final String notifyEmailRouting;
    
    public WaitlistService(WaitlistRepo waitlistRepo,
                         BookingRepo bookingRepo,
                         AdminServiceClient adminServiceClient,
                         RabbitTemplate rabbit,
                         @Value("${app.rabbit.exchange}") String exchange,
                         @Value("${app.rabbit.routing.notifyEmail}") String notifyEmailRouting) {
        this.waitlistRepo = waitlistRepo;
        this.bookingRepo = bookingRepo;
        this.adminServiceClient = adminServiceClient;
        this.rabbit = rabbit;
        this.exchange = exchange;
        this.notifyEmailRouting = notifyEmailRouting;
    }
    
    public Waitlist addToWaitlist(UUID userId, Long lotId, Long spotId, 
                                 LocalDateTime startTime, LocalDateTime endTime) {
        // Validate that lot exists in admin service
        if (!adminServiceClient.validateLotExists(lotId)) {
            log.warn("Lot {} does not exist in admin service for waitlist", lotId);
            throw new IllegalArgumentException("Parking lot does not exist. Only lots created by admin can be booked.");
        }
        
        // Validate that spot exists and belongs to the lot in admin service
        if (!adminServiceClient.validateSpotExists(spotId, lotId)) {
            log.warn("Spot {} does not exist in admin service or does not belong to lot {} for waitlist", spotId, lotId);
            throw new IllegalArgumentException("Parking spot does not exist or does not belong to the specified lot. Only spots created by admin can be booked.");
        }
        
        // Check if user already has a pending waitlist entry for the same spot and time
        if (waitlistRepo.existsPendingByUserAndSpotAndTime(userId, spotId, startTime, endTime)) {
            throw new IllegalArgumentException("User already has a pending waitlist entry for this spot and time");
        }
        
        Waitlist waitlist = new Waitlist();
        waitlist.setUserId(userId);
        waitlist.setLotId(lotId);
        waitlist.setSpotId(spotId);
        waitlist.setStartTime(startTime);
        waitlist.setEndTime(endTime);
        
        // Calculate priority based on creation time (earlier = higher priority)
        waitlist.setPriority(0);
        
        return waitlistRepo.save(waitlist);
    }
    
    @Transactional
    public void processWaitlistForSpot(Long spotId, LocalDateTime startTime, LocalDateTime endTime) {
        List<Waitlist> pendingEntries = waitlistRepo.findPendingBySpotAndTimeWindow(spotId, startTime, endTime);
        
        for (Waitlist entry : pendingEntries) {
            try {
                // Check if spot is still available
                boolean isAvailable = !bookingRepo.existsBySpotIdAndStatusInAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
                    spotId, List.of("CREATED", "CONFIRMED"), endTime, startTime);
                
                if (isAvailable) {
                    // Validate lot and spot still exist in admin service before creating booking
                    if (!adminServiceClient.validateLotExists(entry.getLotId())) {
                        log.warn("Lot {} no longer exists in admin service, cancelling waitlist entry {}", 
                                entry.getLotId(), entry.getId());
                        entry.setStatus("CANCELLED");
                        waitlistRepo.save(entry);
                        continue;
                    }
                    
                    if (!adminServiceClient.validateSpotExists(entry.getSpotId(), entry.getLotId())) {
                        log.warn("Spot {} no longer exists in admin service or does not belong to lot {}, cancelling waitlist entry {}", 
                                entry.getSpotId(), entry.getLotId(), entry.getId());
                        entry.setStatus("CANCELLED");
                        waitlistRepo.save(entry);
                        continue;
                    }
                    
                    // Create booking for waitlist entry
                    Booking booking = new Booking();
                    booking.setUserId(entry.getUserId());
                    booking.setLotId(entry.getLotId());
                    booking.setSpotId(entry.getSpotId());
                    booking.setStartTime(entry.getStartTime());
                    booking.setEndTime(entry.getEndTime());
                   // booking.setStatus("CREATED");
                    booking.setStatus(BookingStatus.CREATED);
                    Booking savedBooking = bookingRepo.save(booking);
                    
                    // Update waitlist status
                    entry.setStatus("NOTIFIED");
                    waitlistRepo.save(entry);
                    
                    // Send notification email
                    rabbit.convertAndSend(
                        exchange,
                        notifyEmailRouting,
                        new Events.NotifyEmail(
                            entry.getUserId(),
                            "user@example.com", // In production, get from user service
                            "Spot Available - Booking Confirmed",
                            "Great news! A spot has become available and your booking has been confirmed. " +
                            "Booking ID: " + savedBooking.getId() +
                            "\nSpot: " + entry.getSpotId() +
                            "\nTime: " + entry.getStartTime() + " to " + entry.getEndTime()
                        )
                    );
                    
                    // Publish booking created event
                    rabbit.convertAndSend(
                        exchange,
                        "booking.created",
                        new Events.BookingCreated(
                            savedBooking.getId(),
                            savedBooking.getUserId(),
                            savedBooking.getLotId(),
                            savedBooking.getSpotId(),
                            savedBooking.getStartTime(),
                            savedBooking.getEndTime()
                        )
                    );
                    
                    log.info("Created booking from waitlist entry {} for user {}", entry.getId(), entry.getUserId());
                    break; // Only process one entry at a time
                }
            } catch (Exception e) {
                log.error("Failed to process waitlist entry {}: {}", entry.getId(), e.getMessage());
            }
        }
    }
    
    public void cancelWaitlistEntry(UUID userId, UUID waitlistId) {
        waitlistRepo.findById(waitlistId).ifPresent(entry -> {
            if (entry.getUserId().equals(userId) && "PENDING".equals(entry.getStatus())) {
                entry.setStatus("CANCELLED");
                waitlistRepo.save(entry);
                log.info("Cancelled waitlist entry {} for user {}", waitlistId, userId);
            }
        });
    }
    
    public List<Waitlist> getUserWaitlist(UUID userId) {
        return waitlistRepo.findByUserIdAndStatus(userId, "PENDING");
    }
    
    public void expireWaitlistEntries() {
        List<Waitlist> expiredEntries = waitlistRepo.findExpiredPending(LocalDateTime.now());
        for (Waitlist entry : expiredEntries) {
            entry.setStatus("EXPIRED");
            waitlistRepo.save(entry);
        }
        if (!expiredEntries.isEmpty()) {
            log.info("Expired {} waitlist entries", expiredEntries.size());
        }
    }
}
