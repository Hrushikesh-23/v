package com.hashedin.parking.booking.web;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hashedin.parking.booking.model.Booking;
import com.hashedin.parking.booking.model.Waitlist;
import com.hashedin.parking.booking.service.BookingService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;

    public record CreateBookingRequest(@NotNull Long lotId,
                                       @NotNull Long spotId,
                                       @NotNull LocalDateTime startTime,
                                       @NotNull LocalDateTime endTime) {}
    
    public record UpdateBookingRequest(Long lotId,
                                      Long spotId,
                                      LocalDateTime startTime,
                                      LocalDateTime endTime) {}

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @GetMapping
    public List<Booking> getMyBookings(Authentication auth) {
        return bookingService.getUserBookings(UUID.fromString(auth.getName()));
    }

    @GetMapping("/{bookingId}")
    public ResponseEntity<?> getBookingById(Authentication auth, @PathVariable("bookingId") UUID bookingId) {
        return ResponseEntity.of(bookingService.getBookingById(bookingId, UUID.fromString(auth.getName())));
    }

    @PostMapping
    public ResponseEntity<?> createBooking(Authentication auth, @Valid @RequestBody CreateBookingRequest req) {
        Map<String, Object> result = bookingService.createBooking(
            UUID.fromString(auth.getName()),
            req.lotId(),
            req.spotId(),
            req.startTime(),
            req.endTime()
        );
        
        if (result.containsKey("waitlistId")) {
            return ResponseEntity.status(202).body(result);
        }
        
        return ResponseEntity.ok(result.get("booking"));
    }

    @PutMapping("/{bookingId}")
    public ResponseEntity<?> updateBooking(Authentication auth, 
                                         @PathVariable("bookingId") UUID bookingId, 
                                         @Valid @RequestBody UpdateBookingRequest req) {
        Map<String, Object> result = bookingService.updateBooking(
            bookingId,
            UUID.fromString(auth.getName()),
            req.lotId(),
            req.spotId(),
            req.startTime(),
            req.endTime()
        );
        return ResponseEntity.ok(result);
    }

    @DeleteMapping("/{bookingId}")
    public ResponseEntity<?> cancelBooking(Authentication auth, @PathVariable("bookingId") UUID bookingId) {
        Map<String, Object> result = bookingService.cancelBooking(bookingId, UUID.fromString(auth.getName()));
        return ResponseEntity.ok(result);
    }

    @GetMapping("/past")
    public List<Booking> getPastBookings(Authentication auth) {
        return bookingService.getPastBookings(UUID.fromString(auth.getName()));
    }

    @GetMapping("/future")
    public List<Booking> getFutureBookings(Authentication auth) {
        return bookingService.getFutureBookings(UUID.fromString(auth.getName()));
    }
    
    // ==== Waitlist Management Endpoints ====
    
    @GetMapping("/waitlist")
    public List<Waitlist> getMyWaitlistEntries(Authentication auth) {
        return bookingService.getUserWaitlist(UUID.fromString(auth.getName()));
    }
    
    @PostMapping("/waitlist")
    public ResponseEntity<?> addBookingToWaitlist(Authentication auth, @Valid @RequestBody CreateBookingRequest req) {
        Map<String, Object> result = bookingService.addToWaitlist(
            UUID.fromString(auth.getName()),
            req.lotId(),
            req.spotId(),
            req.startTime(),
            req.endTime()
        );
        return ResponseEntity.ok(result);
    }
    
    @DeleteMapping("/waitlist/{waitlistId}")
    public ResponseEntity<?> cancelWaitlistEntry(Authentication auth, @PathVariable("waitlistId") UUID waitlistId) {
        Map<String, Object> result = bookingService.cancelWaitlistEntry(UUID.fromString(auth.getName()), waitlistId);
        return ResponseEntity.ok(result);
    }

    // ==== Internal/Admin Endpoints for Service-to-Service Communication ====
    
    @GetMapping("/internal/upcoming")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LOT_MANAGER')")
    public List<Booking> getUpcomingBookings(@RequestParam(defaultValue = "24") int hours) {
        return bookingService.getUpcomingBookings(hours);
    }
}
