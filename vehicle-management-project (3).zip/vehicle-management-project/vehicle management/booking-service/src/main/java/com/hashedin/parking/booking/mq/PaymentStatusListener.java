package com.hashedin.parking.booking.mq;

import com.hashedin.parking.common.model.BookingStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hashedin.parking.booking.model.Booking;
import com.hashedin.parking.booking.repo.BookingRepo;
import com.hashedin.parking.booking.service.BookingService;
import com.hashedin.parking.common.events.Events;


@Component
public class PaymentStatusListener {
    private static final Logger log = LoggerFactory.getLogger(PaymentStatusListener.class);
    
    private final BookingRepo bookingRepo;
    private final BookingService bookingService;
    public PaymentStatusListener(BookingRepo bookingRepo, BookingService bookingService) {
        this.bookingRepo = bookingRepo;
        this.bookingService = bookingService;
    }

    @RabbitListener(queues = "${app.rabbit.queues.bookingService.paymentStatus}")
    @Transactional
    public void onPaymentStatusChanged(Events.PaymentStatusChanged ev) {
        log.info("Received payment status changed event: paymentId={}, bookingId={}, status={}", 
            ev.paymentId(), ev.bookingId(), ev.status());
        
        Booking booking = bookingRepo.findById(ev.bookingId()).orElse(null);
        if (booking == null) {
            log.warn("Booking {} not found for payment status change {}", ev.bookingId(), ev.paymentId());
            return;
        }
        
        // Handle payment completion - confirm booking
        if ("COMPLETED".equals(ev.status())) {
            try {
                // Only confirm booking if currently CREATED
                if (BookingStatus.CREATED.equals(booking.getStatus())) {
                    booking.setStatus(BookingStatus.CONFIRMED);
                    bookingRepo.save(booking);
                    log.info("Booking {} confirmed after payment completion {}", booking.getId(), ev.paymentId());
                } else {
                    log.info("PaymentCompleted received but booking {} status is {} — ignoring", booking.getId(), booking.getStatus());
                }
            } catch (Exception e) {
                log.error("Error confirming booking {} for completed payment {}: {}", 
                    ev.bookingId(), ev.paymentId(), e.getMessage(), e);
            }
        }
        // Handle payment failure - cancel the booking and make slot available
        else if ("FAILED".equals(ev.status())) {
            try {
                // Only cancel if booking is still active (CREATED or CONFIRMED)
                if (BookingStatus.CREATED.equals(booking.getStatus()) || BookingStatus.CONFIRMED.equals(booking.getStatus())) {
                    log.info("Cancelling booking {} due to failed payment {}", booking.getId(), ev.paymentId());
                    
                    booking.setStatus(BookingStatus.CANCELLED);
                    bookingRepo.save(booking);
                    
                    // Trigger async cancellation processing (cache cleanup, waitlist, events)
                    bookingService.cancelBookingAsync(booking);
                    
                    log.info("Booking {} cancelled successfully due to failed payment. Slot is now available.", booking.getId());
                } else {
                    log.info("Booking {} is already in status {}, not cancelling", booking.getId(), booking.getStatus());
                }
            } catch (Exception e) {
                log.error("Error cancelling booking {} for failed payment {}: {}", 
                    ev.bookingId(), ev.paymentId(), e.getMessage(), e);
            }
        }
    }


}

