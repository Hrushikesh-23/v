package com.hashedin.parking.booking.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;

@Service
public class AdminServiceClient {
    private static final Logger log = LoggerFactory.getLogger(AdminServiceClient.class);
    
    private final RestTemplate restTemplate;
    private final String adminServiceUrl;

    public AdminServiceClient(RestTemplate restTemplate,
                             @Value("${app.services.admin.url:http://admin-service}") String adminServiceUrl) {
        this.restTemplate = restTemplate;
        this.adminServiceUrl = adminServiceUrl;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ParkingLot(Long id, String name, String address) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ParkingSpot(Long id, String code, boolean available, Long lotId) {}

    /**
     * Validates that a parking lot exists in admin service
     * @param lotId The lot ID to validate
     * @return true if lot exists, false otherwise
     */
    public boolean validateLotExists(Long lotId) {
        if (lotId == null) {
            return false;
        }
        
        try {
            // Try to get the lot directly by ID
            String url = String.format("%s/api/lots/%d", adminServiceUrl, lotId);
            try {
                ParkingLot lot = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<ParkingLot>() {}
                ).getBody();
                
                boolean exists = lot != null && lot.id().equals(lotId);
                log.debug("Lot {} validation: {}", lotId, exists ? "exists" : "not found");
                return exists;
            } catch (RestClientException e) {
                // If direct endpoint fails (404 or auth issue), fall back to getting all lots
                log.debug("Direct lot lookup failed, falling back to list: {}", e.getMessage());
                url = String.format("%s/api/lots", adminServiceUrl);
                java.util.List<ParkingLot> lots = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<java.util.List<ParkingLot>>() {}
                ).getBody();
                
                if (lots == null || lots.isEmpty()) {
                    log.debug("No lots found in admin service");
                    return false;
                }
                
                boolean exists = lots.stream()
                    .anyMatch(lot -> lot.id().equals(lotId));
                
                log.debug("Lot {} validation: {}", lotId, exists ? "exists" : "not found");
                return exists;
            }
        } catch (RestClientException e) {
            log.warn("Error validating lot {}: {}", lotId, e.getMessage());
            return false;
        } catch (Exception e) {
            log.error("Unexpected error validating lot {}: {}", lotId, e.getMessage(), e);
            return false;
        }
    }

    /**
     * Validates that a parking spot exists in admin service and belongs to the specified lot
     * @param spotId The spot ID to validate
     * @param lotId The lot ID to verify the spot belongs to
     * @return true if spot exists and belongs to the lot, false otherwise
     */
    public boolean validateSpotExists(Long spotId, Long lotId) {
        if (spotId == null || lotId == null) {
            return false;
        }
        
        try {
            // Get all spots for the lot
            String url = String.format("%s/api/lots/%d/spots", adminServiceUrl, lotId);
            java.util.List<ParkingSpot> spots = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<java.util.List<ParkingSpot>>() {}
            ).getBody();
            
            if (spots == null || spots.isEmpty()) {
                log.debug("No spots found for lot {}", lotId);
                return false;
            }
            
            boolean exists = spots.stream()
                .anyMatch(spot -> spot.id().equals(spotId));
            
            log.debug("Spot {} validation in lot {}: {}", spotId, lotId, exists ? "exists" : "not found");
            return exists;
        } catch (RestClientException e) {
            log.warn("Error validating spot {} for lot {}: {}", spotId, lotId, e.getMessage());
            return false;
        } catch (Exception e) {
            log.error("Unexpected error validating spot {} for lot {}: {}", spotId, lotId, e.getMessage(), e);
            return false;
        }
    }

    /**
     * Gets parking lot details
     * @param lotId The lot ID
     * @return Optional containing lot if exists
     */
    public Optional<ParkingLot> getLot(Long lotId) {
        if (lotId == null) {
            return Optional.empty();
        }
        
        try {
            // Try to get the lot directly by ID
            String url = String.format("%s/api/lots/%d", adminServiceUrl, lotId);
            try {
                ParkingLot lot = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<ParkingLot>() {}
                ).getBody();
                
                return Optional.ofNullable(lot);
            } catch (RestClientException e) {
                // If direct endpoint fails, fall back to getting all lots
                log.debug("Direct lot lookup failed, falling back to list: {}", e.getMessage());
                url = String.format("%s/api/lots", adminServiceUrl);
                java.util.List<ParkingLot> lots = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<java.util.List<ParkingLot>>() {}
                ).getBody();
                
                if (lots == null || lots.isEmpty()) {
                    return Optional.empty();
                }
                
                return lots.stream()
                    .filter(lot -> lot.id().equals(lotId))
                    .findFirst();
            }
        } catch (Exception e) {
            log.warn("Error fetching lot {}: {}", lotId, e.getMessage());
            return Optional.empty();
        }
    }

    /**
     * Gets parking spot details
     * @param lotId The lot ID
     * @param spotId The spot ID
     * @return Optional containing spot if exists
     */
    public Optional<ParkingSpot> getSpot(Long lotId, Long spotId) {
        if (spotId == null || lotId == null) {
            return Optional.empty();
        }
        
        try {
            String url = String.format("%s/api/lots/%d/spots", adminServiceUrl, lotId);
            java.util.List<ParkingSpot> spots = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<java.util.List<ParkingSpot>>() {}
            ).getBody();
            
            if (spots == null || spots.isEmpty()) {
                return Optional.empty();
            }
            
            return spots.stream()
                .filter(spot -> spot.id().equals(spotId))
                .findFirst();
        } catch (Exception e) {
            log.warn("Error fetching spot {} for lot {}: {}", spotId, lotId, e.getMessage());
            return Optional.empty();
        }
    }
}

