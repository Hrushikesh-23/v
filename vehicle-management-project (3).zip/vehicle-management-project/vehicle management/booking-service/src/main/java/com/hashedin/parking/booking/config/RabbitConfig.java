package com.hashedin.parking.booking.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableRabbit
public class RabbitConfig {

    @Bean
    public TopicExchange bookingExchange(@Value("${app.rabbit.exchange}") String exchange) {
        return new TopicExchange(exchange, true, false);
    }

    @Bean
    public Jackson2JsonMessageConverter jacksonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory cf, Jackson2JsonMessageConverter converter) {
        RabbitTemplate rt = new RabbitTemplate(cf);
        rt.setMessageConverter(converter);
        return rt;
    }

    @Bean
    public Queue bookingUserProfileUpdatedQueue(
            @Value("${app.rabbit.queues.bookingService.userProfileUpdated}") String qName) {
        return QueueBuilder.durable(qName).build();
    }

    @Bean
    public Binding bindBookingUserProfileUpdated(Queue bookingUserProfileUpdatedQueue,
                                                 TopicExchange bookingExchange,
                                                 @Value("${app.rabbit.routing.userProfileUpdated}") String rk) {
        return BindingBuilder.bind(bookingUserProfileUpdatedQueue).to(bookingExchange).with(rk);
    }

    @Bean
    public Queue bookingPaymentStatusQueue(
            @Value("${app.rabbit.queues.bookingService.paymentStatus}") String qName) {
        return QueueBuilder.durable(qName).build();
    }

    @Bean
    public Binding bindBookingPaymentStatus(Queue bookingPaymentStatusQueue,
                                           TopicExchange bookingExchange,
                                           @Value("${app.rabbit.routing.paymentStatus}") String rk) {
        return BindingBuilder.bind(bookingPaymentStatusQueue).to(bookingExchange).with(rk);
    }
}
