package com.hashedin.parking.booking.repo;

import com.hashedin.parking.booking.model.Waitlist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

public interface WaitlistRepo extends JpaRepository<Waitlist, UUID> {
    
    // Find waitlist entries for a specific spot and time window
    @Query("SELECT w FROM Waitlist w WHERE w.spotId = :spotId AND w.status = 'PENDING' " +
           "AND w.startTime <= :endTime AND w.endTime >= :startTime " +
           "ORDER BY w.priority ASC, w.createdAt ASC")
    List<Waitlist> findPendingBySpotAndTimeWindow(@Param("spotId") Long spotId,
                                                @Param("startTime") LocalDateTime startTime,
                                                @Param("endTime") LocalDateTime endTime);
    
    // Find waitlist entries for a user
    List<Waitlist> findByUserIdAndStatus(UUID userId, String status);
    
    // Find all pending waitlist entries ordered by priority and creation time
    @Query("SELECT w FROM Waitlist w WHERE w.status = 'PENDING' " +
           "ORDER BY w.priority ASC, w.createdAt ASC")
    List<Waitlist> findAllPendingOrderedByPriority();
    
    // Find expired waitlist entries
    @Query("SELECT w FROM Waitlist w WHERE w.status = 'PENDING' AND w.endTime < :now")
    List<Waitlist> findExpiredPending(@Param("now") LocalDateTime now);
    
    // Check if user already has a pending waitlist entry for the same spot and time
    @Query("SELECT COUNT(w) > 0 FROM Waitlist w WHERE w.userId = :userId AND w.spotId = :spotId " +
           "AND w.status = 'PENDING' AND w.startTime <= :endTime AND w.endTime >= :startTime")
    boolean existsPendingByUserAndSpotAndTime(@Param("userId") UUID userId,
                                            @Param("spotId") Long spotId,
                                            @Param("startTime") LocalDateTime startTime,
                                            @Param("endTime") LocalDateTime endTime);
}
