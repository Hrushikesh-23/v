//package com.hashedin.parking.user.cache;
//
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.stereotype.Component;
//
//import java.time.Duration;
//import java.util.Map;
//import java.util.concurrent.TimeUnit;
//
//@Component
//public class ProfileCache {
//
//    private final RedisTemplate<String, Object> redis;
//
//    public ProfileCache(RedisTemplate<String, Object> redis) {
//        this.redis = redis;
//    }
//
//    private String key(String userId) {
//        return "user:profile:" + userId;
//    }
//
//    public Map<String, Object> get(String userId) {
//        Object v = redis.opsForValue().get(key(userId));
//        if (v instanceof Map<?, ?> map) {
//            @SuppressWarnings("unchecked")
//            Map<String, Object> cast = (Map<String, Object>) map;
//            return cast;
//        }
//        return null;
//    }
//
//    public void put(String userId, Map<String, Object> profile, Duration ttl) {
//        redis.opsForValue().set(key(userId), profile, ttl.toSeconds(), TimeUnit.SECONDS);
//    }
//
//    public void evict(String userId) {
//        redis.delete(key(userId));
//    }
//}


package com.hashedin.parking.user.cache;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

@Component
public class ProfileCache {

    private static final Logger log = LoggerFactory.getLogger(ProfileCache.class);
    private final RedisTemplate<String, Object> redis;

    public ProfileCache(RedisTemplate<String, Object> redis) {
        this.redis = redis;
    }

    private String key(String userId) {
        return "user:profile:" + userId;
    }

    public Map<String, Object> get(String userId) {
        try {
            Object v = redis.opsForValue().get(key(userId));
            if (v instanceof Map<?, ?> map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> cast = (Map<String, Object>) map;
                return cast;
            }
        } catch (Exception e) {
            log.warn("Failed to get profile from cache for user {}: {}", userId, e.getMessage());
        }
        return null;
    }

    public void put(String userId, Map<String, Object> profile, Duration ttl) {
        try {
            redis.opsForValue().set(key(userId), profile, ttl.toSeconds(), TimeUnit.SECONDS);
        } catch (Exception e) {
            log.warn("Failed to put profile in cache for user {}: {}", userId, e.getMessage());
        }
    }

    public void evict(String userId) {
        try {
            redis.delete(key(userId));
        } catch (Exception e) {
            log.warn("Failed to evict profile from cache for user {}: {}", userId, e.getMessage());
        }
    }
}