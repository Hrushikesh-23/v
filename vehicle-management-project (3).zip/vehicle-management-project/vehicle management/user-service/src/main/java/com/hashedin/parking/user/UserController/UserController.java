package com.hashedin.parking.user.UserController;

import java.util.Map;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hashedin.parking.user.service.UserService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    public record UpdateProfile(String fullName, @Email String email) {}

    @GetMapping("/profile")
    public ResponseEntity<?> getMyProfile(Authentication auth) {
        Map<String, Object> profile = userService.getUserProfile(UUID.fromString(auth.getName()));
        return ResponseEntity.ok(profile);
    }

    @PutMapping("/profile")
    public ResponseEntity<?> updateMyProfile(Authentication auth, @Valid @RequestBody UpdateProfile req) {
        Map<String, Object> result = userService.updateProfile(
            UUID.fromString(auth.getName()),
            req.fullName(),
            req.email()
        );
        return ResponseEntity.ok(result);
    }

    @GetMapping("/test-role")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> testUserAccess(Authentication auth) {
        return ResponseEntity.ok(Map.of(
            "message", "This endpoint is only accessible to USER role",
            "user", auth.getName(),
            "authorities", auth.getAuthorities()
        ));
    }

    // ==== Internal/Admin Endpoints for Service-to-Service Communication ====
    
    @GetMapping("/internal/{userId}/email")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> getUserEmailById(@PathVariable("userId") UUID userId) {
        try {
            Map<String, Object> profile = userService.getUserProfile(userId);
            String email = (String) profile.get("email");
            return ResponseEntity.ok(email);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
