package com.hashedin.parking.user.UserController;

import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hashedin.parking.common.security.JwtUtils;
import com.hashedin.parking.common.security.Roles;
import com.hashedin.parking.common.web.SecurityConstants;
import com.hashedin.parking.user.security.TokenBlacklistService;
import com.hashedin.parking.user.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService userService;
    private final String jwtSecret;
    private final TokenBlacklistService blacklistService;

    public AuthController(UserService userService,
                          TokenBlacklistService blacklistService,
                          @Value("${app.jwt.secret}") String jwtSecret) {
        this.userService = userService;
        this.blacklistService = blacklistService;
        this.jwtSecret = jwtSecret;
    }

    public record RegisterRequest(@NotBlank String fullName, @Email String email, @NotBlank String password, Roles role) {}
    public record LoginRequest(@Email String email, @NotBlank String password) {}
    public record TokenResponse(String token) {}
    public record ChangePasswordRequest(@NotBlank String oldPassword, @NotBlank String newPassword) {}
    public record ForgotPasswordRequest(@Email String email) {}
    public record ResetPasswordRequest(@NotBlank String token, @NotBlank String newPassword) {}


    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody RegisterRequest req) {
        Map<String, Object> result = userService.registerUser(
            req.fullName(), 
            req.email(), 
            req.password(), 
            req.role()
        );
        return ResponseEntity.ok(result);
    }

//    @GetMapping("/getbyId")
//    public ResponseEntity<?> getById(@RequestParam UUID id) {
//
//        User u = repo.findById(id).orElse(null);
//        if (u == null) {
//            return ResponseEntity.notFound().build();
//        }
//        return ResponseEntity.ok(Map.of("id", u.getId(), "email", u.getEmail(), "role", u.getRole()));
//    }
//    @GetMapping("getBYEmail")
//    public ResponseEntity<?> getByEmail(@RequestParam String email) {
//        User u = repo.findByEmail(email).orElse(null);
//        if (u == null) {
//            return ResponseEntity.notFound().build();
//        }
//        return ResponseEntity.ok(Map.of("id", u.getId(), "email", u.getEmail(), "role", u.getRole()));
//    }
    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest req) {
        Map<String, Object> result = userService.loginUser(req.email(), req.password());
        return ResponseEntity.ok(new TokenResponse((String) result.get("token")));
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logoutUser(HttpServletRequest request) {
        String header = request.getHeader(SecurityConstants.AUTH_HEADER);
        if (header != null && header.startsWith(SecurityConstants.BEARER_PREFIX)) {
            String token = header.substring(SecurityConstants.BEARER_PREFIX.length());
            try {
                JwtUtils jwt = new JwtUtils(jwtSecret, 3600);
                long expMillis = jwt.parse(token).getBody().getExpiration().getTime();
                long nowMillis = System.currentTimeMillis();
                long ttlSeconds = Math.max(1, (expMillis - nowMillis) / 1000);
                blacklistService.blacklist(token, ttlSeconds);
            } catch (Exception ignored) {
                // token invalid or already expired -> nothing to do
            }
        }
        return ResponseEntity.ok(Map.of("message", "logged out"));
    }

    // ==== Change password (requires auth) ====
    @PostMapping("/change-password")
    public ResponseEntity<?> changePassword(Authentication auth, @RequestBody ChangePasswordRequest req) {
        if (auth == null) return ResponseEntity.status(401).body(Map.of("error","unauthorized"));

        Map<String, Object> result = userService.changePassword(
            UUID.fromString(auth.getName()),
            req.oldPassword(),
            req.newPassword()
        );
        return ResponseEntity.ok(result);
    }


    @PostMapping("/forgot-password")
    public ResponseEntity<?> requestPasswordReset(@RequestBody ForgotPasswordRequest req) {
        Map<String, Object> result = userService.forgotPassword(req.email());
        return ResponseEntity.ok(result);
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPasswordWithToken(@RequestBody ResetPasswordRequest req) {
        Map<String, Object> result = userService.resetPassword(req.token(), req.newPassword());
        return ResponseEntity.ok(result);
    }
//    // ==== Forgot / Reset password (anonymous) ====
//    @PostMapping("/forgot-password")
//    public ResponseEntity<?> forgotPassword(@RequestBody ForgotPasswordRequest req) {
//        User u = repo.findByEmail(req.email()).orElse(null);
//        // Don't leak user existence
//        if (u == null) {
//            return ResponseEntity.ok(Map.of("message", "If the email exists, a reset token has been generated"));
//        }
//        String token = UUID.randomUUID().toString();
//        PasswordResetToken prt = new PasswordResetToken();
//        prt.setUserId(u.getId());
//        prt.setToken(token);
//        prt.setExpiresAt(LocalDateTime.now().plusHours(1));
//        resetRepo.save(prt);
//
//        // TODO: call Notification service to email a reset link containing the token.
//        return ResponseEntity.ok(Map.of("message", "If the email exists, a reset token has been generated"));
//    }
//
//    @PostMapping("/reset-password")
//    public ResponseEntity<?> resetPassword(@RequestBody ResetPasswordRequest req) {
//        var prtOpt = resetRepo.findByToken(req.token());
//        if (prtOpt.isEmpty()) {
//            return ResponseEntity.badRequest().body(Map.of("error", "invalid or expired token"));
//        }
//        PasswordResetToken prt = prtOpt.get();
//        if (prt.getExpiresAt().isBefore(LocalDateTime.now())) {
//            resetRepo.delete(prt);
//            return ResponseEntity.badRequest().body(Map.of("error", "invalid or expired token"));
//        }
//        User u = repo.findById(prt.getUserId()).orElse(null);
//        if (u == null) {
//            resetRepo.delete(prt);
//            return ResponseEntity.badRequest().body(Map.of("error", "user not found"));
//        }
//        u.setPasswordHash(BCrypt.hashpw(req.newPassword(), BCrypt.gensalt()));
//        repo.save(u);
//        resetRepo.delete(prt);
//        return ResponseEntity.ok(Map.of("message", "password reset successful"));
//    }
}
