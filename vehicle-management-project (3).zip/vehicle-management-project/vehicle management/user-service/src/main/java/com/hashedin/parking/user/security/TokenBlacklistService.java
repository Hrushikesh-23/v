package com.hashedin.parking.user.security;

import java.time.Duration;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class TokenBlacklistService {
    //private final RedisTemplate<String, String> redis;
    private final StringRedisTemplate redis;

    public TokenBlacklistService(StringRedisTemplate redis) {
        this.redis = redis;
    }
    //public TokenBlacklistService(RedisTemplate<String, String> redis) {
//        this.redis = redis;
//    }

    public void blacklist(String token, long expirySeconds) {
        if (expirySeconds <= 0) {
            expirySeconds = 1;
        }
        redis.opsForValue().set("blacklist:" + token, "1", Duration.ofSeconds(expirySeconds));
    }

    public boolean isBlacklisted(String token) {
        return Boolean.TRUE.equals(redis.hasKey("blacklist:" + token));
    }
}
