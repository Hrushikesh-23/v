package com.hashedin.parking.user.service;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hashedin.parking.common.events.Events;
import com.hashedin.parking.common.security.JwtUtils;
import com.hashedin.parking.common.security.Roles;
import com.hashedin.parking.user.cache.ProfileCache;
import com.hashedin.parking.user.model.PasswordResetToken;
import com.hashedin.parking.user.model.User;
import com.hashedin.parking.user.repo.PasswordResetRepo;
import com.hashedin.parking.user.repo.UserRepo;

@Service
public class UserService {

    private final UserRepo userRepo;
    private final PasswordResetRepo passwordResetRepo;
    private final ProfileCache profileCache;
    private final RabbitTemplate rabbitTemplate;
    private final String exchange;
    private final String notifyEmailRouting;
    private final String userProfileUpdatedRouting;
    private final String jwtSecret;

    public UserService(UserRepo userRepo,
                      PasswordResetRepo passwordResetRepo,
                      ProfileCache profileCache,
                      RabbitTemplate rabbitTemplate,
                      @Value("${app.rabbit.exchange}") String exchange,
                      @Value("${app.rabbit.routing.notifyEmail}") String notifyEmailRouting,
                      @Value("${app.rabbit.routing.userProfileUpdated}") String userProfileUpdatedRouting,
                      @Value("${app.jwt.secret}") String jwtSecret) {
        this.userRepo = userRepo;
        this.passwordResetRepo = passwordResetRepo;
        this.profileCache = profileCache;
        this.rabbitTemplate = rabbitTemplate;
        this.exchange = exchange;
        this.notifyEmailRouting = notifyEmailRouting;
        this.userProfileUpdatedRouting = userProfileUpdatedRouting;
        this.jwtSecret = jwtSecret;
    }

    @Transactional
    public Map<String, Object> registerUser(String fullName, String email, String password, Roles role) {
        if (userRepo.findByEmail(email).isPresent()) {
            throw new IllegalArgumentException("Email already exists");
        }
        
        User user = new User();
        user.setEmail(email);
        user.setFullName(fullName);
        user.setPasswordHash(BCrypt.hashpw(password, BCrypt.gensalt()));
        user.setRole(role != null ? role : Roles.USER);
        
        User savedUser = userRepo.save(user);
        
        // Cache user profile
        Map<String, Object> profileData = Map.of(
            "id", savedUser.getId(),
            "email", savedUser.getEmail(),
            "fullName", savedUser.getFullName(),
            "role", savedUser.getRole()
        );
        profileCache.put(savedUser.getId().toString(), profileData, Duration.ofHours(1));
        
        return Map.of(
            "id", savedUser.getId(),
            "email", savedUser.getEmail(),
            "role", savedUser.getRole()
        );
    }

    public Map<String, Object> loginUser(String email, String password) {
        User user = userRepo.findByEmail(email)
            .orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));
            
        if (!BCrypt.checkpw(password, user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid credentials");
        }
        
        JwtUtils jwt = new JwtUtils(jwtSecret, 3600);
        String token = jwt.generateToken(
            user.getId().toString(),
            Map.of("email", user.getEmail(), "role", user.getRole().name())
        );
        
        return Map.of("token", token);
    }

    @Transactional
    public Map<String, Object> changePassword(UUID userId, String oldPassword, String newPassword) {
        User user = userRepo.findById(userId)
            .orElseThrow(() -> new IllegalArgumentException("User not found"));
            
        if (!BCrypt.checkpw(oldPassword, user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid old password");
        }
        
        user.setPasswordHash(BCrypt.hashpw(newPassword, BCrypt.gensalt()));
        userRepo.save(user);
        
        // Update cache
        Map<String, Object> profileData = Map.of(
            "id", user.getId(),
            "email", user.getEmail(),
            "fullName", user.getFullName(),
            "role", user.getRole()
        );
        profileCache.put(userId.toString(), profileData, Duration.ofHours(1));
        
        // Send email notification
        rabbitTemplate.convertAndSend(
            exchange,
            notifyEmailRouting,
            new Events.NotifyEmail(
                user.getId(),
                user.getEmail(),
                "Password Changed Successfully",
                "Hi " + (user.getFullName() == null ? "" : user.getFullName()) +
                    ",\n\nYour password has been changed successfully. " +
                    "If you did not make this change, please contact support immediately.\n\n" +
                    "Best regards,\nVehicle Parking Management Team"
            )
        );
        
        return Map.of("message", "password updated");
    }

    @Transactional
    public Map<String, Object> forgotPassword(String email) {
        Optional<User> userOpt = userRepo.findByEmail(email);
        
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            String token = UUID.randomUUID().toString();
            
            PasswordResetToken resetToken = new PasswordResetToken();
            resetToken.setUserId(user.getId());
            resetToken.setToken(token);
            resetToken.setExpiresAt(LocalDateTime.now().plusHours(1));
            passwordResetRepo.save(resetToken);

            // Send reset email
            String resetLink = "http://localhost:3000/reset-password?token=" +
                URLEncoder.encode(token, StandardCharsets.UTF_8);
            
            rabbitTemplate.convertAndSend(
                exchange,
                notifyEmailRouting,
                new Events.NotifyEmail(
                    user.getId(),
                    user.getEmail(),
                    "Password reset",
                    "Hi " + (user.getFullName() == null ? "" : user.getFullName()) +
                        ",\n\nUse this link to reset your password:\n" + resetLink +
                        "\n\nIf you didn't request this, ignore this email."
                )
            );
        }
        
        return Map.of("message", "If the email exists, a reset link has been sent.");
    }

    @Transactional
    public Map<String, Object> resetPassword(String token, String newPassword) {
        PasswordResetToken resetToken = passwordResetRepo.findByToken(token)
            .orElseThrow(() -> new IllegalArgumentException("Invalid or expired token"));
            
        if (resetToken.getExpiresAt().isBefore(LocalDateTime.now())) {
            passwordResetRepo.delete(resetToken);
            throw new IllegalArgumentException("Invalid or expired token");
        }
        
        User user = userRepo.findById(resetToken.getUserId())
            .orElseThrow(() -> new IllegalArgumentException("User not found"));
            
        user.setPasswordHash(BCrypt.hashpw(newPassword, BCrypt.gensalt()));
        userRepo.save(user);
        passwordResetRepo.delete(resetToken);
        
        // Update cache
        Map<String, Object> profileData = Map.of(
            "id", user.getId(),
            "email", user.getEmail(),
            "fullName", user.getFullName(),
            "role", user.getRole()
        );
        profileCache.put(user.getId().toString(), profileData, Duration.ofHours(1));
        
        // Send confirmation email
        rabbitTemplate.convertAndSend(
            exchange,
            notifyEmailRouting,
            new Events.NotifyEmail(
                user.getId(),
                user.getEmail(),
                "Password reset successful",
                "Hi " + (user.getFullName() == null ? "" : user.getFullName()) +
                    ",\n\nYour password has been reset successfully."
            )
        );
        
        return Map.of("message", "password reset successful");
    }

    public Map<String, Object> getUserProfile(UUID userId) {
        // Try cache first
        Map<String, Object> cachedProfile = profileCache.get(userId.toString());
        if (cachedProfile != null) {
            return cachedProfile;
        }
        
        // Fetch from database
        User user = userRepo.findById(userId)
            .orElseThrow(() -> new IllegalArgumentException("User not found"));
            
        // Cache the result
        Map<String, Object> profileData = Map.of(
            "id", user.getId(),
            "email", user.getEmail(),
            "fullName", user.getFullName(),
            "role", user.getRole()
        );
        profileCache.put(userId.toString(), profileData, Duration.ofHours(1));
        
        return profileData;
    }

    @Transactional
    public Map<String, Object> updateProfile(UUID userId, String fullName, String email) {
        User user = userRepo.findById(userId)
            .orElseThrow(() -> new IllegalArgumentException("User not found"));
            
        boolean hasChanges = false;
        
        if (fullName != null && !fullName.equals(user.getFullName())) {
            user.setFullName(fullName);
            hasChanges = true;
        }
        
        if (email != null && !email.equals(user.getEmail())) {
            if (userRepo.findByEmail(email).isPresent()) {
                throw new IllegalArgumentException("Email already exists");
            }
            user.setEmail(email);
            hasChanges = true;
        }
        
        if (!hasChanges) {
            return Map.of("message", "no changes detected");
        }
        
        User savedUser = userRepo.save(user);
        
        // Update cache
        Map<String, Object> profileData = Map.of(
            "id", savedUser.getId(),
            "email", savedUser.getEmail(),
            "fullName", savedUser.getFullName(),
            "role", savedUser.getRole()
        );
        profileCache.put(userId.toString(), profileData, Duration.ofHours(1));
        
        // Publish profile updated event
        rabbitTemplate.convertAndSend(
            exchange,
            userProfileUpdatedRouting,
            new Events.UserProfileUpdated(
                savedUser.getId(),
                savedUser.getEmail(),
                savedUser.getFullName(),
                savedUser.getRole()
            )
        );
        
        return Map.of(
            "message", "profile updated successfully",
            "user", Map.of(
                "id", savedUser.getId(),
                "email", savedUser.getEmail(),
                "fullName", savedUser.getFullName(),
                "role", savedUser.getRole()
            )
        );
    }

    public User getUserById(UUID userId) {
        return userRepo.findById(userId)
            .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }

    public User getUserByEmail(String email) {
        return userRepo.findByEmail(email)
            .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }
}
