package com.hashedin.parking.user.mq;

import java.time.LocalDateTime;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import com.hashedin.parking.common.events.Events;
import com.hashedin.parking.user.repo.UserRepo;

@Component
public class BookingEventListener {

    private static final Logger log = LoggerFactory.getLogger(BookingEventListener.class);
    private final UserRepo users;

    public BookingEventListener(UserRepo users) {
        this.users = users;
    }

    //@RabbitListener(queues = "${app.rabbit.queues.userService.bookingCreated}")
    @RabbitListener(queues = "#{userBookingCreatedQueue.name}")
    public void onBookingCreated(Events.BookingCreated ev) {
        try {
            UUID userId = ev.userId();
            users.findById(userId).ifPresent(u -> {
                Integer currentCount = u.getBookingCount();
                Integer count = currentCount == null ? 0 : currentCount;
                u.setBookingCount(count + 1);
                u.setLastBookingAt(LocalDateTime.now());
                users.save(u);
            });
        } catch (Exception e) {
            log.warn("Failed updating user booking stats for booking {}: {}", ev.bookingId(), e.getMessage());
        }
    }
}
