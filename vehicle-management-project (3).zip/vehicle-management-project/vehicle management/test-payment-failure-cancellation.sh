#!/bin/bash

# Test Payment Failure → Booking Cancellation → Slot Availability Scenario:
# 1. Person A creates booking
# 2. Payment is initiated
# 3. Payment fails
# 4. Booking should be automatically cancelled
# 5. Slot should be available for another person (via waitlist or direct booking)

BASE_URL_BOOKING="http://localhost:8083"
BASE_URL_PAYMENT="http://localhost:8084"
GATEWAY_URL="http://localhost:8080"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

echo "========================================="
echo "PAYMENT FAILURE → BOOKING CANCELLATION TEST"
echo "Scenario: Payment fails → Booking cancelled → Slot available"
echo "========================================="
echo ""

# Setup admin
ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ -z "$ADMIN_TOKEN" ]; then
    curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
        -H "Content-Type: application/json" \
        -d '{"fullName":"Test Admin","email":"admintest@example.com","password":"admin123","role":"ADMIN"}' > /dev/null
    sleep 1
    ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
        -H "Content-Type: application/json" \
        -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)
fi

# Get lot and create spot
LOTS_RESPONSE=$(curl -s -X GET "${GATEWAY_URL}/api/lots" -H "Authorization: Bearer ${ADMIN_TOKEN}")
LOT_ID=$(echo "$LOTS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0]['id'] if data else '')" 2>/dev/null)

SPOT_CODE="PAYMENT-FAIL-TEST-$(date +%s)"
SPOT_CREATE_RESPONSE=$(curl -s -X POST "${GATEWAY_URL}/api/lots/${LOT_ID}/spots" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${ADMIN_TOKEN}" \
    -d "{\"code\":\"${SPOT_CODE}\",\"available\":true}")

sleep 1
SPOTS_RESPONSE=$(curl -s -X GET "${GATEWAY_URL}/api/lots/${LOT_ID}/spots" -H "Authorization: Bearer ${ADMIN_TOKEN}")
SPOT_ID=$(echo "$SPOTS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); spot=[s for s in data if s.get('code')=='${SPOT_CODE}']; print(spot[0]['id'] if spot else '')" 2>/dev/null)

echo "Using Lot ID: $LOT_ID, Spot ID: $SPOT_ID"
echo ""

# Register User A
USER_A_EMAIL="paymentfailuser_$(date +%s)@example.com"
echo "Registering User A: ${USER_A_EMAIL}"
curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"fullName\":\"Payment Fail User\",\"email\":\"${USER_A_EMAIL}\",\"password\":\"password123\",\"role\":\"USER\"}" > /dev/null
sleep 1

LOGIN_A=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"${USER_A_EMAIL}\",\"password\":\"password123\"}")
USER_A_TOKEN=$(echo "$LOGIN_A" | grep -o '"token":"[^"]*' | cut -d'"' -f4)

# Register User B (to test slot availability after cancellation)
USER_B_EMAIL="waitlistuser_$(date +%s)@example.com"
echo "Registering User B: ${USER_B_EMAIL}"
curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"fullName\":\"Waitlist User\",\"email\":\"${USER_B_EMAIL}\",\"password\":\"password123\",\"role\":\"USER\"}" > /dev/null
sleep 1

LOGIN_B=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"${USER_B_EMAIL}\",\"password\":\"password123\"}")
USER_B_TOKEN=$(echo "$LOGIN_B" | grep -o '"token":"[^"]*' | cut -d'"' -f4)

echo "✅ Users registered"
echo ""

# Calculate future dates
DAY_AFTER_TOMORROW=$(date -v+2d +%Y-%m-%d 2>/dev/null || date -d "+2 days" +%Y-%m-%d)
START_TIME="${DAY_AFTER_TOMORROW}T10:00:00"
END_TIME="${DAY_AFTER_TOMORROW}T14:00:00"

echo "========================================="
echo "STEP 1: User A Creates Booking"
echo "========================================="
echo "Time Window: ${START_TIME} to ${END_TIME}"
echo ""

BOOKING_RESPONSE=$(curl -s -X POST "${BASE_URL_BOOKING}/api/bookings" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${USER_A_TOKEN}" \
    -d "{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START_TIME}\",\"endTime\":\"${END_TIME}\"}")

echo "Booking Response:"
echo "$BOOKING_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$BOOKING_RESPONSE"
echo ""

BOOKING_ID=$(echo "$BOOKING_RESPONSE" | grep -o '"id":"[^"]*' | cut -d'"' -f4)

if [ -z "$BOOKING_ID" ]; then
    echo -e "${COLOR_RED}✗ Booking creation failed${COLOR_NC}"
    exit 1
fi

echo -e "${COLOR_GREEN}✓ Booking created: ${BOOKING_ID}${COLOR_NC}"
echo ""

# Wait for async confirmation
sleep 3

BOOKING_CHECK=$(curl -s -X GET "${BASE_URL_BOOKING}/api/bookings/${BOOKING_ID}" -H "Authorization: Bearer ${USER_A_TOKEN}")
BOOKING_STATUS=$(echo "$BOOKING_CHECK" | grep -o '"status":"[^"]*' | cut -d'"' -f4)
echo "Booking Status: $BOOKING_STATUS"
echo ""

echo "========================================="
echo "STEP 2: User A Initiates Payment"
echo "========================================="
echo ""

PAYMENT_AMOUNT=75.00
# Wait a moment for payment to be auto-created from booking event
sleep 2

# Check if payment already exists (auto-created by payment service listener)
EXISTING_PAYMENTS=$(curl -s -X GET "${BASE_URL_PAYMENT}/api/payments/booking/${BOOKING_ID}" -H "Authorization: Bearer ${USER_A_TOKEN}")
PAYMENT_ID=$(echo "$EXISTING_PAYMENTS" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0]['id'] if data and len(data) > 0 else '')" 2>/dev/null)

if [ -z "$PAYMENT_ID" ]; then
    # Try to create payment manually
    PAYMENT_RESPONSE=$(curl -s -X POST "${BASE_URL_PAYMENT}/api/payments" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${USER_A_TOKEN}" \
        -d "{\"bookingId\":\"${BOOKING_ID}\",\"amount\":${PAYMENT_AMOUNT}}")
    
    echo "Payment Response:"
    echo "$PAYMENT_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$PAYMENT_RESPONSE"
    echo ""
    
    PAYMENT_ID=$(echo "$PAYMENT_RESPONSE" | grep -o '"id":"[^"]*' | cut -d'"' -f4)
    
    if [ -z "$PAYMENT_ID" ]; then
        echo -e "${COLOR_RED}✗ Payment initiation failed${COLOR_NC}"
        exit 1
    fi
    echo -e "${COLOR_GREEN}✓ Payment initiated: ${PAYMENT_ID}${COLOR_NC}"
else
    echo -e "${COLOR_GREEN}✓ Payment already exists (auto-created): ${PAYMENT_ID}${COLOR_NC}"
    echo "Payment Details:"
    echo "$EXISTING_PAYMENTS" | python3 -m json.tool 2>/dev/null || echo "$EXISTING_PAYMENTS"
fi

PAYMENT_STATUS=$(echo "$EXISTING_PAYMENTS" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0]['status'] if data and len(data) > 0 else 'PENDING')" 2>/dev/null || echo "PENDING")
echo "Payment Status: $PAYMENT_STATUS"
echo ""

echo "========================================="
echo "STEP 3: User B Tries to Book Same Slot"
echo "========================================="
echo ""

# User B tries to book - should go to waitlist
BOOKING_B_RESPONSE=$(curl -s -X POST "${BASE_URL_BOOKING}/api/bookings/waitlist" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${USER_B_TOKEN}" \
    -d "{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START_TIME}\",\"endTime\":\"${END_TIME}\"}")

echo "User B Waitlist Response:"
echo "$BOOKING_B_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$BOOKING_B_RESPONSE"
echo ""

WAITLIST_ID=$(echo "$BOOKING_B_RESPONSE" | grep -o '"waitlistId":"[^"]*' | cut -d'"' -f4)
if [ ! -z "$WAITLIST_ID" ]; then
    echo -e "${COLOR_GREEN}✓ User B added to waitlist: ${WAITLIST_ID}${COLOR_NC}"
else
    echo -e "${COLOR_YELLOW}⚠ User B not added to waitlist (may have failed)${COLOR_NC}"
fi
echo ""

echo "========================================="
echo "STEP 4: Payment Fails"
echo "========================================="
echo ""

FAIL_REASON="Insufficient funds - card declined"
FAIL_RESPONSE=$(curl -s -X POST "${BASE_URL_PAYMENT}/api/payments/${PAYMENT_ID}/fail?reason=${FAIL_REASON}" \
    -H "Authorization: Bearer ${USER_A_TOKEN}")

echo "Payment Failure Response:"
echo "$FAIL_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$FAIL_RESPONSE"
echo ""

if echo "$FAIL_RESPONSE" | grep -q "failed\|success"; then
    echo -e "${COLOR_GREEN}✓ Payment marked as failed${COLOR_NC}"
else
    echo -e "${COLOR_YELLOW}⚠ Payment failure may need to be processed${COLOR_NC}"
fi

# Wait for async processing (payment failure event → booking cancellation should happen)
echo "Waiting for payment failure event processing and booking cancellation (7 seconds)..."
sleep 7
echo ""

echo "========================================="
echo "STEP 5: Verify Booking Cancellation"
echo "========================================="
echo ""

# Check booking status
BOOKING_CHECK_AFTER=$(curl -s -X GET "${BASE_URL_BOOKING}/api/bookings/${BOOKING_ID}" -H "Authorization: Bearer ${USER_A_TOKEN}")
BOOKING_STATUS_AFTER=$(echo "$BOOKING_CHECK_AFTER" | grep -o '"status":"[^"]*' | cut -d'"' -f4)

echo "Booking Status After Payment Failure: $BOOKING_STATUS_AFTER"

if [ "$BOOKING_STATUS_AFTER" = "CANCELLED" ]; then
    echo -e "${COLOR_GREEN}✅ Booking automatically cancelled!${COLOR_NC}"
else
    echo -e "${COLOR_YELLOW}⚠ Booking status: $BOOKING_STATUS_AFTER (expected: CANCELLED)${COLOR_NC}"
    echo "  This might need more time for async processing or the listener needs to be checked"
fi
echo ""

echo "========================================="
echo "STEP 6: Verify Slot Availability"
echo "========================================="
echo ""

# Check if User B's waitlist entry was promoted to booking
WAITLIST_CHECK=$(curl -s -X GET "${BASE_URL_BOOKING}/api/bookings/waitlist" -H "Authorization: Bearer ${USER_B_TOKEN}")
echo "User B's Waitlist Entries:"
echo "$WAITLIST_CHECK" | python3 -m json.tool 2>/dev/null || echo "$WAITLIST_CHECK"
echo ""

BOOKINGS_B=$(curl -s -X GET "${BASE_URL_BOOKING}/api/bookings" -H "Authorization: Bearer ${USER_B_TOKEN}")
BOOKING_B_ID=$(echo "$BOOKINGS_B" | grep -o '"id":"[^"]*' | cut -d'"' -f4 | head -1)

if [ ! -z "$BOOKING_B_ID" ]; then
    echo -e "${COLOR_GREEN}✅ User B now has a booking!${COLOR_NC}"
    echo "  Booking ID: $BOOKING_B_ID"
    echo "  This means the slot became available and waitlist was processed!"
else
    echo -e "${COLOR_YELLOW}⚠ User B doesn't have a booking yet${COLOR_NC}"
    echo "  Waitlist processing may need more time"
fi
echo ""

# Try direct booking to verify slot is available
echo "Attempting direct booking to verify slot availability..."
DIRECT_BOOKING=$(curl -s -X POST "${BASE_URL_BOOKING}/api/bookings" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${USER_B_TOKEN}" \
    -d "{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START_TIME}\",\"endTime\":\"${END_TIME}\"}")

DIRECT_BOOKING_ID=$(echo "$DIRECT_BOOKING" | grep -o '"id":"[^"]*' | cut -d'"' -f4)

if [ ! -z "$DIRECT_BOOKING_ID" ]; then
    echo -e "${COLOR_GREEN}✅ Slot is available! Direct booking successful: ${DIRECT_BOOKING_ID}${COLOR_NC}"
elif echo "$DIRECT_BOOKING" | grep -q "waitlist"; then
    echo -e "${COLOR_YELLOW}⚠ Slot may still be considered unavailable (went to waitlist)${COLOR_NC}"
else
    echo -e "${COLOR_YELLOW}⚠ Could not verify slot availability directly${COLOR_NC}"
fi
echo ""

echo "========================================="
echo "MONITORING"
echo "========================================="
echo ""

echo -e "${COLOR_BLUE}[RABBITMQ] Payment status event queue:${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "
import sys, json
data = json.load(sys.stdin)
queues = [q for q in data if 'payment' in q['name'].lower() and 'status' in q['name'].lower()]
for q in queues:
    print(f\"  - {q['name']}: {q.get('messages', 0)} messages, {q.get('consumers', 0)} consumers\")
" 2>/dev/null

echo ""
echo -e "${COLOR_BLUE}[RABBITMQ] Booking service payment status listener:${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "
import sys, json
data = json.load(sys.stdin)
queues = [q for q in data if 'booking' in q['name'].lower() and 'payment' in q['name'].lower()]
for q in queues:
    print(f\"  - {q['name']}: {q.get('messages', 0)} messages, {q.get('consumers', 0)} consumers\")
" 2>/dev/null

echo ""
echo "========================================="
echo "TEST RESULTS"
echo "========================================="
echo ""

if [ "$BOOKING_STATUS_AFTER" = "CANCELLED" ]; then
    echo -e "${COLOR_GREEN}✅ TEST PASSED!${COLOR_NC}"
    echo ""
    echo "Flow Summary:"
    echo "  1. ✅ User A created booking"
    echo "  2. ✅ Payment initiated"
    echo "  3. ✅ User B added to waitlist"
    echo "  4. ✅ Payment failed"
    echo "  5. ✅ Booking automatically cancelled"
    if [ ! -z "$BOOKING_B_ID" ]; then
        echo "  6. ✅ Slot became available (User B got booking from waitlist)"
    fi
    echo ""
    echo "✅ Payment failure → Booking cancellation → Slot availability flow working!"
else
    echo -e "${COLOR_YELLOW}⚠ TEST INCOMPLETE${COLOR_NC}"
    echo ""
    echo "Expected:"
    echo "  - Payment failure should trigger booking cancellation"
    echo "  - Booking status should change to CANCELLED"
    echo "  - Slot should become available"
    echo ""
    echo "Actual:"
    echo "  - Booking status: $BOOKING_STATUS_AFTER"
    echo ""
    echo "Note: This might need more processing time or the listener may need configuration"
fi

echo ""
echo "========================================="
echo "TEST COMPLETE"
echo "========================================="

