package com.hashedin.parking.payment.web;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hashedin.parking.payment.model.Payment;
import com.hashedin.parking.payment.service.PaymentService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    public record InitiateRequest(@NotNull UUID bookingId, @NotNull BigDecimal amount) {}

    @PostMapping
    public ResponseEntity<?> initiatePayment(Authentication auth, @Valid @RequestBody InitiateRequest req) {
        Payment payment = paymentService.initiatePayment(
            UUID.fromString(auth.getName()),
            req.bookingId(),
            req.amount()
        );
        return ResponseEntity.ok(payment);
    }

    @PostMapping("/{paymentId}/confirm")
    public ResponseEntity<?> confirmPayment(@PathVariable("paymentId") UUID paymentId) {
        Map<String, String> result = paymentService.confirmPayment(paymentId);
        return ResponseEntity.ok(result);
    }

    @GetMapping
    public List<Payment> getMyPayments(Authentication auth) {
        return paymentService.getUserPayments(UUID.fromString(auth.getName()));
    }

    @GetMapping("/booking/{bookingId}")
    public List<Payment> getPaymentsByBooking(@PathVariable("bookingId") UUID bookingId) {
        return paymentService.getPaymentsByBooking(bookingId);
    }

    @GetMapping("/date-range")
    public List<Payment> getPaymentsByDateRange(@RequestParam String from, @RequestParam String to) {
        return paymentService.getPaymentsByDateRange(
            LocalDateTime.parse(from), 
            LocalDateTime.parse(to)
        );
    }

    @GetMapping("/status/{status}")
    public List<Payment> getPaymentsByStatus(@PathVariable("status") String status) {
        return paymentService.getPaymentsByStatus(status);
    }

    // ==== Admin Endpoints ====
    
    @GetMapping("/admin/all")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Payment> getAllPaymentsForAdmin() {
        return paymentService.getAllPayments();
    }

    @GetMapping("/admin/user/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Payment> getPaymentsByUserIdForAdmin(@PathVariable("userId") UUID userId) {
        return paymentService.getUserPayments(userId);
    }

    @GetMapping("/admin/status/{status}")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Payment> getPaymentsByStatusForAdmin(@PathVariable("status") String status) {
        return paymentService.getPaymentsByStatus(status);
    }

    @PostMapping("/{paymentId}/fail")
    public ResponseEntity<?> markPaymentAsFailed(@PathVariable("paymentId") UUID paymentId, 
                                       @RequestParam(required = false) String reason,
                                       Authentication auth) {
        Map<String, String> result = paymentService.failPayment(paymentId, reason);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/admin/cache/clear")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> clearPaymentCache() {
        Map<String, String> result = paymentService.clearCache();
        return ResponseEntity.ok(result);
    }

    // ==== Internal/Admin Endpoints for Service-to-Service Communication ====
    
    @GetMapping("/internal/pending")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Payment> getPendingPaymentsOlderThan(@RequestParam(defaultValue = "1") int olderThanHours) {
        return paymentService.getPendingPaymentsOlderThan(olderThanHours);
    }
}
