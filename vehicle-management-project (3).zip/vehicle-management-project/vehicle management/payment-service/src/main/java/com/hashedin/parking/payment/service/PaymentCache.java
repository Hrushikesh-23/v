package com.hashedin.parking.payment.service;

import com.hashedin.parking.payment.model.Payment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Component
public class PaymentCache {
    
    private final RedisTemplate<String, Object> redis;
    
    public PaymentCache(RedisTemplate<String, Object> redis) {
        this.redis = redis;
    }
    
    private String userPaymentsKey(UUID userId) {
        return "payments:user:" + userId;
    }
    
    private String bookingPaymentsKey(UUID bookingId) {
        return "payments:booking:" + bookingId;
    }
    
    private String paymentKey(UUID paymentId) {
        return "payment:" + paymentId;
    }
    
    private String statusPaymentsKey(String status) {
        return "payments:status:" + status;
    }
    
    public List<Payment> getUserPayments(UUID userId) {
        Object cached = redis.opsForValue().get(userPaymentsKey(userId));
        if (cached instanceof List<?> list) {
            @SuppressWarnings("unchecked")
            List<Payment> payments = (List<Payment>) list;
            return payments;
        }
        return null;
    }
    
    public void putUserPayments(UUID userId, List<Payment> payments, Duration ttl) {
        redis.opsForValue().set(userPaymentsKey(userId), payments, ttl.toSeconds(), TimeUnit.SECONDS);
    }
    
    public List<Payment> getBookingPayments(UUID bookingId) {
        Object cached = redis.opsForValue().get(bookingPaymentsKey(bookingId));
        if (cached instanceof List<?> list) {
            @SuppressWarnings("unchecked")
            List<Payment> payments = (List<Payment>) list;
            return payments;
        }
        return null;
    }
    
    public void putBookingPayments(UUID bookingId, List<Payment> payments, Duration ttl) {
        redis.opsForValue().set(bookingPaymentsKey(bookingId), payments, ttl.toSeconds(), TimeUnit.SECONDS);
    }
    
    public Payment getPayment(UUID paymentId) {
        Object cached = redis.opsForValue().get(paymentKey(paymentId));
        if (cached instanceof Payment payment) {
            return payment;
        }
        return null;
    }
    
    public void putPayment(Payment payment, Duration ttl) {
        redis.opsForValue().set(paymentKey(payment.getId()), payment, ttl.toSeconds(), TimeUnit.SECONDS);
    }
    
    public List<Payment> getPaymentsByStatus(String status) {
        Object cached = redis.opsForValue().get(statusPaymentsKey(status));
        if (cached instanceof List<?> list) {
            @SuppressWarnings("unchecked")
            List<Payment> payments = (List<Payment>) list;
            return payments;
        }
        return null;
    }
    
    public void putPaymentsByStatus(String status, List<Payment> payments, Duration ttl) {
        redis.opsForValue().set(statusPaymentsKey(status), payments, ttl.toSeconds(), TimeUnit.SECONDS);
    }
    
    public void evictUserPayments(UUID userId) {
        redis.delete(userPaymentsKey(userId));
    }
    
    public void evictBookingPayments(UUID bookingId) {
        redis.delete(bookingPaymentsKey(bookingId));
    }
    
    public void evictPayment(UUID paymentId) {
        redis.delete(paymentKey(paymentId));
    }
    
    public void evictPaymentsByStatus(String status) {
        redis.delete(statusPaymentsKey(status));
    }
    
    public Object getPaymentsByDateRange(String cacheKey) {
        return redis.opsForValue().get("payments:dateRange:" + cacheKey);
    }
    
    public void putPaymentsByDateRange(String cacheKey, List<Payment> payments, Duration ttl) {
        redis.opsForValue().set("payments:dateRange:" + cacheKey, payments, ttl.toSeconds(), TimeUnit.SECONDS);
    }
    
    public void evictPaymentsByDateRange(String cacheKey) {
        redis.delete("payments:dateRange:" + cacheKey);
    }

    public void evictAllPaymentCaches() {
        redis.delete(redis.keys("payments:*"));
        redis.delete(redis.keys("payment:*"));
    }
}
