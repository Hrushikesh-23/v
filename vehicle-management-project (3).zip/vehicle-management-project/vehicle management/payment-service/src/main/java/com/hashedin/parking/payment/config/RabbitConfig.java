package com.hashedin.parking.payment.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;

@Configuration
@EnableRabbit
public class RabbitConfig {

    // Exchange
    @Bean
    public TopicExchange bookingExchange(@Value("${app.rabbit.exchange}") String exchange) {
        return new TopicExchange(exchange, true, false);
    }

    // Queue this service OWNS (to consume booking.created)
    @Bean
    public Queue paymentBookingCreatedQueue(
            @Value("${app.queues.paymentService.bookingCreated}") String qName) {
        return QueueBuilder.durable(qName).build();
    }

    // Bind that queue to the booking.created routing key
    @Bean
    public Binding bindPaymentBookingCreated(Queue paymentBookingCreatedQueue,
                                             TopicExchange bookingExchange,
                                             @Value("${app.rabbit.routing.bookingCreated}") String rk) {
        return BindingBuilder.bind(paymentBookingCreatedQueue).to(bookingExchange).with(rk);
    }

    // JSON conversion for both publisher and listeners
    @Bean
    public Jackson2JsonMessageConverter jacksonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    // For @RabbitListener so it can deserialize JSON into your record classes
    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
            ConnectionFactory cf, Jackson2JsonMessageConverter converter) {
        SimpleRabbitListenerContainerFactory f = new SimpleRabbitListenerContainerFactory();
        f.setConnectionFactory(cf);
        f.setMessageConverter(converter);
        return f;
    }

    // For publishing payment.status events as JSON
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory cf, Jackson2JsonMessageConverter converter) {
        RabbitTemplate rt = new RabbitTemplate(cf);
        rt.setMessageConverter(converter);
        return rt;
    }

    // inside your existing class ...
    @Bean
    public Queue paymentUserProfileUpdatedQueue(
            @Value("${app.queues.paymentService.userProfileUpdated}") String qName) {
        return QueueBuilder.durable(qName).build();
    }

    @Bean
    public Binding bindPaymentUserProfileUpdated(Queue paymentUserProfileUpdatedQueue,
                                                 TopicExchange bookingExchange,
                                                 @Value("${app.rabbit.routing.userProfileUpdated}") String rk) {
        return BindingBuilder.bind(paymentUserProfileUpdatedQueue).to(bookingExchange).with(rk);
    }

    // Queue for booking cancelled events
    @Bean
    public Queue paymentBookingCancelledQueue(
            @Value("${app.queues.paymentService.bookingCancelled}") String qName) {
        return QueueBuilder.durable(qName).build();
    }

    @Bean
    public Binding bindPaymentBookingCancelled(Queue paymentBookingCancelledQueue,
                                              TopicExchange bookingExchange,
                                              @Value("${app.rabbit.routing.bookingCancelled}") String rk) {
        return BindingBuilder.bind(paymentBookingCancelledQueue).to(bookingExchange).with(rk);
    }

}
