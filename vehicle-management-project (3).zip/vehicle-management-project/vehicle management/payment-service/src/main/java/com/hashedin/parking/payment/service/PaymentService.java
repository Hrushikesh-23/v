package com.hashedin.parking.payment.service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hashedin.parking.common.events.Events;
import com.hashedin.parking.payment.model.Payment;
import com.hashedin.parking.payment.repo.PaymentRepo;

@Service
public class PaymentService {
    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);

    private final PaymentRepo paymentRepo;
    private final PaymentCache paymentCache;
    private final RabbitTemplate rabbitTemplate;
    private final String exchange;
    private final String paymentStatusRoutingKey;
    private final int processingDelaySeconds;

    public PaymentService(PaymentRepo paymentRepo,
                         PaymentCache paymentCache,
                         RabbitTemplate rabbitTemplate,
                         @Value("${app.rabbit.exchange}") String exchange,
                         @Value("${app.rabbit.routing.paymentStatus}") String paymentStatusRoutingKey,
                         @Value("${app.payment.processing.delay.seconds:3}") int processingDelaySeconds) {
        this.paymentRepo = paymentRepo;
        this.paymentCache = paymentCache;
        this.rabbitTemplate = rabbitTemplate;
        this.exchange = exchange;
        this.paymentStatusRoutingKey = paymentStatusRoutingKey;
        this.processingDelaySeconds = processingDelaySeconds;
    }

    @Transactional
    public Payment initiatePayment(UUID userId, UUID bookingId, BigDecimal amount) {
        log.info("Initiating payment for booking {} by user {} with amount {}", bookingId, userId, amount);
        
        // Check if payment already exists for this booking
        if (paymentRepo.existsByBookingIdAndStatus(bookingId, "PENDING")) {
            log.warn("Payment already exists for booking {}", bookingId);
            throw new IllegalArgumentException("Payment already exists for this booking");
        }
        
        Payment payment = new Payment();
        payment.setBookingId(bookingId);
        payment.setUserId(userId);
        payment.setAmount(amount);
        payment.setStatus("PENDING");
        
        Payment savedPayment = paymentRepo.save(payment);
        log.info("Payment {} initiated for booking {} by user {}", savedPayment.getId(), bookingId, userId);

        // Cache the payment
        paymentCache.putPayment(savedPayment, Duration.ofMinutes(30));

        // Evict related caches
        paymentCache.evictUserPayments(savedPayment.getUserId());
        paymentCache.evictBookingPayments(savedPayment.getBookingId());
        paymentCache.evictPaymentsByStatus("PENDING");

        // Publish payment status changed event
        rabbitTemplate.convertAndSend(
                exchange,
                paymentStatusRoutingKey,
                new Events.PaymentStatusChanged(
                        savedPayment.getId(), 
                        savedPayment.getBookingId(), 
                        savedPayment.getUserId(),
                        savedPayment.getAmount(), 
                        savedPayment.getStatus()
                )
        );
        
        return savedPayment;
    }

    @Transactional
    public Map<String, String> confirmPayment(UUID paymentId) {
        log.info("Confirming payment {}", paymentId);
        
        Payment payment = paymentRepo.findById(paymentId)
            .orElseThrow(() -> {
                log.warn("Payment {} not found for confirmation", paymentId);
                return new IllegalArgumentException("Payment not found");
            });
        
        // Prevent confirming payments that are already completed or failed
        String currentStatus = payment.getStatus();
        if ("COMPLETED".equals(currentStatus)) {
            log.warn("Attempted to confirm already COMPLETED payment {}", paymentId);
            throw new IllegalStateException("Payment is already COMPLETED and cannot be confirmed again");
        }
        if ("FAILED".equals(currentStatus)) {
            log.warn("Attempted to confirm FAILED payment {}", paymentId);
            throw new IllegalStateException("Payment is FAILED and cannot be confirmed");
        }
        if (!"PENDING".equals(currentStatus)) {
            log.warn("Attempted to confirm payment {} with status {}", paymentId, currentStatus);
            throw new IllegalStateException("Payment is not in PENDING status. Current status: " + currentStatus);
        }
        
        log.info("Payment {} is PENDING, initiating async processing", paymentId);

        rabbitTemplate.convertAndSend(
                exchange,
                paymentStatusRoutingKey,
                new Events.PaymentStatusChanged(
                        payment.getId(),
                        payment.getBookingId(),
                        payment.getUserId(),
                        payment.getAmount(),
                        payment.getStatus()
                )
        );
        // Process payment asynchronously with delay to mimic real-world payment processing
        processPaymentAsync(paymentId);
        
        return Map.of(
            "message", "Payment processing initiated. It will be confirmed shortly.",
            "paymentId", paymentId.toString(),
            "status", "PROCESSING"
        );
    }

    @Async("paymentTaskExecutor")
    @Transactional
    public void processPaymentAsync(UUID paymentId) {
        try {
            log.info("Starting async payment processing for payment: {}", paymentId);
            
            // Simulate payment processing delay (mimics real-world payment gateway delay)
            Thread.sleep(processingDelaySeconds * 1000L);
            
            Payment payment = paymentRepo.findById(paymentId)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found during async processing"));
            
            // Prevent state transitions: once COMPLETED or FAILED, don't change
            String currentStatus = payment.getStatus();
            if ("COMPLETED".equals(currentStatus)) {
                log.warn("Payment {} is already COMPLETED, skipping processing", paymentId);
                return;
            }
            if ("FAILED".equals(currentStatus)) {
                log.warn("Payment {} is FAILED, cannot be completed", paymentId);
                return;
            }
            
            // Simulate payment gateway verification (in real world, this would call payment gateway API)
            // For demo, we'll auto-confirm
            payment.setStatus("COMPLETED");
            Payment savedPayment = paymentRepo.save(payment);

            // Update cache
            paymentCache.putPayment(savedPayment, Duration.ofMinutes(30));

            // Evict related caches
            paymentCache.evictUserPayments(savedPayment.getUserId());
            paymentCache.evictBookingPayments(savedPayment.getBookingId());
            paymentCache.evictPaymentsByStatus("PENDING");
            paymentCache.evictPaymentsByStatus("COMPLETED");

            // Publish payment status changed event
            rabbitTemplate.convertAndSend(
                    exchange,
                    paymentStatusRoutingKey,
                    new Events.PaymentStatusChanged(
                            savedPayment.getId(), 
                            savedPayment.getBookingId(), 
                            savedPayment.getUserId(),
                            savedPayment.getAmount(), 
                            savedPayment.getStatus()
                    )
            );
            
            log.info("Payment {} processed successfully and confirmed", paymentId);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Payment processing interrupted for payment: {}", paymentId, e);
            failPaymentAsync(paymentId, "Processing interrupted");
        } catch (Exception e) {
            log.error("Error processing payment {}: {}", paymentId, e.getMessage(), e);
            failPaymentAsync(paymentId, "Processing failed: " + e.getMessage());
        }
    }

    @Async("paymentTaskExecutor")
    @Transactional
    public void failPaymentAsync(UUID paymentId, String reason) {
        try {
            Payment payment = paymentRepo.findById(paymentId).orElse(null);
            if (payment == null) {
                log.warn("Payment {} not found for async failure", paymentId);
                return;
            }
            
            // Prevent state transitions: once COMPLETED, cannot be failed
            String currentStatus = payment.getStatus();
            if ("COMPLETED".equals(currentStatus)) {
                log.warn("Payment {} is already COMPLETED, cannot be failed", paymentId);
                return;
            }
            if ("FAILED".equals(currentStatus)) {
                log.info("Payment {} is already FAILED, skipping", paymentId);
                return;
            }
            
            payment.setStatus("FAILED");
            Payment savedPayment = paymentRepo.save(payment);

            // Update cache
            paymentCache.putPayment(savedPayment, Duration.ofMinutes(30));

            // Evict related caches
            paymentCache.evictUserPayments(savedPayment.getUserId());
            paymentCache.evictBookingPayments(savedPayment.getBookingId());
            paymentCache.evictPaymentsByStatus("PENDING");
            paymentCache.evictPaymentsByStatus("FAILED");

            // Publish payment status changed event
            rabbitTemplate.convertAndSend(
                    exchange,
                    paymentStatusRoutingKey,
                    new Events.PaymentStatusChanged(
                            savedPayment.getId(), 
                            savedPayment.getBookingId(), 
                            savedPayment.getUserId(),
                            savedPayment.getAmount(), 
                            savedPayment.getStatus()
                    )
            );
            
            log.info("Payment {} marked as failed: {}", paymentId, reason);
        } catch (Exception e) {
            log.error("Error failing payment {}: {}", paymentId, e.getMessage(), e);
        }
    }

    @Transactional
    public Map<String, String> failPayment(UUID paymentId, String reason) {
        log.info("Marking payment {} as failed. Reason: {}", paymentId, reason != null ? reason : "No reason provided");
        
        Payment payment = paymentRepo.findById(paymentId)
            .orElseThrow(() -> {
                log.warn("Payment {} not found for failure", paymentId);
                return new IllegalArgumentException("Payment not found");
            });
        
        // Prevent state transitions: once COMPLETED, cannot be failed
        String currentStatus = payment.getStatus();
        if ("COMPLETED".equals(currentStatus)) {
            log.warn("Attempted to fail COMPLETED payment {}", paymentId);
            throw new IllegalStateException("Payment is COMPLETED and cannot be failed");
        }
        if ("FAILED".equals(currentStatus)) {
            log.warn("Attempted to fail already FAILED payment {}", paymentId);
            throw new IllegalStateException("Payment is already FAILED");
        }
        
        log.info("Payment {} status changed from {} to FAILED", paymentId, currentStatus);
        payment.setStatus("FAILED");
        Payment savedPayment = paymentRepo.save(payment);

        // Update cache
        paymentCache.putPayment(savedPayment, Duration.ofMinutes(30));

        // Evict related caches
        paymentCache.evictUserPayments(savedPayment.getUserId());
        paymentCache.evictBookingPayments(savedPayment.getBookingId());
        paymentCache.evictPaymentsByStatus("PENDING");
        paymentCache.evictPaymentsByStatus("FAILED");

        // Publish payment status changed event
        rabbitTemplate.convertAndSend(
                exchange,
                paymentStatusRoutingKey,
                new Events.PaymentStatusChanged(
                        savedPayment.getId(), 
                        savedPayment.getBookingId(), 
                        savedPayment.getUserId(),
                        savedPayment.getAmount(), 
                        savedPayment.getStatus()
                )
        );
        
        return Map.of(
            "message", "payment marked as failed", 
            "reason", reason != null ? reason : "No reason provided"
        );
    }

    public List<Payment> getUserPayments(UUID userId) {
        // Try cache first
        List<Payment> cached = paymentCache.getUserPayments(userId);
        if (cached != null) {
            return cached;
        }
        
        // Fetch from database
        List<Payment> payments = paymentRepo.findByUserId(userId);
        
        // Cache the result
        paymentCache.putUserPayments(userId, payments, Duration.ofMinutes(15));
        
        return payments;
    }

    public List<Payment> getPaymentsByBooking(UUID bookingId) {
        // Try cache first
        List<Payment> cached = paymentCache.getBookingPayments(bookingId);
        if (cached != null) {
            return cached;
        }
        
        // Fetch from database
        List<Payment> payments = paymentRepo.findByBookingId(bookingId);
        
        // Cache the result
        paymentCache.putBookingPayments(bookingId, payments, Duration.ofMinutes(15));
        
        return payments;
    }

    public List<Payment> getPaymentsByDateRange(LocalDateTime from, LocalDateTime to) {
        // Try cache first (use date range as cache key)
        String cacheKey = "dateRange:" + from + ":" + to;
        Object cached = paymentCache.getPaymentsByDateRange(cacheKey);
        if (cached instanceof List) {
            @SuppressWarnings("unchecked")
            List<Payment> payments = (List<Payment>) cached;
            return payments;
        }
        
        // Fetch from database
        List<Payment> payments = paymentRepo.findByCreatedAtBetween(from, to);
        
        // Cache the result (shorter TTL for date range queries)
        paymentCache.putPaymentsByDateRange(cacheKey, payments, Duration.ofMinutes(10));
        
        return payments;
    }

    public List<Payment> getPaymentsByStatus(String status) {
        // Try cache first
        List<Payment> cached = paymentCache.getPaymentsByStatus(status);
        if (cached != null) {
            return cached;
        }
        
        // Fetch from database
        List<Payment> payments = paymentRepo.findByStatus(status);
        
        // Cache the result
        paymentCache.putPaymentsByStatus(status, payments, Duration.ofMinutes(10));
        
        return payments;
    }

    public List<Payment> getAllPayments() {
        return paymentRepo.findAll();
    }

    public Map<String, String> clearCache() {
        paymentCache.evictAllPaymentCaches();
        return Map.of("message", "All payment caches cleared");
    }

    public List<Payment> getPendingPaymentsOlderThan(int hours) {
        LocalDateTime cutoff = LocalDateTime.now().minusHours(hours);
        return paymentRepo.findAll().stream()
            .filter(p -> "PENDING".equals(p.getStatus()))
            .filter(p -> p.getCreatedAt().isBefore(cutoff))
            .toList();
    }
}
