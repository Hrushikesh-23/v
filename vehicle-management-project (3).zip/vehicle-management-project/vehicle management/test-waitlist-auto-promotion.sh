#!/bin/bash

# Test Waitlist Auto-Promotion Scenario:
# 1. Person A books a slot for a time window
# 2. Person B tries to book same slot/time - gets waitlisted
# 3. Person A cancels booking
# 4. Person B's waitlist should automatically convert to confirmed booking

BASE_URL="http://localhost:8083"
GATEWAY_URL="http://localhost:8080"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

echo "========================================="
echo "WAITLIST AUTO-PROMOTION TEST"
echo "Scenario: Booking cancellation -> Waitlist promotion"
echo "========================================="
echo ""

# Setup: Get admin token and create lot/spot
echo "Setting up test environment..."
ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ -z "$ADMIN_TOKEN" ]; then
    curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
        -H "Content-Type: application/json" \
        -d '{"fullName":"Test Admin","email":"admintest@example.com","password":"admin123","role":"ADMIN"}' > /dev/null
    sleep 1
    ADMIN_TOKEN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
        -H "Content-Type: application/json" \
        -d '{"email":"admintest@example.com","password":"admin123"}' | grep -o '"token":"[^"]*' | cut -d'"' -f4)
fi

# Get or create lot and spot
LOTS_RESPONSE=$(curl -s -X GET "${GATEWAY_URL}/api/lots" -H "Authorization: Bearer ${ADMIN_TOKEN}")
LOT_ID=$(echo "$LOTS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0]['id'] if data else '')" 2>/dev/null)

if [ -z "$LOT_ID" ]; then
    LOT_RESPONSE=$(curl -s -X POST "${GATEWAY_URL}/api/lots" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${ADMIN_TOKEN}" \
        -d '{"name":"Waitlist Test Lot","address":"Test Address"}')
    LOT_ID=$(echo "$LOT_RESPONSE" | grep -o '"id":[0-9]*' | cut -d':' -f2)
fi

# Create a fresh spot specifically for this test
SPOT_CODE="WAITLIST-PROMO-$(date +%s)"
echo "Creating fresh spot: ${SPOT_CODE}"
SPOT_CREATE_RESPONSE=$(curl -s -X POST "${GATEWAY_URL}/api/lots/${LOT_ID}/spots" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${ADMIN_TOKEN}" \
    -d "{\"code\":\"${SPOT_CODE}\",\"available\":true}")
SPOT_ID=$(echo "$SPOT_CREATE_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data.get('id', ''))" 2>/dev/null)

if [ -z "$SPOT_ID" ]; then
    sleep 1
    SPOTS_RESPONSE=$(curl -s -X GET "${GATEWAY_URL}/api/lots/${LOT_ID}/spots" -H "Authorization: Bearer ${ADMIN_TOKEN}")
    SPOT_ID=$(echo "$SPOTS_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); spot=[s for s in data if s.get('code')=='${SPOT_CODE}']; print(spot[0]['id'] if spot else '')" 2>/dev/null)
fi

echo "Using Lot ID: $LOT_ID, Spot ID: $SPOT_ID"
echo ""

# Register User A
USER_A_EMAIL="usera_$(date +%s)@example.com"
echo "Registering User A: ${USER_A_EMAIL}"
curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"fullName\":\"User A\",\"email\":\"${USER_A_EMAIL}\",\"password\":\"password123\",\"role\":\"USER\"}" > /dev/null
sleep 1

LOGIN_A=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"${USER_A_EMAIL}\",\"password\":\"password123\"}")
USER_A_TOKEN=$(echo "$LOGIN_A" | grep -o '"token":"[^"]*' | cut -d'"' -f4)

# Register User B
USER_B_EMAIL="userb_$(date +%s)@example.com"
echo "Registering User B: ${USER_B_EMAIL}"
curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
    -H "Content-Type: application/json" \
    -d "{\"fullName\":\"User B\",\"email\":\"${USER_B_EMAIL}\",\"password\":\"password123\",\"role\":\"USER\"}" > /dev/null
sleep 1

LOGIN_B=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"${USER_B_EMAIL}\",\"password\":\"password123\"}")
USER_B_TOKEN=$(echo "$LOGIN_B" | grep -o '"token":"[^"]*' | cut -d'"' -f4)

echo "✅ Users registered"
echo ""

# Calculate time window (future date - use day after tomorrow to avoid conflicts)
DAY_AFTER_TOMORROW=$(date -v+2d +%Y-%m-%d 2>/dev/null || date -d "+2 days" +%Y-%m-%d)
START_TIME="${DAY_AFTER_TOMORROW}T09:00:00"
END_TIME="${DAY_AFTER_TOMORROW}T13:00:00"

echo "========================================="
echo "STEP 1: User A books the slot"
echo "========================================="
echo "Time Window: ${START_TIME} to ${END_TIME}"
echo ""

BOOKING_A_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/bookings" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${USER_A_TOKEN}" \
    -d "{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START_TIME}\",\"endTime\":\"${END_TIME}\"}")

echo "User A booking response:"
echo "$BOOKING_A_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$BOOKING_A_RESPONSE"
echo ""

BOOKING_A_ID=$(echo "$BOOKING_A_RESPONSE" | grep -o '"id":"[^"]*' | cut -d'"' -f4)
BOOKING_A_STATUS=$(echo "$BOOKING_A_RESPONSE" | grep -o '"status":"[^"]*' | cut -d'"' -f4)

if [ -z "$BOOKING_A_ID" ]; then
    echo -e "${COLOR_RED}✗ FAIL: User A booking failed${COLOR_NC}"
    exit 1
fi

echo -e "${COLOR_GREEN}✓ User A booking created${COLOR_NC}"
echo "  Booking ID: $BOOKING_A_ID"
echo "  Status: $BOOKING_A_STATUS"
echo ""

# Wait for async confirmation
echo "Waiting for booking confirmation (3 seconds)..."
sleep 3

# Check booking status
BOOKING_A_CHECK=$(curl -s -X GET "${BASE_URL}/api/bookings/${BOOKING_A_ID}" -H "Authorization: Bearer ${USER_A_TOKEN}")
BOOKING_A_STATUS=$(echo "$BOOKING_A_CHECK" | grep -o '"status":"[^"]*' | cut -d'"' -f4)
echo "User A booking status after confirmation: $BOOKING_A_STATUS"
echo ""

echo "========================================="
echo "STEP 2: User B tries to book same slot"
echo "========================================="
echo ""

# Try booking - if it fails with cache error, try waitlist endpoint directly
BOOKING_B_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/bookings" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${USER_B_TOKEN}" \
    -d "{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START_TIME}\",\"endTime\":\"${END_TIME}\"}")

echo "User B booking response:"
echo "$BOOKING_B_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$BOOKING_B_RESPONSE"
echo ""

WAITLIST_ID=$(echo "$BOOKING_B_RESPONSE" | grep -o '"waitlistId":"[^"]*' | cut -d'"' -f4)

# If booking failed due to cache, try adding to waitlist directly
if [ -z "$WAITLIST_ID" ]; then
    echo "Booking failed - trying waitlist endpoint directly..."
    WAITLIST_RESPONSE=$(curl -s -X POST "${BASE_URL}/api/bookings/waitlist" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${USER_B_TOKEN}" \
        -d "{\"lotId\":${LOT_ID},\"spotId\":${SPOT_ID},\"startTime\":\"${START_TIME}\",\"endTime\":\"${END_TIME}\"}")
    
    echo "Waitlist response:"
    echo "$WAITLIST_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$WAITLIST_RESPONSE"
    echo ""
    
    WAITLIST_ID=$(echo "$WAITLIST_RESPONSE" | grep -o '"waitlistId":"[^"]*' | cut -d'"' -f4)
    
    if [ -z "$WAITLIST_ID" ]; then
        echo -e "${COLOR_RED}✗ FAIL: User B could not be added to waitlist${COLOR_NC}"
        echo "This might be a code issue - cache is blocking waitlist addition"
        exit 1
    fi
fi

echo -e "${COLOR_GREEN}✓ User B added to waitlist${COLOR_NC}"
echo "  Waitlist ID: $WAITLIST_ID"
echo ""

# Check User B's waitlist
echo "Checking User B's waitlist entries..."
WAITLIST_B=$(curl -s -X GET "${BASE_URL}/api/bookings/waitlist" -H "Authorization: Bearer ${USER_B_TOKEN}")
echo "$WAITLIST_B" | python3 -m json.tool 2>/dev/null || echo "$WAITLIST_B"
echo ""

WAITLIST_STATUS=$(echo "$WAITLIST_B" | grep -o '"status":"[^"]*' | cut -d'"' -f4)
echo "Waitlist status: $WAITLIST_STATUS (should be PENDING)"
echo ""

echo "========================================="
echo "STEP 3: User A cancels booking"
echo "========================================="
echo ""

CANCEL_RESPONSE=$(curl -s -X DELETE "${BASE_URL}/api/bookings/${BOOKING_A_ID}" \
    -H "Authorization: Bearer ${USER_A_TOKEN}")

echo "Cancellation response:"
echo "$CANCEL_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$CANCEL_RESPONSE"
echo ""

echo -e "${COLOR_GREEN}✓ Booking cancellation initiated${COLOR_NC}"
echo ""

# Wait for async processing (waitlist promotion)
echo "Waiting for async waitlist processing (5 seconds)..."
sleep 5

echo "========================================="
echo "STEP 4: Verify User B's waitlist promotion"
echo "========================================="
echo ""

# Check User B's waitlist (should be empty or status changed to NOTIFIED)
echo "Checking User B's waitlist after cancellation..."
WAITLIST_B_AFTER=$(curl -s -X GET "${BASE_URL}/api/bookings/waitlist" -H "Authorization: Bearer ${USER_B_TOKEN}")
echo "$WAITLIST_B_AFTER" | python3 -m json.tool 2>/dev/null || echo "$WAITLIST_B_AFTER"
echo ""

# Check if User B has a booking now
echo "Checking User B's bookings..."
BOOKINGS_B=$(curl -s -X GET "${BASE_URL}/api/bookings" -H "Authorization: Bearer ${USER_B_TOKEN}")
echo "$BOOKINGS_B" | python3 -m json.tool 2>/dev/null || echo "$BOOKINGS_B"
echo ""

BOOKING_B_ID=$(echo "$BOOKINGS_B" | grep -o '"id":"[^"]*' | cut -d'"' -f4 | head -1)
BOOKING_B_STATUS=$(echo "$BOOKINGS_B" | grep -o '"status":"[^"]*' | cut -d'"' -f4 | head -1)

echo "========================================="
echo "RESULTS"
echo "========================================="
echo ""

if [ ! -z "$BOOKING_B_ID" ]; then
    echo -e "${COLOR_GREEN}✅ SUCCESS: Waitlist auto-promotion working!${COLOR_NC}"
    echo ""
    echo "User B's booking details:"
    echo "  Booking ID: $BOOKING_B_ID"
    echo "  Status: $BOOKING_B_STATUS"
    echo "  Start Time: ${START_TIME}"
    echo "  End Time: ${END_TIME}"
    echo ""
    echo "✅ User B's waitlist entry was automatically converted to a booking!"
else
    echo -e "${COLOR_YELLOW}⚠️  Waitlist entry not yet converted${COLOR_NC}"
    echo ""
    echo "This might be because:"
    echo "  1. Async processing needs more time"
    echo "  2. Scheduler runs every 5 minutes"
    echo ""
    echo "Checking waitlist status..."
    
    # Check waitlist status directly from database query via admin API
    WAITLIST_STATUS_AFTER=$(echo "$WAITLIST_B_AFTER" | grep -o '"status":"[^"]*' | cut -d'"' -f4)
    if [ "$WAITLIST_STATUS_AFTER" = "NOTIFIED" ] || [ -z "$WAITLIST_B_AFTER" ]; then
        echo -e "${COLOR_GREEN}✅ Waitlist status changed to NOTIFIED (promotion in progress)${COLOR_NC}"
    else
        echo "Waitlist status: $WAITLIST_STATUS_AFTER"
    fi
fi

echo ""
echo "========================================="
echo "MONITORING"
echo "========================================="
echo ""

echo -e "${COLOR_BLUE}[RABBITMQ] Booking events...${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "import sys, json; data=json.load(sys.stdin); queues = [q for q in data if 'booking' in q['name'].lower()]; [print(f\"  - {q['name']}: {q.get('messages', 0)} messages, {q.get('consumers', 0)} consumers\") for q in queues] if queues else print('  No booking queues')" 2>/dev/null

echo ""
echo -e "${COLOR_BLUE}[REDIS] Cache status...${COLOR_NC}"
redis-cli KEYS "*spot*${SPOT_ID}*" 2>/dev/null | head -5 || echo "  No spot cache keys"

echo ""
echo "========================================="
echo "TEST COMPLETE"
echo "========================================="

