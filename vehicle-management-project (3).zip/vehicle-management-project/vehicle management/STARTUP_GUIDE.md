# Vehicle Parking Management System - Startup Guide

## 🚀 Prerequisites

Before starting the services, ensure you have the following running:

### Required Services:
1. **MySQL 8.x** - Database server
2. **Redis 7.x** - Cache server
3. **RabbitMQ 4.x** - Message broker
4. **Java 21** - JDK installed and configured
5. **Maven 3.6+** - Build tool

### Verify Prerequisites:
```bash
# Check Java version
java -version  # Should be Java 21

# Check Maven version
mvn -version

# Check MySQL (use your system's command)
mysql --version

# Check Redis
redis-cli ping  # Should return PONG

# Check RabbitMQ (if management plugin enabled)
# Access: http://localhost:15672 (guest/guest)
```

## 📋 Service Startup Order

Services **MUST** be started in the following order to ensure proper registration:

### 1. **Eureka Service Discovery** (Port 8761) - **START FIRST**
   - This is the service registry that all other services register with
   - **Wait time after start**: 10-15 seconds before starting next service

### 2. **API Gateway** (Port 8080)
   - Routes requests to appropriate microservices
   - **Wait time after start**: 5 seconds before starting other services

### 3. **Core Services** (Can be started in parallel after gateway):
   - **User Service** (Port 8081)
   - **Admin Service** (Port 8082)
   - **Booking Service** (Port 8083)
   - **Payment Service** (Port 8084)
   - **Notification Service** (Port 8085)

## 🔧 Startup Methods

### Method 1: Using Batch Script (Windows)

```bash
start-all-services.bat
```

### Method 2: Manual Startup (Recommended for Development)

#### Terminal 1 - Eureka Service Discovery
```bash
cd discovery-service
mvn clean install
mvn spring-boot:run
```
**Wait until you see**: `Started DiscoveryApplication in X seconds`

#### Terminal 2 - API Gateway
```bash
cd api-gateway
mvn clean install
mvn spring-boot:run
```
**Wait until you see**: `Started GatewayApplication in X seconds`

#### Terminal 3 - User Service
```bash
cd user-service
mvn clean install
mvn spring-boot:run
```

#### Terminal 4 - Admin Service
```bash
cd admin-service
mvn clean install
mvn spring-boot:run
```

#### Terminal 5 - Booking Service
```bash
cd booking-service
mvn clean install
mvn spring-boot:run
```

#### Terminal 6 - Payment Service
```bash
cd payment-service
mvn clean install
mvn spring-boot:run
```

#### Terminal 7 - Notification Service
```bash
cd notification-service
mvn clean install
mvn spring-boot:run
```

## ✅ Verification Steps

### 1. Check Eureka Dashboard
Open browser: **http://localhost:8761**

You should see all services registered:
- ✅ **API-GATEWAY**
- ✅ **USER-SERVICE**
- ✅ **ADMIN-SERVICE**
- ✅ **BOOKING-SERVICE**
- ✅ **PAYMENT-SERVICE**
- ✅ **NOTIFICATION-SERVICE**

**Note**: If services don't appear, check:
- Services have `eureka.client.service-url.defaultZone` configured
- Services have `spring-cloud-starter-netflix-eureka-client` dependency
- Eureka server was started first
- Wait 30-60 seconds for registration (heartbeat interval)

### 2. Check Service Health Endpoints

```bash
# API Gateway
curl http://localhost:8080/actuator/health

# User Service
curl http://localhost:8081/actuator/health

# Admin Service
curl http://localhost:8082/actuator/health

# Booking Service
curl http://localhost:8083/actuator/health

# Payment Service
curl http://localhost:8084/actuator/health

# Notification Service
curl http://localhost:8085/actuator/health
```

### 3. Verify Database Connections
Check logs for each service to ensure:
- ✅ Database connection successful
- ✅ Tables created/updated
- ✅ No connection errors

### 4. Verify RabbitMQ Connection
Check service logs for:
- ✅ RabbitMQ connection established
- ✅ Exchanges and queues created
- ✅ No connection errors

### 5. Verify Redis Connection
Check service logs for:
- ✅ Redis connection successful
- ✅ Cache operations working
- ✅ No connection errors

## 🔍 Troubleshooting

### Issue: Services not registering with Eureka

**Solution:**
1. Ensure Eureka server started first and is running
2. Check `application.yml` has correct Eureka configuration:
   ```yaml
   eureka:
     client:
       service-url:
         defaultZone: http://localhost:8761/eureka
   ```
3. Verify `spring-cloud-starter-netflix-eureka-client` dependency exists
4. Check service logs for registration errors
5. Wait 30-60 seconds (registration happens on heartbeat)

### Issue: API Gateway can't route to services

**Solution:**
1. Verify services are registered in Eureka dashboard
2. Check API Gateway uses `lb://service-name` format (load balancer)
3. Verify service names match exactly:
   - `user-service`
   - `admin-service`
   - `booking-service`
   - `payment-service`
   - `notification-service`

### Issue: Database connection errors

**Solution:**
1. Verify MySQL is running
2. Check database credentials in `application.yml`
3. Ensure databases exist (they're auto-created if configured)
4. Check MySQL port (default: 3306)

### Issue: RabbitMQ connection errors

**Solution:**
1. Verify RabbitMQ is running: `rabbitmqctl status`
2. Check RabbitMQ port (default: 5672)
3. Verify management plugin enabled: `rabbitmq-plugins enable rabbitmq_management`
4. Access management UI: http://localhost:15672

### Issue: Redis connection errors

**Solution:**
1. Verify Redis is running: `redis-cli ping`
2. Check Redis port (default: 6379)
3. Check Redis configuration in `application.yml`

## 📝 Service Configuration Checklist

### Each Service Should Have:
- [ ] `spring.application.name` in `application.yml`
- [ ] Eureka client dependency in `pom.xml`
- [ ] Eureka client configuration in `application.yml`
- [ ] Database configuration
- [ ] Redis configuration (if using cache)
- [ ] RabbitMQ configuration (if using messaging)
- [ ] JWT secret configured

### API Gateway Should Have:
- [ ] Eureka client dependency
- [ ] Routes configured with `lb://service-name`
- [ ] Correct path predicates

## 🎯 Next Steps

After all services are running:
1. ✅ Verify all services registered in Eureka
2. ✅ Test API endpoints (see API_TESTING.md)
3. ✅ Check Swagger documentation at service URLs
4. ✅ Monitor logs for any errors

## 📊 Service Ports Summary

| Service | Port | Eureka Registration | Health Check |
|---------|------|---------------------|--------------|
| Eureka Server | 8761 | N/A | http://localhost:8761 |
| API Gateway | 8080 | ✅ | http://localhost:8080/actuator/health |
| User Service | 8081 | ✅ | http://localhost:8081/actuator/health |
| Admin Service | 8082 | ✅ | http://localhost:8082/actuator/health |
| Booking Service | 8083 | ✅ | http://localhost:8083/actuator/health |
| Payment Service | 8084 | ✅ | http://localhost:8084/actuator/health |
| Notification Service | 8085 | ✅ | http://localhost:8085/actuator/health |

## 🛑 Stopping Services

1. Press `Ctrl+C` in each terminal
2. Stop in reverse order (Notification → Eureka)
3. Or use process manager to stop all Java processes

