#!/bin/bash

# Complete Admin Service API Testing with Different Values

BASE_URL="http://localhost:8082"
GATEWAY_URL="http://localhost:8080"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

ADMIN_TOKEN=""
LOT_IDS=()
SPOT_IDS=()

echo "========================================="
echo "COMPREHENSIVE ADMIN SERVICE API TESTING"
echo "Testing with Different Values"
echo "========================================="
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local token=$5
    local expected_code=${6:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ -z "$token" ]; then
        response=$(curl -s -w "\n%{http_code}" -X $method "${BASE_URL}${endpoint}" \
            -H "Content-Type: application/json" \
            -d "${data}")
    else
        response=$(curl -s -w "\n%{http_code}" -X $method "${BASE_URL}${endpoint}" \
            -H "Content-Type: application/json" \
            -H "Authorization: Bearer ${token}" \
            -d "${data}")
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "$body" | python3 -m json.tool 2>/dev/null | head -15 || echo "$body" | head -5
        echo "$body" > /tmp/last_response.json
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "$body"
        return 1
    fi
    echo ""
}

# Get admin token
echo "Getting admin token..."
ADMIN_LOGIN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"admintest@example.com","password":"admin123"}')
ADMIN_TOKEN=$(echo "$ADMIN_LOGIN" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
if [ -z "$ADMIN_TOKEN" ]; then
    echo "Registering admin..."
    curl -s -X POST "${GATEWAY_URL}/api/auth/register" \
        -H "Content-Type: application/json" \
        -d '{"fullName":"Test Admin","email":"admintest@example.com","password":"admin123","role":"ADMIN"}' > /dev/null
    sleep 1
    ADMIN_LOGIN=$(curl -s -X POST "${GATEWAY_URL}/api/auth/login" \
        -H "Content-Type: application/json" \
        -d '{"email":"admintest@example.com","password":"admin123"}')
    ADMIN_TOKEN=$(echo "$ADMIN_LOGIN" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
fi
echo "✅ Admin token obtained"
echo ""

echo "========================================="
echo "PHASE 1: Create Multiple Parking Lots"
echo "========================================="

# Create multiple parking lots
test_api "POST" "/api/lots" '{"name":"Central Business District Parking","address":"100 Business Ave, Downtown"}' "1.1 Create Lot 1" "$ADMIN_TOKEN"
LOT1_ID=$(cat /tmp/last_response.json | grep -o '"id":[0-9]*' | cut -d':' -f2)
LOT_IDS+=($LOT1_ID)

test_api "POST" "/api/lots" '{"name":"Shopping Mall Parking","address":"200 Retail Blvd, Shopping District"}' "1.2 Create Lot 2" "$ADMIN_TOKEN"
LOT2_ID=$(cat /tmp/last_response.json | grep -o '"id":[0-9]*' | cut -d':' -f2)
LOT_IDS+=($LOT2_ID)

test_api "POST" "/api/lots" '{"name":"Airport Parking","address":"300 Airport Way, Terminal 1"}' "1.3 Create Lot 3" "$ADMIN_TOKEN"
LOT3_ID=$(cat /tmp/last_response.json | grep -o '"id":[0-9]*' | cut -d':' -f2)
LOT_IDS+=($LOT3_ID)

echo ""
echo "========================================="
echo "PHASE 2: Add Multiple Parking Spots"
echo "========================================="

# Add spots to Lot 1
test_api "POST" "/api/lots/${LOT1_ID}/spots" '{"code":"CBD-01","available":true}' "2.1 Add spot to Lot 1" "$ADMIN_TOKEN"
test_api "POST" "/api/lots/${LOT1_ID}/spots" '{"code":"CBD-02","available":true}' "2.2 Add spot to Lot 1" "$ADMIN_TOKEN"
test_api "POST" "/api/lots/${LOT1_ID}/spots" '{"code":"CBD-03","available":false}' "2.3 Add occupied spot to Lot 1" "$ADMIN_TOKEN"

# Add spots to Lot 2
test_api "POST" "/api/lots/${LOT2_ID}/spots" '{"code":"MALL-01","available":true}' "2.4 Add spot to Lot 2" "$ADMIN_TOKEN"
test_api "POST" "/api/lots/${LOT2_ID}/spots" '{"code":"MALL-02","available":true}' "2.5 Add spot to Lot 2" "$ADMIN_TOKEN"

# Add spots to Lot 3
test_api "POST" "/api/lots/${LOT3_ID}/spots" '{"code":"APT-A1","available":true}' "2.6 Add spot to Lot 3" "$ADMIN_TOKEN"
test_api "POST" "/api/lots/${LOT3_ID}/spots" '{"code":"APT-A2","available":true}' "2.7 Add spot to Lot 3" "$ADMIN_TOKEN"
test_api "POST" "/api/lots/${LOT3_ID}/spots" '{"code":"APT-A3","available":false}' "2.8 Add occupied spot to Lot 3" "$ADMIN_TOKEN"

echo ""
echo "========================================="
echo "PHASE 3: Get All Data"
echo "========================================="

test_api "GET" "/api/lots" "" "3.1 Get all parking lots" "$ADMIN_TOKEN"

test_api "GET" "/api/lots/${LOT1_ID}/spots" "" "3.2 Get all spots for Lot 1" "$ADMIN_TOKEN"

test_api "GET" "/api/lots/${LOT2_ID}/spots/available" "" "3.3 Get available spots for Lot 2" "$ADMIN_TOKEN"

echo ""
echo "========================================="
echo "PHASE 4: Update Operations"
echo "========================================="

test_api "PUT" "/api/lots/${LOT1_ID}" '{"name":"Updated Central Business District","address":"101 Updated Business Ave"}' "4.1 Update Lot 1" "$ADMIN_TOKEN"

# Get first spot ID from Lot 1
SPOT1_ID=$(curl -s -X GET "${BASE_URL}/api/lots/${LOT1_ID}/spots" -H "Authorization: Bearer ${ADMIN_TOKEN}" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0]['id'] if data else '')" 2>/dev/null)

if [ ! -z "$SPOT1_ID" ]; then
    test_api "PUT" "/api/lots/${LOT1_ID}/spots/${SPOT1_ID}" '{"code":"CBD-01-UPDATED","available":true}' "4.2 Update Spot 1" "$ADMIN_TOKEN"
fi

echo ""
echo "========================================="
echo "PHASE 5: Dashboard & Reports (Real Data)"
echo "========================================="

test_api "GET" "/api/admin/dashboard/stats" "" "5.1 Dashboard stats (REAL DATA)" "$ADMIN_TOKEN"

test_api "GET" "/api/admin/bookings/history" "" "5.2 Booking history (REAL DATA)" "$ADMIN_TOKEN"

test_api "GET" "/api/admin/transactions/logs" "" "5.3 Transaction logs (REAL DATA)" "$ADMIN_TOKEN"

test_api "GET" "/api/admin/reports/occupancy" "" "5.4 Occupancy report (REAL DATA)" "$ADMIN_TOKEN"

test_api "GET" "/api/admin/reports/revenue" "" "5.5 Revenue report (REAL DATA)" "$ADMIN_TOKEN"

echo ""
echo "========================================="
echo "PHASE 6: Filtered Queries"
echo "========================================="

test_api "GET" "/api/admin/bookings/history?status=CREATED" "" "6.1 Booking history with status filter" "$ADMIN_TOKEN"

test_api "GET" "/api/admin/transactions/logs?status=COMPLETED" "" "6.2 Transaction logs with status filter" "$ADMIN_TOKEN"

echo ""
echo "========================================="
echo "MONITORING"
echo "========================================="

echo -e "${COLOR_BLUE}[RABBITMQ] Queue Status:${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "import sys, json; data=json.load(sys.stdin); admin_queues = [q for q in data if 'admin' in q['name'].lower()]; [print(f\"  Queue: {q['name']}, Messages: {q.get('messages', 0)}, Consumers: {q.get('consumers', 0)}\") for q in admin_queues] if admin_queues else print('  No admin queues')" 2>/dev/null

echo ""
echo -e "${COLOR_BLUE}[REDIS] Cache Keys:${COLOR_NC}"
redis-cli KEYS "*" 2>/dev/null | head -10 | while read key; do
    echo "  Key: $key"
done

echo ""
echo "========================================="
echo "TESTING COMPLETE"
echo "========================================="

