#!/bin/bash

# Complete Admin Service API Testing with RabbitMQ and Redis Monitoring

BASE_URL="http://localhost:8082"
GATEWAY_URL="http://localhost:8080"
COLOR_GREEN='\033[0;32m'
COLOR_RED='\033[0;31m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_NC='\033[0m'

ADMIN_TOKEN=""
LOT_ID=""
SPOT_ID=""

echo "========================================="
echo "COMPREHENSIVE ADMIN SERVICE API TESTING"
echo "========================================="
echo ""

# Function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    local token=$5
    local expected_code=${6:-200}
    
    echo -e "${COLOR_YELLOW}[TEST] ${description}${COLOR_NC}"
    echo "  ${method} ${endpoint}"
    
    if [ -z "$token" ]; then
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -d "${data}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}")
        fi
    else
        if [ "$method" = "POST" ]; then
            response=$(curl -s -w "\n%{http_code}" -X POST "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "PUT" ]; then
            response=$(curl -s -w "\n%{http_code}" -X PUT "${BASE_URL}${endpoint}" \
                -H "Content-Type: application/json" \
                -H "Authorization: Bearer ${token}" \
                -d "${data}")
        elif [ "$method" = "DELETE" ]; then
            response=$(curl -s -w "\n%{http_code}" -X DELETE "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        else
            response=$(curl -s -w "\n%{http_code}" -X GET "${BASE_URL}${endpoint}" \
                -H "Authorization: Bearer ${token}")
        fi
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq "$expected_code" ]; then
        echo -e "${COLOR_GREEN}✓ PASS (${http_code})${COLOR_NC}"
        echo "  Response: $body" | head -c 300
        echo ""
        echo "$body" > /tmp/last_response.json
        echo "$body"
        return 0
    else
        echo -e "${COLOR_RED}✗ FAIL (Expected ${expected_code}, Got ${http_code})${COLOR_NC}"
        echo "  Response: $body"
        return 1
    fi
    echo ""
}

# Get admin token first
echo "Getting admin token..."
ADMIN_LOGIN=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"admin@example.com","password":"admin123"}')

# Try alternative admin
if [ -z "$(echo "$ADMIN_LOGIN" | grep -o '"token"')" ]; then
    echo "Trying to register admin first..."
    curl -s -X POST "${BASE_URL}/api/auth/register" \
        -H "Content-Type: application/json" \
        -d '{"fullName":"Admin User","email":"admin@example.com","password":"admin123","role":"ADMIN"}' > /dev/null
    sleep 1
    ADMIN_LOGIN=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
        -H "Content-Type: application/json" \
        -d '{"email":"admin@example.com","password":"admin123"}')
fi

ADMIN_TOKEN=$(echo "$ADMIN_LOGIN" | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ -z "$ADMIN_TOKEN" ]; then
    echo -e "${COLOR_RED}✗ FAILED to get admin token${COLOR_NC}"
    exit 1
fi

echo -e "${COLOR_GREEN}✓ Admin token obtained${COLOR_NC}"
echo ""

echo "========================================="
echo "PHASE 1: Parking Lot Management APIs"
echo "========================================="

# 1. Create Parking Lot
LOT_DATA='{"name":"Test Parking Lot","address":"123 Test Street, Test City"}'
test_api "POST" "/api/lots" "$LOT_DATA" "1.1 Create parking lot" "$ADMIN_TOKEN"
LOT_ID=$(cat /tmp/last_response.json | grep -o '"id":[0-9]*' | cut -d':' -f2)
echo "Created Lot ID: $LOT_ID"

# 2. Get All Parking Lots
test_api "GET" "/api/lots" "" "1.2 Get all parking lots" "$ADMIN_TOKEN"

# 3. Update Parking Lot
if [ ! -z "$LOT_ID" ]; then
    UPDATE_LOT_DATA='{"name":"Updated Test Parking Lot","address":"456 Updated Street, Updated City"}'
    test_api "PUT" "/api/lots/${LOT_ID}" "$UPDATE_LOT_DATA" "1.3 Update parking lot" "$ADMIN_TOKEN"
fi

echo ""
echo "========================================="
echo "PHASE 2: Parking Spot Management APIs"
echo "========================================="

# 4. Add Parking Spot
if [ ! -z "$LOT_ID" ]; then
    SPOT_DATA='{"code":"A-01","available":true}'
    test_api "POST" "/api/lots/${LOT_ID}/spots" "$SPOT_DATA" "2.1 Add parking spot" "$ADMIN_TOKEN"
    SPOT_ID=$(cat /tmp/last_response.json | grep -o '"id":[0-9]*' | cut -d':' -f2)
    echo "Created Spot ID: $SPOT_ID"
fi

# 5. Add Another Spot
if [ ! -z "$LOT_ID" ]; then
    SPOT_DATA2='{"code":"A-02","available":true}'
    test_api "POST" "/api/lots/${LOT_ID}/spots" "$SPOT_DATA2" "2.2 Add second parking spot" "$ADMIN_TOKEN"
fi

# 6. Get All Spots for Lot
if [ ! -z "$LOT_ID" ]; then
    test_api "GET" "/api/lots/${LOT_ID}/spots" "" "2.3 Get all spots for lot" "$ADMIN_TOKEN"
fi

# 7. Get Available Spots
if [ ! -z "$LOT_ID" ]; then
    test_api "GET" "/api/lots/${LOT_ID}/spots/available" "" "2.4 Get available spots" "$ADMIN_TOKEN"
fi

# 8. Update Parking Spot
if [ ! -z "$LOT_ID" ] && [ ! -z "$SPOT_ID" ]; then
    UPDATE_SPOT_DATA='{"code":"A-01-UPDATED","available":false}'
    test_api "PUT" "/api/lots/${LOT_ID}/spots/${SPOT_ID}" "$UPDATE_SPOT_DATA" "2.5 Update parking spot" "$ADMIN_TOKEN"
fi

echo ""
echo "========================================="
echo "PHASE 3: Admin Dashboard & Reporting APIs"
echo "========================================="

# 9. Get Dashboard Stats
test_api "GET" "/api/admin/dashboard/stats" "" "3.1 Get dashboard statistics" "$ADMIN_TOKEN"

# 10. Get Booking History
test_api "GET" "/api/admin/bookings/history" "" "3.2 Get booking history" "$ADMIN_TOKEN"

# 11. Get Transaction Logs
test_api "GET" "/api/admin/transactions/logs" "" "3.3 Get transaction logs" "$ADMIN_TOKEN"

# 12. Get Occupancy Report
test_api "GET" "/api/admin/reports/occupancy" "" "3.4 Get occupancy report" "$ADMIN_TOKEN"

# 13. Get Revenue Report
test_api "GET" "/api/admin/reports/revenue" "" "3.5 Get revenue report" "$ADMIN_TOKEN"

echo ""
echo "========================================="
echo "PHASE 4: Cleanup (Optional)"
echo "========================================="

# 14. Delete Parking Spot
if [ ! -z "$LOT_ID" ] && [ ! -z "$SPOT_ID" ]; then
    test_api "DELETE" "/api/lots/${LOT_ID}/spots/${SPOT_ID}" "" "4.1 Delete parking spot" "$ADMIN_TOKEN" 200
fi

# 15. Delete Parking Lot (should fail if spots exist)
if [ ! -z "$LOT_ID" ]; then
    test_api "DELETE" "/api/lots/${LOT_ID}" "" "4.2 Delete parking lot (may fail if spots exist)" "$ADMIN_TOKEN"
fi

echo ""
echo "========================================="
echo "MONITORING CHECK"
echo "========================================="

echo -e "${COLOR_BLUE}[RABBITMQ] Checking queues:${COLOR_NC}"
curl -s -u guest:guest http://localhost:15672/api/queues | python3 -c "import sys, json; data=json.load(sys.stdin); [print(f\"  Queue: {q['name']}, Messages: {q.get('messages', 0)}\") for q in data if 'admin' in q['name'].lower() or 'lot' in q['name'].lower()]" 2>/dev/null || echo "  Could not check queues"

echo ""
echo -e "${COLOR_BLUE}[REDIS] Checking cache keys:${COLOR_NC}"
redis-cli KEYS "*lot*" 2>/dev/null | head -5 || echo "  No lot-related cache keys"

echo ""
echo "========================================="
echo "ADMIN SERVICE TESTING COMPLETE"
echo "========================================="

